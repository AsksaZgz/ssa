<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<!-- marca 0 -->  
<?php
include_once("lib/parroquia.php");
include_once("lib/informacion/informacion.php");
include_once("lib/informacion/tema.php");
include_once("lib/contador/contador.php");
include_once("lib/jquery/jqueryAcordeon.php");
include_once("lib/jquery/jqueryGaleria.php");
include_once("lib/bd.php");
include_once("lib/fichero/fichero_musica.php");

bd::conectar();
$parroquia = new Parroquia();
$contador  = new Contador(parroquia::$PREFIJO);
$jquery = new JqueryAcordeon();

$musica = new Musica();


$menuHistoria = new ParroquiaMenu("Historia",400,100023);      //
$menuDevocion = new ParroquiaMenu("Devoci�n",200, 100024);    //
$menuEucaristias = new ParroquiaMenu("Eucaristias",100,100025); //
$menuDespacho = new ParroquiaMenu("Despacho",500, 100026);       //
$menuObraSocial = new ParroquiaMenu("Obra Social",600,100109);  //
$menuComunidad = new ParroquiaMenu("Comunidad",700, 100520);     //
$menuNovios = new ParroquiaMenu("Novios",800,100041);         //
$menuEvangelio = new ParroquiaMenu("Evangelio",900,100010); //
$menuCulto = new ParroquiaMenu("Culto",1000,100001);
$menuGrupos = new ParroquiaMenu("Grupos",1100,100002);     //
$menuFotografias = new ParroquiaMenu("Fotografias", 3000);//

$galeria = new JqueryGaleria();
$galeria->nuevaFoto("./images/exterior/DSCN3140.JPG");
$galeria->nuevaFoto("./images/exterior/DSCN3141.JPG");
$galeria->nuevaFoto("./images/exterior/DSCN3142.JPG");
$galeria->nuevaFoto("./images/exterior/DSCN3146.JPG");
$galeria->nuevaFoto("./images/exterior/DSCN3147.JPG");
$galeria->nuevaFoto("./images/exterior/DSCN3148.JPG");
$galeria->nuevaFoto("./images/exterior/DSCN3150.JPG");
$galeria->nuevaFoto("./images/exterior/DSCN3151.JPG");
$galeria->nuevaFoto("./images/exterior/DSCN3153.JPG");
$galeria->nuevaFoto("./images/exterior/DSCN3154.JPG");
$galeria->nuevaFoto("./images/exterior/DSCN3155.JPG");
$galeria->nuevaFoto("./images/exterior/DSCN3156.JPG");

$HEAD = JqueryAcordeon::$HEAD
        .$galeria->head();
$BODY = JqueryAcordeon::$BODY_SCRIPT
        .$galeria->body()
        .$musica->web(); 

?>
<!-- marca 1-->
 <?php
    $parametros = new Parametro();
    $parametros->recuperar();  
    $orden = $parametros->orden();
    $suborden = $parametros->suborden();
    $menu = $menuEvangelio->enlace()
        .$menuNovios->enlace()
        .$menuGrupos->enlace()
        .$menuComunidad->enlace()
        .$menuDevocion->enlace()
        .$menuCulto->enlace()
        .$menuDespacho->enlace()
        .$menuEucaristias->enlace()
        .$menuObraSocial->enlace()
        .$menuHistoria->enlace()
        .$menuFotografias->enlace();
 ?>
 <?php    //L�gica del contenido
    $titulo="";
    $contenido="";
    switch ($orden) 
    {
        case $menuFotografias->orden:
            $contenido = $galeria->web();
        break;
        case $menuDevocion->orden:
        case $menuDespacho->orden:
        case $menuObraSocial->orden:
        case $menuHistoria->orden:
        case $menuEucaristias->orden:  
        case $menuComunidad->orden: 
        case $menuNovios->orden: 
            $infoManager = new Informacion(parroquia::$PREFIJO,parroquia::$INICIO);
            //$contenido =  $infoManager->webMostrar($suborden,true);
            $info = $infoManager->obtener($suborden);
            $contenido =  $info->contenido;
            $titulo = $info->titulo;            
            $contador->visita($orden);
        break;
        case $menuEvangelio->orden:
        case $menuCulto->orden:
        case $menuGrupos->orden:
            $tema = new Tema(parroquia::$PREFIJO);
            $infoManager = new Informacion(parroquia::$PREFIJO,parroquia::$INICIO);
            $listadoInfo = $tema->obtenerInformacionesOrdenadasFecha($suborden);
            foreach ($listadoInfo as $infoIdentificador) 
            {
                $info = $infoManager->obtener($infoIdentificador[0]);
                $contenido.=$jquery->panel($info->titulo, "", $info->contenido);
            }
            $contenido = $jquery->acordeon($contenido);
            $contador->visita($orden);
        break;    
        default:
            $tema = new Tema(parroquia::$PREFIJO);
            $infoManager = new Informacion(parroquia::$PREFIJO,parroquia::$INICIO);
            $listadoInfo = $tema->obtenerInformacionesOrdenadasFecha($menuEvangelio->suborden);
            foreach ($listadoInfo as $infoIdentificador) 
            {
                $info = $infoManager->obtener($infoIdentificador[0]);
                $contenido.=$jquery->panel($info->titulo, "", $info->contenido);
            }
            $contenido = $jquery->acordeon($contenido);
            $contador->visita($menuEvangelio->orden);
                  
            $contador->visita();
        break;
    }
    ?>
<?php
    print $HEAD;
?>
<title>
    <?php print Parroquia::$TITULO; ?>
</title>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<link rel="stylesheet" href="images/mm_lodging1.css" type="text/css" />
</head>
<body bgcolor="#999966">
<?php
    print $BODY;
?>
<table width="100%" border="0" cellspacing="0" cellpadding="0">
	<tr>
	<td width="10" nowrap="nowrap">
    	<img src="images/mm_spacer.gif" alt="" width="15" height="1" border="0" /></td>
	<td height="60" colspan="3" class="logo" nowrap="nowrap">
        <br />
        <img src="images/parroquia_100.gif" alt="" border="0" />
	    <?php print Parroquia::$TITULO; ?>
    </td>
	<td width="13">&nbsp;</td>
	<td width="22">&nbsp;</td>
	</tr>

	<tr bgcolor="#ffffff">
	<td colspan="6"><img src="images/mm_spacer.gif" alt="" width="1" height="1" border="0" /></td>
	</tr>

	<tr bgcolor="#a4c2c2">
	<td nowrap="nowrap">&nbsp;</td>
	<td height="36" colspan="3" id="navigation" class="navText">
        <?php 
            print $menu;
        ?>
    </td>
	<td width="13">&nbsp;</td>
	<td width="22">&nbsp;</td>
	</tr>

	<tr bgcolor="#ffffff">
	<td colspan="6"><img src="images/mm_spacer.gif" alt="" width="1" height="1" border="0" /></td>
	</tr>

	<tr bgcolor="#ffffff">
	<td colspan="2" valign="top" bgcolor="#a4c2c2"><table border="0" cellspacing="0" cellpadding="0" width="10">
		<tr>
		<td>
            
            <br />&nbsp;<br />        </td>
		</tr>
	</table>	
    </td>
	<td width="4" valign="top">&nbsp;</td>
	<td width="943" valign="top"><br />
	<br />
   
	<table border="0" cellspacing="0" cellpadding="0" width="100%">
		<tr>
		<td class="pageName">
            <p>
            <?php
                print $titulo;
            ?>
            </p>
        </td>
		</tr>

		<tr>
		<td class="bodyText">
		<p>
        <?php
            print $contenido;
        ?>
        </p>
        
		<br />		
        <div align="right">
            <?php
                print     $contador->visitasPagina();
            ?>
        </div>
        </td>
		</tr>
	</table>	</td>
	<td width="13">&nbsp;</td>
	<td width="22">&nbsp;</td>
	</tr>

	<tr bgcolor="#ffffff">
	<td colspan="6"><img src="images/mm_spacer.gif" alt="" width="1" height="1" border="0" /></td>
	</tr>

	<tr>
	<td colspan="2"><img src="images/mm_spacer.gif" alt="" width="50" height="1" border="0" /></td>
	<td width="4">&nbsp;</td>
	<td width="943">&nbsp;
	
    </td>
	<td width="13">&nbsp;</td>
	<td width="22">&nbsp;</td>
	</tr>
</table>
</body>
</html>
<?php
bd::desconectar();
?>