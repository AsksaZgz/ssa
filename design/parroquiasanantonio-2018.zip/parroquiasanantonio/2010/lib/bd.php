<?php
/*      IDEA
TABLA xxx_tabla
COLUMNAS    

METODOS     
*/ 
               
/*
VERSION     FECHA       COMENTARIO
----------- ----------- ----------------------------------------------------------------
x.x.x       dd/mm/aaaa  
*/
class bd
{
    /// PROPIEDADES //////////////////////////////////////////////////////////////////////
    private static function servidor()
    {
        return "hostingmysql56.amen.es";
    }
    private static function usuario()
    {
        return "cm250399";
    }
    private static function clave()
    {
        return"rY-XdTj2";
    }
    private static function base_datos()
    {
        return "cm250399";
    }
    
    
    public static function conectar()
    {
        mysql_connect(bd::servidor(), bd::usuario(), bd::clave());
        mysql_select_db(bd::base_datos());
    }
    
    public static function desconectar()
    {
        mysql_close(); 
    }
}
?>
