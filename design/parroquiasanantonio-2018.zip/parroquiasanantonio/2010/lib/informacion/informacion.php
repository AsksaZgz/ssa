<?php
/*
    Clase que permite trabajar con informaciones.
    
                        
            
            
*/
class Informacion
{
    var $tabla = "";
    var $pagina_web ="";
    var $fck_barra_herramientas = "Basic";
    var $fck_altura = 600;
    var $fck_anchura = 600;
    var $fck_base_path = "./etc/fckeditor/" ; 
    
    
    var $grupo = 0;                         //3.1.0
    
    var $orden_actualizar = 100;
    var $orden = "informacion";
    
    var $suborden_insertar = "insertar";     //3.1.0
    var $suborden_actualizar = "actualizar";   //3.1.0
    
    var $error = false;
    var $error_descripcion = "";
    
    var $mostrar_formulario_titulo_visible = true;
    var $mostrar_formulario_titulo_etiqueta = "Titulo:";
    var $mostrar_formulario_titulo_valor = "";
    var $sql = "";
    
   //Constructor
   function Informacion($prefijo_tabla ,  $pagina_web_base )
   {
       $this->tabla = $informacion_tabla;
       $this->pagina_web = $pagina_web_base;
       $this->sql = new InformacionSql($prefijo_tabla);
             
   }
   function logica($orden=null, $suborden=null)   //3.2.0
   {
       $informacion_datos = $this->recoger_parametros();
       
       if (is_null($orden))
       {
           $orden = $_POST["orden"];
       }
       if (is_null($suborden))
       {
           $suborden = $_POST["suborden"];
       }
       if ($orden==$this->orden)
       {
           switch ($suborden) {
              case $this->suborden_actualizar:
                    $salida = $this->sql_actualizar($informacion_datos["codigo"], $informacion_datos["titulo"], $informacion_datos["texto"]);
                break;
              case $this->suborden_insertar:
                     $salida = $this->sql_insertar($informacion_datos);
                break;
              
           }
       }
       
       return $salida;
       
   }
   
   function recoger_parametros() //3.2.0
   {
       return $_POST["informacion"];
   }
   
   //Muestra la informaci�n por codigo
   function mostrar($codigo , $mostrar_titulo = false )
   {
       $informacion = $this->sql_recuperar($codigo);
       if ($mostrar_titulo)
       {
           print $informacion["titulo"];
       }
       print $informacion["texto"];
       
   }
   
   function obtener($codigo)
   {
       return $this->sql->recuperar($codigo);
   }
   
   function webMostrar($codigo , $mostrar_titulo = false ) // 3.3.0
   {
       //$informacion = $this->sql_recuperar($codigo);
       $informacion = $this->sql->recuperar($codigo);
       //$informacion = new InformacionObjeto();
       $salida = "";
       if ($mostrar_titulo)
       {
           $salida = $informacion->titulo."<br />";
       }
       return $salida.$informacion->contenido;
       
   }
   
   function mostrar_formulario($codigo, $grupo) //3.1.0, 3.1.1  , 3.2.1.
   {
       $informacion_datos = null;
       if (is_null($codigo))
       {
           //Informacion nueva
           $suborden = $this->suborden_insertar;
           $boton = "Insertar";
           
       } else {
           //Editar informacion
           $suborden = $this->suborden_actualizar;
           $informacion_datos = $this->sql_recuperar($codigo);
           $boton = "Actualizar";
       }
       $oFCKeditor = new FCKeditor('informacion[texto]') ;
       $oFCKeditor->BasePath    = $this->fck_base_path ;
       $oFCKeditor->ToolbarSet = $this->fck_barra_herramientas;
       $oFCKeditor->Value        = $informacion_datos[texto] ;
       $oFCKeditor->Height = $this->fck_altura;
       $oFCKeditor->Width = $this->fck_anchura;
       
       $salida = "<form id=\"form1\" name=\"form1\" method=\"post\" action=\"$this->pagina_web\">";
                  
                  
       if ($this->mostrar_formulario_titulo_visible)
       {
           $salida .= "<label>
                  $this->mostrar_formulario_titulo_etiqueta <br />
                  <input type=\"text\" name=\"informacion[titulo]\" value=\"$informacion_datos[titulo]\"/>
                  </label>
                  <br />
                  ";
       } else {
           $salida .= "<input name=\"informacion[titulo]\" type=\"hidden\" id=\"informacion[titulo]\" value=\"$this->mostrar_formulario_titulo_valor\">";
       }
       $salida .= "<label>Texto: <br />";
       
       ob_start();
       $oFCKeditor->Create();
       $salida .= ob_get_contents();
       ob_end_clean();
       $salida .= "</label>
                    <br/>
                   <input name=\"informacion[codigo]\" type=\"hidden\" id=\"informacion[codigo]\" value=\"$codigo\">
                   <input type=\"hidden\" name=\"orden\" value=\"$this->orden\">
                   <input type=\"hidden\" name=\"suborden\" value=\"$suborden\">
                   <input type=\"hidden\" name=\"informacion[grupo]\" value=\"$grupo\">
                   <input name=\"sb_aceptar\" type=\"submit\"  class=\"boton\" value=\"$boton\">
                </form>";
       return $salida;
       
       
   }
   
   function mostrar_editar($codigo)
   {
       $informacion_original= $this->sql_recuperar($codigo);
       
       ?>
<table width="90%" border="0">
  <tr> 
    <td> 
      <div align="center">EDITAR 
        <table width="98%" border="0">
          <tr> 
            <td>
              <form name="form8" method="post" action="<?php print $this->pagina_web; ?>">
                <table width="99%" border="0" align="center">
                  <tr> 
                    <td> 
                      <div align="left">Id: 
                        <?php print $informacion_original[codigo];?>
                      </div>
                    </td>
                  </tr>
                  <tr> 
                    <td>Titulo:</td>
                    <td> * 
                      <input name="informacion[titulo]" type="text" id="informacion[titulo]" value="<?php print $informacion_original[titulo]; ?>" size="100">
                    </td>
                  </tr>
                  <tr> 
                    <td>Comentario:</td>
                    <td valign="top"> * 
                      
 <?php
// Automatically calculates the editor base path based on the _samples directory.
// This is usefull only for these samples. A real application should use something like this:
// $oFCKeditor->BasePath = '/fckeditor/' ;    // '/fckeditor/' is the default value.


$oFCKeditor = new FCKeditor('informacion[texto]') ;
$oFCKeditor->BasePath    = $this->fck_base_path ;
$oFCKeditor->ToolbarSet = $this->fck_barra_herramientas;
$oFCKeditor->Value        = $informacion_original[texto] ;
$oFCKeditor->Height = $this->fck_altura;
$oFCKeditor->Width = $this->fck_anchura; 
$oFCKeditor->Create() ;
?>

 
                    </td>
                  </tr>
                  <tr> 
                    <td colspan="2"> 
                      <div align="right"> 
                        
                        <input name="informacion[codigo]" type="hidden" id="informacion[codigo]" value="<?php print $codigo; ?>">
                        <input type="hidden" name="orden" value="<?php print $this->orden_actualizar; ?>">
                        <input type="hidden" name="informacion[grupo]" value="<?php print $informacion_original[grupo]; ?>">
                        
                        <input name="Submit172" type="submit"  class="boton" value="ACEPTAR">
                        
                      </div>
                    </td>
                  </tr>
                  <tr>
                    <td colspan="2">Los campos marcados con * son obligatorios.</td>
                  </tr>
                </table>
              </form>
            </td>
          </tr>
          <tr> 
            <td> 
              
            </td>
          </tr>
        </table>
      </div>
    </td>
  </tr>
</table>
<?php
}
   
   function actualizar()
   {
       $informacion_actualizada = $_POST[informacion];
       return $this->sql_actualizar($informacion_actualizada[codigo], $informacion_actualizada[titulo] , $informacion_actualizada[texto]);
   }    
   
   function error($texto)          //3.2.0
   {
       if ($texto != "")
       {
            $this->error = true;
            $this->error_descripcion = $texto;
       } else {
               $this->error = false;
       }
   }
       
   
   
}

?>
<!-- I -->
<?php
class InformacionSql     //4.0.0
{
    
    public static $CAMPO_IDENTIFICADOR = "id_informacion";
    public static $CAMPO_TITULO = "titulo";
    public static $CAMPO_CONTENIDO = "texto";    
    public static $TABLA = "informacion";
    var $tabla="informacion";
    var $ordenar = "";
    
    function InformacionSql($prefijo_tabla)
    {
          $this->tabla = $prefijo_tabla."_".InformacionSql::$TABLA;
    }
    
    function ordenar_fecha($ascendente = true)
    {
        if ($ascendente)
        {
            $this->ordenar =" ORDER BY modificado ";
        } else {
            $this->ordenar =" ORDER BY modificado DESC ";
        }
    }
    function lista()
    {
        return mysql_query("    SELECT *    
                                FROM $this->tabla 
                                WHERE estado = 1 ".$this->ordenar);
    }
    
    function existe_grupo_titulo($grupo , $titulo)   //3.1.0
   {
         $sentencia = " select *
                        from $this->tabla
                        where grupo = $grupo
                            and titulo = '$titulo' ";
         return mysql_fetch_array(mysql_query($sentencia));
   }
   
   function recuperar($codigo)
   {
       $res_informacion_original=mysql_query("SELECT ".InformacionSql::$CAMPO_TITULO
                                                .",".InformacionSql::$CAMPO_CONTENIDO
                                                ." FROM ".$this->tabla
                                                ." WHERE ".InformacionSql::$CAMPO_IDENTIFICADOR."='$codigo'");
                                                
       return $this->construir( mysql_fetch_array($res_informacion_original));
   }
   
   function borrar($codigo) //4.0.0
   {
       return mysql_query("DELETE from ".$this->tabla." where codigo='$codigo'");
   }
   function insertar_fecha($informacion_datos)     //4.0.0
   {
      $sentencia = " INSERT INTO $this->tabla (
                            `grupo` ,
                            `titulo` ,
                            `texto` ,
                            `estado` ,
                            `modificado` 
                        )
                        VALUES (
                            '".$informacion_datos["grupo"]."', 
                            '".$informacion_datos["titulo"]."', 
                            '".$informacion_datos["texto"]."', 
                            '1', 
                            '".$informacion_datos["modificado"]."' 
                        );";
      return informacion_sql::ejecutar($sentencia);
   }
   
   function insertar($informacion_datos)     //3.2.0
   {
      $sentencia = " INSERT INTO $this->tabla (
                            `grupo` ,
                            `titulo` ,
                            `texto` ,
                            `estado` ,
                            `modificado` 
                        )
                        VALUES (
                            '".$informacion_datos["grupo"]."', 
                            '".$informacion_datos["titulo"]."', 
                            '".$informacion_datos["texto"]."', 
                            '1', 
                            NOW( ) 
                        );";
      return informacion_sql::ejecutar($sentencia);
   }
   
   function actualizar($codigo, $titulo , $texto)
   {
       $sentencia = "UPDATE `".$this->tabla."` 
                    SET 
                    `titulo` = '".$titulo."',
                    `texto` = '".$texto."',
                    `modificado` = NOW( ) 
                    WHERE `codigo` =".$codigo.";";
       mysql_query($sentencia);
       
       return mysql_error();
       
   }
   
   function crear_tabla()
   {
       $sentencia ="CREATE TABLE `".$this->tabla."` (
                      `codigo` int(10) unsigned NOT NULL auto_increment,
                      `grupo` int(10) unsigned default NULL,
                      `titulo` varchar(200) collate utf8_spanish_ci default NULL,
                      `texto` text collate utf8_spanish_ci,
                      `estado` tinyint(1) unsigned NOT NULL default '1',
                      `modificado` timestamp NOT NULL default CURRENT_TIMESTAMP on update CURRENT_TIMESTAMP,
                      PRIMARY KEY  (`codigo`)
                    ) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci AUTO_INCREMENT=1 ;";
       mysql_query($sentencia);
       
       return mysql_error();
   }
   
   
   public static function ejecutar($sentencia)      //3.2.0
   {
       return mysql_query($sentencia);
   }
   
   function construir($array)
   {
       return new InformacionObjeto($array[InformacionSql::$CAMPO_IDENTIFICADOR]
                                    ,$array[InformacionSql::$CAMPO_TITULO]
                                    ,$array[InformacionSql::$CAMPO_CONTENIDO] );
   }
   
    
}
?>
<?php
    class InformacionObjeto
    {
        public $identificador = "";
        public $titulo = "";
        public $contenido = "";
        
        function InformacionObjeto($identificador , $titulo, $contenido)
        {
            $this->identificador = $identificador;
            $this->titulo = $titulo;
            $this->contenido = $contenido;
            
        }
    }
    
?>
<?php
/* VERSIONES:
Versiones:
     1.0 2008/07/18 
        Se crea la clase.
        Se a�aden los siguiente metodos:
            __consturct
            insertar SIN TERMINAR
            reconfigurar()
    1.1 2008/07/20
        Se a�aden nuevos metodos y propiedades.
    1.2 2008/07/23 
        Se a�ade nuevos metodos.
               
    2.0.1     2008/11/03
        Problema con el constructor. No es compatible con la version web
    2.0.2     2008/11/05
        Error en la presentaci�n 
    3.0.0   2009/01/03  Nueva por completo
    3.1.0   2009/01/24  
    3.1.1   2009/01/27  En una string contener el FCKeditor
    3.2.0   2009/01/27  
    3.3.0   2009/02/18  Nuevos metodos
   4.0.0   2009/03/14  Se separa en clases informacion , informacion_sql , ...
   4.1.0    2009/10/17 (+) Informacion::obtener para obtener el objeto Informaci�n     
    
        

        

        

*/
?>