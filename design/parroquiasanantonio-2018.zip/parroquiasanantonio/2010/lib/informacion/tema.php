<?php
class Tema
{
    var $sql = "";
    
    function Tema($prefijoWeb)
    {
        $this->sql = new TemaSql($prefijoWeb); 
    }
    function obtenerInformacionesOrdenadasFecha($tema)
    {
        return $this->sql->obtenerInformacionesPorTema($tema , TemaSql::$CAMPO_FECHA." DESC " );
    }
    
    function obtenerInformacionesPorTema($tema)
    {
        return $this->sql->obtenerInformacionesPorTema($tema);
    }
}
?>
<?php
class TemaSql
{
    public static $TABLA = "temario";
    
    public static $CAMPO_TEMA_ID = "id_tema";
    public static $CAMPO_INFO_ID = "id_informacion";
    public static $CAMPO_ORDEN = "orden";
    public static $CAMPO_ESTADO = "estado";    
    public static $CAMPO_FECHA = "fecha";
    
    /* Estados */
    public static $ESTADO_ACTIVO = 1;
    public static $ESTADO_INACTIVO = 0;
    
    var $tabla="";
    var $ordenar = "";
    
    function TemaSql($prefijo_tabla)
    {
        $this->tabla = $prefijo_tabla."_".TemaSql::$TABLA;
    }
    
    
    function obtenerInformacionesPorTema($tema ,$orden = "" )
    {
        if ($orden == "")
        {
            $orden = TemaSql::$CAMPO_ORDEN;
        }
        $res = mysql_query("SELECT "
                        .TemaSql::$CAMPO_INFO_ID
                        ." FROM "
                        .$this->tabla  
                        ." WHERE "
                        .TemaSql::$CAMPO_TEMA_ID
                        ." = $tema "
                        ." AND "
                        .TemaSql::$CAMPO_ESTADO
                        ." = "
                        .TemaSql::$ESTADO_ACTIVO
                        ." ORDER BY "
                        .$orden);
        
        $listado = array();
        while ($fila = mysql_fetch_array($res))
        {
            array_push($listado,$fila);
        }
        return $listado;
        
        /*
        Scripts para crear las tablas necesarias, revisar los PREFIJOS WEB "msa"
        CREATE TABLE `msa_temario` (
          `id_tema` mediumint(6) unsigned default NULL,
          `id_informacion` mediumint(6) unsigned default NULL,
          `orden` tinyint(4) NOT NULL default '0',
          `estado` tinyint(4) NOT NULL default '0',
          `fecha` timestamp NOT NULL default CURRENT_TIMESTAMP on update CURRENT_TIMESTAMP
        ) ENGINE=MyISAM DEFAULT CHARSET=latin1;
        
        CREATE TABLE `msa_tema` (
          `id_tema` mediumint(6) unsigned default NULL,
          `id_web` mediumint(6) unsigned default NULL,
          `titulo` varchar(200) default NULL,
          `texto` text,
          `color` varchar(20) default NULL,
          `size` varchar(20) default NULL,
          `alineacion` varchar(20) default NULL,
          `estado` tinyint(3) unsigned default '1',
          `fecha` timestamp NOT NULL default CURRENT_TIMESTAMP on update CURRENT_TIMESTAMP,
          `id_fondo` mediumint(6) NOT NULL default '0',
          `orden` tinyint(4) NOT NULL default '0'
        ) ENGINE=MyISAM DEFAULT CHARSET=latin1;
*/
    }
    
}
?>