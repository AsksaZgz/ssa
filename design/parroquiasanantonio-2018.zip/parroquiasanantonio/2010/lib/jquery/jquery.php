<?php
class JqueryWeb
{
    var  $rutaBase = "http://lib.asksa.es/";
    var  $directorio = "jquery/";
    var $version = "jquery.tools.min.js";
    
    
    
    function JqueryWeb($rutaBase="")
    {
        if ($rutaBase <> "")
        {
            $this->rutaBase = $rutaBase . "/";
        }
        
    }
    
    function ruta($extra="")
    {
        return $this->rutaBase.$this->directorio.$extra;
    }
    
    function headObligatorio()
    {
        return "<script src=\"".$this->ruta($this->version)."\"></script>";
    }
    
    public static function estiloEnlace($rutaArchivo)
    {
        return "<link rel=\"stylesheet\" type=\"text/css\" href=\"$rutaArchivo\"/>";        
    }
    
    public static function estilo($estilo)
    {
        return "<style>$estilo</style>";
    }
    
    
}
?>
<?php
class JqueryVentanaFlotante  extends JqueryWeb
{
    var $ventanaFlotanteEstilo = "ventana_flotante/overlay-minimal.css";
    
    public function head()
    {
        return "<script>$(function() { $(\"button[rel]\").overlay();  });</script>"
                .$this->estiloEnlace($this->ruta($this->ventanaFlotanteEstilo));
    }
    
    public static function body($cuerpo)
    {
        return "<div class=\"overlay\" id=\"overlay\">$cuerpo</div>";
        
    }
    
    public static function desencadenador($texto)
    {
        return "<button type=\"button\" rel=\"#overlay\">$texto</button> ";
    }
}


?>


<?php
class JqueryPaneles extends JqueryWeb
{
    var $panelesRuta = "paneles/";
    var $panelesEstilo = "  a:active {
                              outline:none;
                            }

                            :focus {
                              -moz-outline-style:none;
                            }
                            #products img {
                                margin:0 20px 10px 0;    
                                cursor:pointer;
                                width:80px;
                                height:80px;    
                            }

                            div.description {
                                background-color:#ff9;
                                border:2px solid #ccc;    
                                width:90%;
                                min-height:140px;
                                display:none;
                                margin-top:17px;
                                -moz-border-radius:4px;
                                padding:0 20px;
                            }

                            div.description div.arrow {
                                width:34px;
                                height:34px;
                                background:transparent url(#ruta#yellow.png) repeat scroll 0 -68px;
                                margin-top:-28px;
                                margin-left:40px;
                            }";
                            
    public function panelesEstilo()
    {
        return str_replace("#ruta#", $this->ruta($this->panelesRuta), $this->panelesEstilo);
    }
    
    public function head($paneles)
    {
        $estilo = $this->panelesEstilo();
        foreach ($paneles as $panel) {
            //depurar
            //$panel = new Panel("","","");
            $estilo .= "#".$panel->identificador." div.arrow { margin-left:".$panel->desplazamiento."px;    }";
        }
        return ""
                .$this->estilo($estilo);
    }
    
    public static function body($paneles)
    {
        foreach ($paneles as $panel) {
            //depurar
            //$panel = new Panel("","","");
            $cuerpoMenu .= "<img src=\"".$panel->rutaImagen."\" alt=\"".$panel->titulo."\" />";
            $cuerpoPaneles .= "<div class=\"description\" id=\"".$panel->identificador."\">
                                <div class=\"arrow\"></div>".$panel->cuerpo."</div>"; 
        }
        $script = " <script>    $(function() {    $(\"#products\").tabs(\"div.description\", {event:'mouseover'});    });    </script>";
        return "<div id=\"products\">$cuerpoMenu</div>$cuerpoPaneles $script";
    }
    
}

?>
   
<?php
class Panel
{
    var $identificador = "";
    var $desplazamiento = 0;
    var $cuerpo = "";
    var $rutaImagen = "";
    var $titulo = "";
    function Panel($identificador , $desplazamiento , $rutaImagen , $titulo, $cuerpo)
    {
        $this->identificador = $identificador;
        $this->desplazamiento = $desplazamiento;
        $this->rutaImagen = $rutaImagen;
        $this->titulo = $titulo;
        $this->cuerpo = $cuerpo;
    }
}
?>