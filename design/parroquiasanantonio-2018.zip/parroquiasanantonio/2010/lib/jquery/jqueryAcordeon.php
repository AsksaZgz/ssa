<?php
?>
<?php
/*
Permite crear paneles desplegables 
Como:
    Crear un objeto JqueryAcordeon
    Publicar el $HEAD en el Head de la web
    Publicar en el Body de la web $BODY_SCRIPT
    Crear los paneles con   panel()
    Unir todos los paneles con acordeon()
Ejemplo:
    www.santuariosanantonio.com "Parroquia"
Original:
    http://flowplayer.org/tools/demos/tabs/accordion.html
    
*/
class JqueryAcordeon
{
    public static $HEAD = "<script src=\"./lib/jquery/jquery.tools.min.js\"></script>
    <style type=\"text/css\">
    <!--
        /*
        body {
        padding:50px 50px;
        font-family:\"Lucida Grande\",\"Lucida Sans Unicode\",\"bitstream vera sans\",\"trebuchet ms\",verdana;
        }
        */
        /* get rid of those system borders being generated for A tags */
        a:active {
          outline:none;
        }
        :focus {
          -moz-outline-style:none;
        }
        /* root element for accordion. decorated with rounded borders and gradient background image */
        #accordion {
            background:#333 url(./lib/jquery/imagen/h300.png) 0 0;
            border:1px solid #333;    
            -background:#666;
        }
        /* accordion header */
        #accordion h2 {
            background:#ccc url(./lib/jquery/imagen/h30.png);
            margin:0;
            padding:5px 15px;
            font-size:14px;
            font-weight:normal;
            border:1px solid #fff;
            border-bottom:1px solid #ddd;
            cursor:pointer;        
        }
        /* currently active header */
        #accordion h2.current {
            cursor:default;
            background-color:#fff;
        }
       /* accordion pane */
        #accordion div.pane {
            border:1px solid #fff;
            border-width:0 2px;
            display:none;
            padding:15px;
            color:#fff;
            font-size:12px;
        }
        /* a title inside pane */
        #accordion div.pane h3 {
            font-weight:normal;
            margin:0 0 -5px 0;
            font-size:16px;
            color:#999;
        }
        -->
        </style>
    ";
    
    public static $BODY_SCRIPT = "<script>
                                \$(function() { 
                                \$(\"#accordion\").tabs(\"#accordion div.pane\", {tabs: 'h2', effect: 'slide', initialIndex: null});
                                });
                                </script>";
    
   
    function JqueryAcordeon()
    {
    }
    
    function acordeon($paneles)
    {
        return "<div id=\"accordion\">".$paneles."</div>";
    }
    
    function panel($cabecera, $titulo, $contenido, $esElPrimero=False)
    {
        $primero="";
        if ($esElPrimero == true)
        {
            $primero="class=\"current\"";
        }
        return "<h2 $primeros >$cabecera</h2>
                <div class=\"pane\">
                    <h3>$titulo</h3>
                    <p>$contenido</p>
                </div>";   
    }
}
?>