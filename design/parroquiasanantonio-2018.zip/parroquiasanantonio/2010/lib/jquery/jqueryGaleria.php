<?php
?>
<?php
/*
*@desc Crear una galeria fotografica
*@howto 
*   Crear un objeto JqueryGaleria
*   Publicar head() y body()
*   A�adir las fotografias con nuevaFoto()
*   Publicar las fotos con web() 
*/ 
class JqueryGaleria
{
    var $rutaLibreria = "./lib/jquery/";
    // Listado de objetos de fotografias
    var $galeria = array();
    
    
    
    function JqueryGaleria()
    {
    }
    /*
    *@desc Contenido de la cabecera
    */
    function head()
    {
        return JqueryGaleriaAyuda::head($this->rutaLibreria);
    }
    /*
    *@desc Contenido del cuerpo 
    */
    function body()
    {
        return JqueryGaleriaAyuda::body();
    }
    /*
    *@desc Publicar la galeria
    */
    function web($anchura="200")
    {
        $pre = "
            <div id=\"image_wrap\">      
                <!-- Initially the image is a simple 1x1 pixel transparent GIF -->     
                <img src=\"/tools/img/blank.gif\" width=\"$anchura\"  />  
            </div>
            <a class=\"prevPage browse left\"></a>
            <!-- root element for scrollable -->
            <div class=\"scrollable\">    
                
                <!-- root element for the items -->
                <div class=\"items\">";
        $post = "               
                </div>
                
            </div>

            <!-- \"next page\" action -->
            <a class=\"nextPage browse right\"></a>

            <br clear=\"all\" />";
        $contenidoGaleria = "";    
        foreach ($this->galeria as $foto) {
            $contenidoGaleria.=$foto->enlace();
        }
        
        return $pre.$contenidoGaleria.$post;
    }
    /*
    *@desc A�adir fotografia a la galer�a
    *@param $rutaImagen ruta de la imagen
    *@param $comentario comentario de la imagen
    */
    function nuevaFoto($rutaImagen , $comentario = "")
    {
        $foto = new JqueryGaleriaObjeto($rutaImagen, $comentario);
        array_push($this->galeria , $foto);
    }
    
}
?>
<?
class JqueryGaleriaObjeto
{
    var $rutaImagen ="";
    var $comentario ="";
    
    function JqueryGaleriaObjeto($rutaImagen , $comentario)
    {
        $this->rutaImagen = $rutaImagen;
        $this->comentario = $comentario;
    }
    
    function enlace()
    {
        return "<img src=\"".$this->rutaImagen."\" />";
    }
    
}
?>
<?php
class JqueryGaleriaAyuda
{
    public static function head($rutaLibreria)
    {
        return JqueryGaleriaAyuda::headScript($rutaLibreria).JqueryGaleriaAyuda::estilo($rutaLibreria);
    }
    
    public static function body()
    {
        return JqueryGaleriaAyuda::bodyScript();
    }
    
    public static function headScript($rutaLibreria)
    {
        return "<script src=\"$rutaLibreria/jquery.tools.min.js\"></script>";
    }
    
    public static function bodyScript()
    {
        return "
        <!-- javascript coding -->


        <script>
        // execute your scripts when the DOM is ready. this is a good habit
        $(function() {

            // initialize scrollable
            $(\"div.scrollable\").scrollable();

        });
        </script>




        <script>
        $(function() {

        $(\".items img\").click(function() {

            // calclulate large image's URL based on the thumbnail URL (flickr specific)
            var url = $(this).attr(\"src\").replace(\"_t\", \"\");

            // get handle to element that wraps the image and make it semitransparent
            var wrap = $(\"#image_wrap\").fadeTo(\"medium\", 0.5);

            // the large image from flickr
            var img = new Image();

            // call this function after it's loaded
            img.onload = function() {

                // make wrapper fully visible
                wrap.fadeTo(\"fast\", 1);

                // change the image
                wrap.find(\"img\").attr(\"src\", url);

            };

            // begin loading the image from flickr
            img.src = url;

        // when page loads simulate a \"click\" on the first image
        }).filter(\":first\").click();
        });
        </script>";
    }
    public static function estilo($rutaLibreria)
    {
        return "<style>
                    /* styling for the image wrapper  */
                    #image_wrap {
                        /* dimensions */
                        width:677px;
                        margin:15px 0 15px 40px;
                        padding:15px 0;

                        /* centered */
                        text-align:center;

                        /* some \"skinning\" */
                        background-color:#efefef;
                        border:2px solid #fff;
                        outline:1px solid #ddd;
                        -moz-ouline-radius:4px;
                    }
                    /*
                    body {
                        padding:50px 50px;
                        font-family:\"Lucida Grande\",\"Lucida Sans Unicode\",\"bitstream vera sans\",\"trebuchet ms\",verdana;
                    }
                    */
                    /* get rid of those system borders being generated for A tags */
                    a:active {
                      outline:none;
                    }

                    :focus {
                      -moz-outline-style:none;
                    }
                    
                    /*
                        root element for the scrollable.
                        when scrolling occurs this element stays still.
                    */
                    .scrollable {

                        /* required settings */
                        position:relative;
                        overflow:hidden;
                        width: 680px;
                        height:120px;

                        /* custom decorations */
                        border:1px solid #ccc;
                        background:url($rutaLibreria/imagen/h300.png) repeat-x;
                    }

                    /*
                        root element for scrollable items. Must be absolutely positioned
                        and it should have a extremely large width to accomodate scrollable items.
                        it's enough that you set the width and height for the root element and
                        not for this element.
                    */
                    .scrollable .items {
                        /* this cannot be too large */
                        width:20000em;
                        position:absolute;
                        clear:both;
                    }

                    /* single scrollable item */
                    .scrollable img {
                        float:left;
                        margin:20px 5px 20px 21px;
                        background-color:#fff;
                        padding:2px;
                        border:1px solid #ccc;
                        cursor:pointer;
                        width:100px;
                        height:75px;
                        
                        -moz-border-radius:4px;
                        -webkit-border-radius:4px;
                    }

                    /* active item */
                    .scrollable .active {
                        border:2px solid #000;
                        z-index:9999;
                        position:relative;
                    }
                    
                    /* this makes it possible to add next button beside scrollable */
                    .scrollable {
                        float:left;    
                    }

                    /* prev, next, prevPage and nextPage buttons */
                    a.browse {
                        background:url($rutaLibreria/imagen/hori_large.png) no-repeat;
                        display:block;
                        width:30px;
                        height:30px;
                        float:left;
                        margin:40px 10px;
                        cursor:pointer;
                        font-size:1px;
                    }

                    /* right */
                    a.right                 { background-position: 0 -30px; clear:right; margin-right: 0px;}
                    a.right:hover         { background-position:-30px -30px; }
                    a.right:active     { background-position:-60px -30px; } 


                    /* left */
                    a.left                { margin-left: 0px; } 
                    a.left:hover          { background-position:-30px 0; }
                    a.left:active      { background-position:-60px 0; }

                    /* up and down */
                    a.up, a.down        { 
                        background:url($rutaLibreria/imagen/vert_large.png) no-repeat; 
                        float: none;
                        margin: 10px 50px;
                    }

                    /* up */
                    a.up:hover          { background-position:-30px 0; }
                    a.up:active          { background-position:-60px 0; }

                    /* down */
                    a.down                 { background-position: 0 -30px; }
                    a.down:hover          { background-position:-30px -30px; }
                    a.down:active      { background-position:-60px -30px; } 


                    /* disabled navigational button */
                    a.disabled {
                        visibility:hidden !important;        
                    }     




                    
                </style>
        ";
    }
    
     
}
?>