<?php
include_once("web.php");
?>

<?php
class Parametro
{
    var $traza = false;
    /**
    * @desc cadena que contiene los parametros que se van a utilizar
    */
    var $parametro = array();
    // Ejemplo: index.php?ref=...
    var $referencia = "ref";
    
    /**
    * @desc Prefijo para los parametros
    * 
    * @ver 2.0.0
    */
    var $paramPrefijo ="&";
    /**
    * @desc Separador del par nombre  valor
    * 
    * @ver 2.0.0
    */
    var $paramIntermedio = "=";
    
    /**
    * @desc Sufijo de los parametros
    * 
    * @ver 2.0.0
    */
    var $paramSufijo = "";
    // Ejemplo: &nombre=valor
    
    /**
    * @desc Prepara el formato de un parametro
    * 
    * @ver 2.0.0
    */
    public function montar($nombre, $valor)
    {
        return   $this->paramPrefijo.$nombre.$this->paramIntermedio.$valor.$this->paramSufijo;
    }
    /**
    * @desc Gestiona un parametro
    * 
    * @ver 2.0.0
    */
    public function valor($nombre, $valor="" , $borrar=false)
    {
        if ($borrar)
        {
            unset($this->parametro[$nombre]);
            $salida = true;
        } else {
            if ($valor<>"")
            {
                $this->parametro[$nombre]=$valor;    
            }
            $salida = $this->parametro[$nombre]; 
        }
        return $salida;
    }
    
    
    /**
    * @desc Parametro Orden
    * 
    * @ver 2.0.0
    */
    public function orden($orden = "", $borrar = false)
    {
        return $this->valor("orden",$orden,$borrar);
    }
    
    /**
    * @desc Parametro Suborden
    * 
    * @ver 2.0.0
    */
    public function suborden($suborden="",$borrar = false)
    {
        return $this->valor("suborden",$suborden,$borrar);
    }
    
    /**
    * @desc Parametro Codigo
    * 
    * @ver 2.0.0
    */
    public function codigo($valor="",$borrar = false)
    {
        return $this->valor("codigo",$valor,$borrar);
    }
    
    /**
    * @desc Parametro Usuario
    * 
    * @ver 2.0.0
    */
    public function usuario($valor="",$borrar = false)
    {
        return $this->valor("usuario",$valor,$borrar);
    }
    
    /**
    * @desc Parametro ruta
    * 
    * @param valor del parametro ruta
    * @param True: borra el parametro
    * 
    * @ver 2.0.0
    */
    public function ruta($valor="",$borrar = false)
    {
        return $this->valor("ruta",$valor,$borrar);
    }
    
    /**
    * @desc Recupera el listado de parametros
    * 
    * @ver 2.0.0
    */
    public function recuperar()
    {
        $this->desencriptar(web::recoger($this->referencia));
    }
    
    /**
    * @desc Devuelve los parametro para ser utilizados libremente
    * 
    * @ver 2.0.0
    */
    public function ver()
    {
        return $this->encriptar();
    }
    
    /**
    * @desc Devuelve los parametros para utilizarlos en un enlace
    * 
    * @ver 2.0.0
    */
    public function enlace($pagina = "index.php")
    {
        return $pagina."?".$this->referencia."=".$this->ver();
    }
    
    
    /**
    * @desc Asigna un valor a un parametro existente
    * 
    * @ver 2.0.0
    */
    public function asignar($nombreParametro , $valor)
    {
        $this->parametro[$nombreParametro] = $valor;
    }
    
    /**
    * @desc Existe el parametro (T|F)
    * 
    * @ver 2.0.0
    */
    public function existe($nombre)
    {
        return ($this->valor($nombre) <> "");
    }
    /**
    * @desc Encripta la cadena de parametros
    * 
    * @ver 2.0.0
    */
    private function encriptar() 
    {
        foreach ($this->parametro as $key=>$value) 
        {
            $salida .= $this->montar($key,$value);
        }
        if (!($this->traza))
        {
            $salida = base64_encode($salida);
        } 
        return $salida;
    }
    
    /**
    * @desc Desencripta
    * 
    * @param Cadena para transformar en un array
    * 
    * @ver 2.0.0 
    */
    public function desencriptar($cadena) 
    {
        if(!$this->traza)
        {
            $salida = base64_decode($cadena);
        }
        parse_str($salida , $this->parametro);
    }
    
}
?>

<?php
/**
* @desc Clase que permite tratar los parametros
*/
class ParametroObsoleto
{
    var $traza = true;
    /**
    * @desc cadena que contiene los parametros que se van a utilizar
    */
    var $parametros = "";
    var $param = array();
    // Ejemplo: index.php?ref=...
    var $referencia = "ref";
    
    /**
    * @desc Prefijo para los parametros
    * 
    * @ver 1.0.0
    */
    var $paramPrefijo ="&";
    /**
    * @desc Separador del par nombre  valor
    * 
    * @ver 1.0.0
    */
    var $paramIntermedio = "=";
    /**
    * @desc Sufijo de los parametros
    */
    var $paramSufijo = "";
    // Ejemplo: &nombre=valor
    
    /**
    * @desc Llave para la encriptaci�n
    * 
    * @ver 1.0.0
    */
    private $llave = "123456789";
    
    /**
    * @desc Prepara el formato de un parametro
    * 
    * @ver 1.1.0
    */
    public function montar($nombre, $valor)
    {
        return   $this->paramPrefijo.$nombre.$this->paramIntermedio.$valor.$this->paramSufijo;
    }
    /**
    * @desc A�ade un nuevo parametro
    * 
    * @ver 1.0.0
    */
    public function nuevo($nombre, $valor="" , $borrar = false)
    {
        if ($valor <> "")
        {
            $this->parametros .=  $this->montar($nombre, $valor);
        }
        return $this->valor($nombre, $borrar);
        
    }
    
    public function nuevo2($nombre , $valor)
    {
        $this->param[$nombre]=$valor;
    }
    
    /**
    * @desc A�ade el parametro Orden
    * 
    * @ver 1.0.0
    */
    public function orden($orden = "", $borrar = false)
    {
        return $this->nuevo("orden",$orden,$borrar);
    }
    
    /**
    * @desc A�ade el parametro Suborden
    * 
    * @ver 1.0.0
    */
    public function suborden($suborden="",$borrar = false)
    {
        return $this->nuevo("suborden",$suborden,$borrar);
    }
    
    /**
    * @desc  A�ade el parametro Codigo
    * 
    * @ver 1.0.0
    */
    public function codigo($valor="",$borrar = false)
    {
        return $this->nuevo("codigo",$valor,$borrar);
    }
    
    /**
    * @desc A�ade el parametro Usuario
    * 
    * @ver 1.0.0
    */
    public function usuario($valor="",$borrar = false)
    {
        return $this->nuevo("usuario",$valor,$borrar);
    }
    
    public function ruta($valor="",$borrar = false)
    {
        return $this->nuevo("ruta",$valor,$borrar);
    }
    
    /**
    * @desc Recupera el listado de parametros
    * 
    * @ver 1.0.0
    */
    public function recuperar()
    {
        $this->parametros = $this->desencriptar(web::recoger($this->referencia));
    }
    
    /**
    * @desc Devuelve los parametro para ser utilizados libremente
    * 
    * @ver 1.0.0
    */
    public function ver()
    {
        return $this->encriptar($this->parametros);
    }
    
    /**
    * @desc Devuelve los parametros para utilizarlos en un enlace
    * 
    * @ver 1.0.0
    */
    public function enlace($pagina = "index.php")
    {
        return $pagina."?".$this->referencia."=".$this->ver();
    }
    
    /**
    * @desc Recupera el valor de un parametro concreto
    * 
    * @param Nombre del parametro que se quiere recuperar
    * 
    * @ver 1.1.0
    */
    public function valor($nombreParametro, $borrar = false)
    {
        //$aux = $this->parametros;
        //str_replace("zz" , "&", $aux);
        //str_replace("xx" , "=", $aux);
        parse_str($this->parametros, $salida);
        if ($borrar)
        {
            $this->parametros = str_replace( $this->montar($nombreParametro,$salida[$nombreParametro]), "" , $this->parametros);
        }
        return $salida[$nombreParametro];
    }
    
    /**
    * @desc Borra un parametro de la lista de parametros
    * 
    * @ver 1.1.0
    */
    public function borrar($nombreParametro)
    {
        $this->valor($nombreParametro , true);
    }
    
    /**
    * @desc Asigna un valor a un parametro existente
    * 
    * @ver 1.1.0
    */
    public function asignar($nombreParametro , $valor)
    {
        $this->valor($nombreParametro,true);
        $this->nuevo($nombreParametro, $valor);
    }
    
    /**
    * @desc Existe el parametro (T|F)
    * 
    * @ver 1.1.0
    */
    public function existe($nombre)
    {
        return ($this->valor($nombre) <> "");
    }
    /**
    * @desc Encripta la cadena de parametros
    * 
    * @ver 1.0.0
    */
    private function encriptar($salida) 
    {
        $salida = str_replace($this->paramPrefijo,"zzz",$salida);
        $salida = str_replace($this->paramIntermedio,"xxx",$salida);
        if (!($this->traza))
        {
            $salida = base64_encode($salida);
        }
        return $salida;
    }
    
    /**
    * @desc Desencripta
    * 
    * @ver 1.0.0 
    */
    private function desencriptar($salida) 
    {
        
        if(!$this->traza)
        {
            $salida = base64_decode($salida);
        }
        $salida = str_replace("zzz",$this->paramPrefijo,$salida);
        $salida = str_replace("xxx",$this->paramIntermedio,$salida);
        return $salida;
    }
    
}

?>

<?php

/*
VERSION     FECHA       COMENTARIO
----------- ----------- ----------------------------------------------------------------
1.0.0       20090607    Primeros metodos.  
1.1.0       20090608    Nuevos metodos.
2.0.0       20090613    Se emplea un array en vez de una cadena
*/
?>


