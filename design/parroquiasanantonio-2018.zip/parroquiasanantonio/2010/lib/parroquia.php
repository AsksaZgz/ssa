<?php
include_once("parametro.php"); 
include_once("web.php");  
?>
<!-- P1 -->
<?php
class Parroquia
{
    public static $PREFIJO ="PSA";
    public static $INFO_TEMA_TABLA="PSA_tema";
    public static $INFO_TEMARIO_TABLA="PSA_temario";
    
    public static $INICIO = "index.php";
    public static $TITULO  = "Parroquia de San Antonio";
    
    public $menuHistoria = "";
    public $menuDevocion = "";
    public $menuEucaristias = "";
    
    public function Parroquia()
    {
         
    }
   
 
}
?>
<!-- P2 -->
<?php
class ParroquiaMenu
{
    public $cuerpo = "";
    public $orden = "";
    public $suborden = "";
    public $usuario = "";
    
    public function ParroquiaMenu($cuerpo , $orden, $suborden = "", $usuario = "")
    {
        $this->cuerpo = $cuerpo;
        $this->orden = $orden;
        $this->suborden = $suborden;
        $this->usuario = $usuario;
        
    }
    public function enlace()
        {
            $parametros = new Parametro();
            $parametros->orden($this->orden);
            $parametros->suborden($this->suborden);
            $parametros->usuario($this->usuario);
            $separador = "&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;";
            $ruta  = $parametros->enlace(Parroquia::$INICIO);
            return WebEnlace::normal($this->cuerpo,$ruta,"navText").$separador;
        }
}
?>