<?php
/*      IDEA
TABLA xxx_tabla
COLUMNAS    

METODOS     
*/ 
               
/*
PENDIENTE
Campos de texto con longitud, texto_100 o pasarle la longitud como variable
�Merece la pena dividirlo en clases , web_tabla , web_enlace, ... ?
VERSION     FECHA       COMENTARIO
---------- ----------- ----------------------------------------------------------------
3.0.0       20090506    Objeto formulario, formulario archivo ....
2.0.1       2009/04/25  Matiz de metodos
2.0.0      14/04/2009   Nueva clase
1.5.0      18/03/2009   Nuevos metodos (desplegable y textos)
1.4.0      14/03/2009   Nuevos metodos para tablas.   
1.3.0      04/03/2009   Metodos nuevos.           
1.2.0      17/02/2009   Nuevos Metodos y actualizaci�n
1.1.0      11/02/2009   Nuevos Metodos  
*/
class Web
{
    /// PROPIEDADES //////////////////////////////////////////////////////////////////////
    
    /// PARAMETROS //////////////////////////////////////////////////////////////////////
    /**
    * @desc Recoge el parametro Orden
    */
    public static function recogerOrden()
    {
        return Web::recoger("orden");
    }
    /**
    * @desc Recoge el parametro Suborden
    */
    public static function recogerSubOrden()
    {
        return Web::recoger("suborden");
    }
    
    /**
    * @desc Recoge el parametro Codigo
    */
    public static function recogerCodigo()
    {
        return Web::recoger("codigo");
    }
    
    /**
    * @desc Recoge el parametro Extra
    */
    public static function recogerExtra()
    {
        return Web::recoger("extra");
    }
    /**
    * @desc Recupera el parametro seleccionado
    * 
    * @param nombre del parametro a recuperar.
    */
    public static function recoger($nombre_parametro) //1.1.0
    {
        $valor = $_POST[$nombre_parametro];
        if  (is_null($valor))
        {
            $valor = $_GET[$nombre_parametro];
        }
        return $valor;
    }
    
        public static function parametros($lista_parametros)  //1.3.0
    {
        $primero = true;
        $salida = "?";
        foreach( $lista_parametros as $nombre => $valor)
        {
            if ($primero)
            {
                $primero = false;
            } else {
                $salida .="&";
            }
            $salida .= $nombre."=".$valor;
        }
        return $salida;
    }
    
    /// FORMULARIOS //////////////////////////////////////////////////////////////////////
    // web_formulario->formulario
    public static function formulario($cuerpo_formulario = "" , $volver = "index.php" , $metodo = "post", $para_fichero = False) //1.1.0 , 1.2.0
    {
        
        if ($para_fichero)
        {
            $fichero = "enctype=\"multipart/form-data\"";
        } else
        {
            $fichero ="";
        }
        
        return "<form id=\"frm_formulario\" name=\"frm_formulario\" $fichero method=\"$metodo\" action=\"$volver\">
                $cuerpo_formulario
                </form>"; 
        
    }
    
    public static function formulario_fichero($cuerpo_formulario = "" , $volver = "index.php" , $metodo = "post")  //1.2.0
    {
        return Web::formulario($cuerpo_formulario, $volver , $metodo , True);
    }
    ///// CONJUNTOS ///////////////////////////////////////////////////////////////////////
    public static function conjunto($titulo, $cuerpo)   //1.5.0
    {
        return "<fieldset><legend>$titulo</legend>$cuerpo</fieldset>";
    }
    
    //// DESPLEGABLE //////////////////////////////////////////////////////////////////////
    public static function desplegable(  $listado, $orden, $etiqueta_listado, $enviar_texto , $volver_url)  //1.5.0
    {
        $salida = "<select name=\"listado_id\" id=\"listado_id\" accesskey=\"l\">";
        foreach ($listado as $clave => $valor) {
            $salida .= "<option value=\"$clave\">$valor</option>";
        }
        $salida .="</select>";
        $salida .= web::oculto_orden($orden);
     $salida .= web::etiqueta($etiqueta_listado.web::boton($enviar_texto));
     return web::formulario($salida,$volver_url) ;
    }
	
  
    /// TABLAS /////////////////////////////////////////////////////////////////////////////
    public static function tabla($cuerpo = ""  , $nombre_id = "" , $borde = 0 , $titulo = "")   //1.4.0
    {
        $tabla = "<table border=\"$borde\" id=\"$nombre_id\" cellspacing=\"5\" cellpadding=\"5\" >";
        if ($titulo <> "")
        {
            $tabla .= "<caption>$titulo</caption>";
        } 
        if ($cuerpo == "")
        {
            $cuerpo = Web::tabla_fila(Web::tabla_columna("Listado vacio."));
        }
        $tabla .= $cuerpo."</ table>";
        
        return $tabla;
    }
    
    public static function tabla_fila($columnas)        //1.4.0
    {
        return "<tr>".$columnas."</tr>";
    }
    
    public static function tabla_columna($celda , $es_cabecera=false)   //1.4.0
    {
        if ($es_cabecera)
        {
            return "<th>$celda</td>";
        } else {
            return "<td>".$celda."</td>";
        }
    }
    
    /// BOTONES ////////////////////////////////////////////////////////////////////////////
    public static function ok($texto_boton = "Aceptar")  //1.1.0 , 1.2.0
    {
        return Web::boton($texto_boton);
    }
    
    public static function boton($texto_boton, $tipo = "submit")    //1.2.0  //1.5.0
    {
        return "<input type=\"$tipo\" value=\"$texto_boton\" />";
    }
    
    /// CAMPOS DE TEXTO ////////////////////////////////////////////////////////////////////
    public static function etiqueta($contenido)   //1.5.0
    {
        return "<label>$contenido</label>";
    }
    
    public static function texto($nombre = "" , $valor = "",  $lineas=1, $etiqueta="")   //1.5.0
    {
        if ($lineas == 1)
        {
            $salida =  "<input type=\"text\" name=\"$nombre\" value=\"$valor\"/>";    
        } else {
            $salida = "<textarea name=\"$nombre\" rows=\"$lineas\">$valor</textarea>";
        }
        if ($etiqueta <> "")
        {
            $salida = web::etiqueta($etiqueta.$salida);
        }
        return $salida;
    }
    
    public static function texto_mini($nombre = "" , $valor = "", $numero_caracteres=1, $etiqueta="")   //1.5.0
    {
        $salida =  "<input type=\"text\" name=\"$nombre\" value=\"$valor\" size=\"$numero_caracteres\" maxlength=\"$numero_caracteres\" />";
        if ($etiqueta <> "")
        {
            $salida = web::etiqueta($etiqueta.$salida);
        }
        return $salida;
    }
    
    
    //// ENLACES ///////////////////////////////////////////////////////////////////////////
    public static function enlace($cuerpo_enlace, $ruta , $clase = "" , $ventana_destino = "")
    {
        return "<a  href=\"$ruta\" target=\"$ventana_destino\" 
                            class=\"$clase\">
                            $cuerpo_enlace
                        </a>";
    }
    
    public static function enlace_orden($cuerpo_enlace ,$orden = "", $suborden = "" , $codigo ="" , $clase = "", $volver="index.php" )
    {
        $ruta = "$volver?orden=$orden&suborden=$suborden&codigo=$codigo";
        
        return Web::enlace($cuerpo_enlace ,$ruta , $clase );
    }
    
    public static function enlace_nueva($cuerpo_enlace , $ruta , $clase = "")
    {
        return Web::enlace($cuerpo_enlace , $ruta , $clase , "_blank");
        
    }
    
    /// CAMPOS OCULTOS /////////////////////////////////////////////////////////////////////
    public static function oculto($nombre = "", $valor = "")
    {
        return "<input name=\"$nombre\" type=\"hidden\" id=\"$nombre\" value=\"$valor\">";
    }
    
    public static function oculto_orden( $valor = "")
    {
        return Web::oculto("orden",$valor);
    }
    
    public static function oculto_suborden( $valor = "")
    {
        return Web::oculto("suborden",$valor);
    }
    
    public static function oculto_codigo( $valor = "")
    {
        return Web::oculto("codigo",$valor);
    }
    
    public static function oculto_grupo( $valor = "")
    {
        return Web::oculto("grupo",$valor);
    }
     
    /// FICHEROS /////////////////////////////////////////////////////////////////////////////
    
    // Genera el tag para subir ficheros
    public static function fichero($etiqueta = "", $nombre = "userfile" , $maximo_MB=2)   //1.1.0 //1.2.0
    {
        $fichero = Web::oculto("MAX_FILE_SIZE",$maximo_MB*1024*1024)
                ."<input name=\"$nombre\" type=\"file\">";
        if ($etiqueta <> "")
        {
            $fichero = Web::etiqueta($etiqueta.$fichero);
        }                        
        return $fichero;
    }
    
     /// METODOS CON ESTILOS ////////////////////////////////////////////////////////////////////
    public static function estilo($archivo_estilo)
    {
        return "<link href=\"$archivo_estilo\" rel=\"stylesheet\" type=\"text/css\" /> ";
    }
    
    public static function espacio($numero_espacios=1)
    {
        
        for($i=0;$i<=$numero_espacios;$i++){
            $espacio .= "&nbsp;";
        }
        return $espacio;
    }
    
    /// METODOS OBSOLETOS //////////////////////////////////////////////////////////////////////
}
?>
<?php
class webImagen
{
    public static function normal($ruta , $borde = 0, $alineacion = "" )
    {
        return "<img src=\"$ruta\" border=\"$borde\" align=\"$alineacion\"   >";
    }
    
    public static function centrada($ruta, $borde = 0)
    {
        return webImagen::normal($ruta, $borde , webEstilo::alineacionCentrada());
    }
}

?>
<?php
class webEstilo
{
    public static function alineacionCentrada() { return "middle"; }
    
}
?>
<?php
class web_enlace
{
        //// ENLACES ///////////////////////////////////////////////////////////////////////////
    public static function normal($cuerpo_enlace, $ruta , $clase = "" , $ventana_destino = "_self")
    {
        return "<a  href=\"$ruta\" target=\"$ventana_destino\" 
                            class=\"$clase\">
                            $cuerpo_enlace
                        </a>";
    }
    
    public static function orden($cuerpo_enlace ,$orden = "", $suborden = "" , $codigo ="" , $clase = "", $volver="index.php" )
    {
        $ruta = "$volver?orden=$orden&suborden=$suborden&codigo=$codigo";
        
        return Web_enlace::normal($cuerpo_enlace ,$ruta , $clase );
    }
    
    public static function nueva($cuerpo_enlace , $ruta , $clase = "")
    {
        return Web_enlace::normal($cuerpo_enlace , $ruta , $clase , "_blank");
        
    }
    
    public static function correo($cuerpo, $direccion, $clase = "" , $rutaImagen = "")
    {
        $ruta = "mailto:".$direccion;
        if ($rutaImagen <> "")
            $cuerpo = "<img src=\"$rutaImagen\" alt=\"$cuerpo\" width=\"20\" border=\"0\" />";
        
        return web_enlace::normal($cuerpo, $ruta , $clase );
    }
    
    
    
}
?>
<?php
class WebEnlace
{
        //// ENLACES ///////////////////////////////////////////////////////////////////////////
    public static function normal($cuerpo_enlace, $ruta , $clase = "" , $ventana_destino = "_self" )
    {
        return "<a  href=\"$ruta\" target=\"$ventana_destino\" 
                            class=\"$clase\">
                            $cuerpo_enlace
                        </a>";
    }
    
    public static function orden($cuerpo_enlace ,$orden = "", $suborden = "" , $codigo ="" , $extra = "", $clase = "", $volver="index.php" )
    {
        $ruta = "$volver?orden=$orden&suborden=$suborden&codigo=$codigo&extra=$extra";
        
        return Web_enlace::normal($cuerpo_enlace ,$ruta , $clase );
    }
    
    public static function nueva($cuerpo_enlace , $ruta , $clase = "")
    {
        return Web_enlace::normal($cuerpo_enlace , $ruta , $clase , "_blank");
        
    }
    
    public static function correo($cuerpo, $direccion, $clase = "" , $rutaImagen = "")
    {
        $ruta = "mailto:".$direccion;
        if ($rutaImagen <> "")
            $cuerpo = "<img src=\"$rutaImagen\" alt=\"$cuerpo\" width=\"20\" border=\"0\" />";
        
        return web_enlace::normal($cuerpo, $ruta , $clase );
    }
    
    
    
}
?>


<?php   //2.0.0
class Formulario_web
{
    public static function formulario($cuerpo_formulario = "" , $volver = "index.php" , $metodo = "post", $para_fichero = False) //1.1.0 , 1.2.0
    {
        
        if ($para_fichero)
        {
            $fichero = "enctype=\"multipart/form-data\"";
        } else
        {
            $fichero ="";
        }
        
        return "<form id=\"frm_formulario\" name=\"frm_formulario\" $fichero method=\"$metodo\" action=\"$volver\">
                $cuerpo_formulario
                </form>"; 
        
    }  
    
    public static function check($identificador , $etiqueta , $seleccionado = false , $tecla = "", $orden = "")
    {    
        $esta_seleccionado = "";
        if ($seleccionado)
        {
            $esta_seleccionado = "checked=\"checked\"";
            
        }
        if ($tecla <> "")
        {
            $tecla = "accesskey=\"$tecla\"";
        }
        if ($orden <> "")
        {
            $orden = "tabindex=\"$orden\"";
        }
        $check =   "<input type=\"checkbox\" name=\"$identificador\" id=\"$identificador\" $tecla $orden $esta_seleccionado />";
        if ($etiqueta<>"")
        {
             $check = "<label>$check $etiqueta</label>";
        }
        return   $check;
    }
    
    public static function fichero($orden,$titulo_pantalla,$etiqueta_busqueda,$megas = 2)
    {
        $fichero = Web::fichero($etiqueta_busqueda,"userfile",$megas)
                    .Web::ok("A�adir")
                    .Web::oculto_orden($orden);
        $fichero = web::conjunto($titulo_pantalla, $fichero);
        return Formulario_web::formulario($fichero, "index.php","post",true);
    }
    
    public static function fichero_titulo(&$formularioArchivo)    //3.0.0
    {
        //Solo para edici�n 
        //$formularioArchivo = new FormularioArchivo();
        $fichero = $formularioArchivo->contenido_previo.$fomularioArchivo->titulo;
        if ($formularioArchivo->nombreArchivo_etiqueta <> "")
        {
            $fichero .= ""; //datos del titulo del archivo
        }
        $fichero .= Web::fichero($formularioArchivo->archivo_etiqueta,$formularioArchivo->archivo_nombre,$formularioArchivo->archivo_MaximoMB)
                    .Web::ok($formularioArchivo->botonEnviar_texto)
                    .Web::oculto_orden($formularioArchivo->orden)
                    .Web::oculto_suborden($formularioArchivo->suborden)
                    .web::oculto_codigo($formularioArchivo->codigo);
        $fichero = web::conjunto($formularioArchivo->titulo, $fichero);
        return Formulario_web::formulario($fichero, $formularioArchivo->paginaDestino,$formularioArchivo->envioFormulario_Post_Get,true);
        
    }
}
?>
<?php
class Formulario  //3.0.0
{
    var $titulo = "";
    var $orden = "";
    var $suborden = "";
    var $codigo = "";
    var $paginaDestino = "";
    var $envioFormulario_Post_Get = "POST";
    var $contenido_previo = "";
    
    var $botonEnviar_texto = "Enviar";
}
?>
<?php
class FormularioArchivo extends Formulario  //3.0.0
{
    var $nombreArchivo_etiqueta = "";
    var $nombreArchivo_texto = "";
    
    var $archivo_etiqueta = "";
    var $archivo_rutaTmp = "";
    var $archivo_MaximoMB = 2;
    var $archivo_nombre = "userfile";
    
    public function tieneTituloArchivo()
    {
        $tieneTituloArchivo = False;
        if ($this->nombreArchivo_etiqueta <> "")
            $tieneTituloArchivo = True;
        return $tieneTituloArchivo;
            
    }
    
}
?>
<?php
class FormularioWeb
{
    /**
    * @desc Formulario para un fichero con titulo.
    */
    public static function ficheroTitulo(&$formularioArchivo)    //3.0.0
    {
        //Solo para edici�n 
        //$formularioArchivo = new FormularioArchivo();
        $fichero = $formularioArchivo->contenido_previo."<br/>";
        if ($formularioArchivo->nombreArchivo_etiqueta <> "")
        {
            $fichero .= ""; //datos del titulo del archivo
        }
        $fichero .= Web::fichero($formularioArchivo->archivo_etiqueta,$formularioArchivo->archivo_nombre,$formularioArchivo->archivo_MaximoMB)
                    .Web::ok($formularioArchivo->botonEnviar_texto)
                    .Web::oculto_orden($formularioArchivo->orden)
                    .Web::oculto_suborden($formularioArchivo->suborden)
                    .web::oculto_codigo($formularioArchivo->codigo);
        $fichero = web::conjunto($formularioArchivo->titulo, $fichero);
        return Formulario_web::formulario($fichero, $formularioArchivo->paginaDestino,$formularioArchivo->envioFormulario_Post_Get,true);
        
    }
    
}

?>
<?php // 2.0.0
class Web_texto
{
    public static function etiqueta($contenido)   //1.5.0
    {
        return "<label>$contenido</label>";
    }
    
    public static function normal($nombre = "" , $valor = "", $etiqueta_delante="" , $etiqueta_detras="" ,  $lineas=1 ) 
    {
        if ($lineas == 1)
        {
            $salida =  "<input type=\"text\" name=\"$nombre\" value=\"$valor\"/>";    
        } else {
            $salida = "<textarea name=\"$nombre\" rows=\"$lineas\">$valor</textarea>";
        }
        if (($etiqueta_delante <> "") || ($etiqueta_detras <>""))
        {
            $salida = web::etiqueta($etiqueta_delante.$salida.$etiqueta_detras);
        }
        return $salida;
    }
    
    public static function mini($nombre = "" , $valor = "", $etiqueta_delante="" , $etiqueta_detras="", $numero_caracteres=1)  
    {
        $salida =  "<input type=\"text\" name=\"$nombre\" value=\"$valor\" size=\"$numero_caracteres\" maxlength=\"$numero_caracteres\" />";
        if (($etiqueta_delante <> "") || ($etiqueta_detras <>""))
        {
            $salida = web::etiqueta($etiqueta_delante.$salida.$etiqueta_detras);
        }
        return $salida;
    }
}

?>
<?php
/**
* @desc Clase que almacena un parametro
*/
/*
class Parametro
{
    public static $nombre = "";
    public static $valor = "";
    
    public function Parametro($nombre = "", $valor = "")
    {
        $this->nombre = $nombre;
        $this->valor = $valor;
    }
    
}
*/
?>
