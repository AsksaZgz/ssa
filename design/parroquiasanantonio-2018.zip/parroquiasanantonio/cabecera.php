 
<div id="header">
          
          <ul class="topLinks">
            <li>
              <a href="<?php $menuEvangelio->enlace(); ?>">
                Evangelio
              </a>
            </li>

			<li>
              <a href="<?php $menuObraSocial->enlace();?>" style="float: right">
                Hoja Parroquial
              </a>
            </li>

          </ul>
          
          <h1 id="logo">
          <a href="index.php">Parroquia de San Antonio</a>
          </h1>
          <ul class="globalRootMenu headNav">
            <li class="hasChildren">
              <a class="hasChildren" href="http:\\www.santuariosanantonio.com">
                Santuario
              </a>
            </li>
			<li class="<?php ParroquiaMenu::seleccionarMenu($orden,"");?>">
              <a class="<?php ParroquiaMenu::seleccionarMenu($orden,"");?>" href="index.php">
                Inicio
              </a>
            </li>
			<li class="<?php ParroquiaMenu::seleccionarMenu($orden,$menuEvangelio->orden);?>">
              <a class="<?php ParroquiaMenu::seleccionarMenu($orden,$menuEvangelio->orden);?>" href="<?php $menuEvangelio->enlace(); ?>">
                Evangelio
              </a>
            </li>
            <li class="<?php ParroquiaMenu::seleccionarMenu($orden,$menuNovios->orden);?>">
              <a class="<?php ParroquiaMenu::seleccionarMenu($orden,$menuNovios->orden);?>" href="<?php $menuNovios->enlace(); ?>">
                Novios
              </a>
            </li>
			 <li class="<?php ParroquiaMenu::seleccionarMenu($orden,$menuObraSocial->orden);?>">
              <a class="<?php ParroquiaMenu::seleccionarMenu($orden,$menuObraSocial->orden);?>" href="<?php $menuObraSocial->enlace(); ?>">
                Hoja Parroquial  
              </a>
            </li>
			
            <li class="<?php ParroquiaMenu::seleccionarMenu($orden,$menuHistoria->orden);?>">
              <a class="<?php ParroquiaMenu::seleccionarMenu($orden,$menuHistoria->orden);?>" href="<?php $menuHistoria->enlace(); ?>">
                Historia  
              </a>
            </li>
			
            <!--
			<li class="<?php ParroquiaMenu::seleccionarMenu($orden,$menuComunidad->orden);?>">
              <a class="<?php ParroquiaMenu::seleccionarMenu($orden,$menuComunidad->orden);?>" href="<?php $menuComunidad->enlace(); ?>">
                Comunidad
              </a>
            </li>
			-->
            <li class="<?php ParroquiaMenu::seleccionarMenu($orden,$menuDevocion->orden);?>">
              <a class="<?php ParroquiaMenu::seleccionarMenu($orden,$menuDevocion->orden);?>" href="<?php $menuDevocion->enlace(); ?>">
                Devocion
              </a>
            </li>
            <li class="<?php ParroquiaMenu::seleccionarMenu($orden,$menuCulto->orden);?>">
              <a class="<?php ParroquiaMenu::seleccionarMenu($orden,$menuCulto->orden);?>" href="<?php $menuCulto->enlace(); ?>">
                Culto
              </a>
            </li>
            <li class="<?php ParroquiaMenu::seleccionarMenu($orden,$menuGrupos->orden);?>">
              <a class="<?php ParroquiaMenu::seleccionarMenu($orden,$menuGrupos->orden);?>" href="<?php $menuGrupos->enlace(); ?>">
                Grupos
              </a>
            </li>
          </ul>
        </div>
        <!--/header-->