<?php

define("WEB_MAIL", "parroquia@santuariosanantonio.com");

/*
 * Escribe en la consola de Chrome logs
 */
function traza($strMensaje,$strValor = null) {
  $strTraza = $strMensaje;
  if (!is_null($strValor)){
    $strTraza .= " ###".$strValor."###";
  }
   
  echo "<script type=\"text/javascript\">"
        ."console.log('$strTraza');</script>";
}
?>
