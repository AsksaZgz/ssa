<?php
  class Contador
  {
      var $prefijoWeb = "";
      var $rutaImagenesContador = "contador/";
      var $sql = "";
      var $web = "";
      
      
      function Contador($prefijoWeb, $rutaImagenesContador = "")
      {
          if ($rutaImagenesContador <> "")
          {
              $this->rutaImagenesContador = $rutaImagenesContador;              
          }
          $this->prefijoWeb = $prefijoWeb;
          $this->sql = new ContadorSql($this->prefijoWeb);
          $this->web = new ContadorWeb();
      }
      
      function visitasPagina()
      {
          return $this->web->mostrar($this->sql->visitasPagina() 
                                , $this->rutaImagenesContador);
          
      }
      
      function visita($seccion="")
      {
          $this->sql->visita($seccion);
      }
      
      
  }  
?>
<?php
    class ContadorWeb
    {
        function mostrar($numeroVisitas , $rutaImagenesContador )
        {
                
            for($i=0;$i<strlen($numeroVisitas);$i++) 
            {
                $imgnum = substr($numeroVisitas,$i,1);
                $contador .= "<img alt='$imgnum' src='$rutaImagenesContador$imgnum.gif'>";
            }
              
              return $contador;
        }
    }
?>
<?php
  class ContadorSql
  {
      public static $TABLA_BASE = "CONTADOR";
      public static $CAMPO_IDENTIFICADOR = "SECCION";
      public static $CAMPO_CONTADOR = "VISITAS";
      public static $CAMPO_FECHA_INICIO = "FECHA_INICIO";
      public static $CAMPO_FECHA_FIN = "FECHA_FIN";
      
      public static $IDENTIFICADOR_PAGINA = 0;
      
      var $tabla = "";
      
      function ContadorSql($webTablaPrefijo)
      {
          $this->tabla = $webTablaPrefijo."_".ContadorSql::$TABLA_BASE;
      }
      
      function visita($seccion)
      {
          if ($seccion=="")
          {
              $seccion = ContadorSql::$IDENTIFICADOR_PAGINA;
          }
          $res = mysql_query("UPDATE "
                                .$this->tabla
                                ." SET  "
                                .ContadorSql::$CAMPO_CONTADOR
                                ." = "
                                .ContadorSql::$CAMPO_CONTADOR
                                ." + 1 "
                                ." , "
                                .ContadorSql::$CAMPO_FECHA_FIN
                                ." = NOW() "
                                ." WHERE "
                                .ContadorSql::$CAMPO_IDENTIFICADOR
                                ." = "
                                .$seccion);
           if (mysql_affected_rows()==0) 
           {
                $this->insertar($seccion);
           }
      }
      
      function insertar($seccion)
      {
          if ($seccion=="")
          {
              $seccion = ContadorSql::$IDENTIFICADOR_PAGINA;
          }
          $res = mysql_query("INSERT INTO "
                                .$this->tabla
                                ." VALUES ($seccion,NOW(),NOW(),1)");
          
      }
      
      function visitasPagina()
      {
          $res = mysql_fetch_array(mysql_query("SELECT "
                                                    .ContadorSql::$CAMPO_CONTADOR
                                                ." FROM "
                                                    .$this->tabla
                                                ." WHERE "
                                                    .ContadorSql::$CAMPO_IDENTIFICADOR
                                                    ." = "
                                                    .ContadorSql::$IDENTIFICADOR_PAGINA));
          return $res[ContadorSql::$CAMPO_CONTADOR];                                                    
      }
      /*
        CREATE TABLE `psa_contador` (
          `SECCION` int(11) NOT NULL default '0' COMMENT 'Identificador de la secci�n',
          `FECHA_INICIO` datetime NOT NULL default '0000-00-00 00:00:00' COMMENT 'Fecha de inicio del contador de visitas',
          `FECHA_FIN` datetime NOT NULL default '0000-00-00 00:00:00' COMMENT 'Fecha de la ultima visita',
          `VISITAS` bigint(20) NOT NULL default '0' COMMENT 'Numero de visitas',
          PRIMARY KEY  (`SECCION`)
        ) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_spanish_ci COMMENT='ParroquiaSanAntonio contador';
      */
  }
?>