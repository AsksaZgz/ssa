<?php
    require_once './editorCulto/editor.publico.php';
     $arrPrueba = editorPublicoContenido('./contenido/culto');

        foreach ($arrPrueba as $fichero => $titulo) {
            //echo 'Fichero:##'.$key.'## Titulo:##'.$value.'##<br/>';
            //$menuEvangelio->usuario = $fichero;
            $menuCulto->suborden = $fichero;
			echo '<li><a href="';
			$menuCulto->enlace();
			echo '">'.$titulo.'</a></li>';
                                
        }
?>