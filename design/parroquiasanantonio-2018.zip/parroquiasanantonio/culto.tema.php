<?php
                                                                               
?>
<div id="body">
    <div id="sideBar">
      <div id="sideNav">
      <div id="sideNavBottom">
        <h1 class="title">Culto</h1>
        
<ul class="sectionMenu">
    <?php 
        require_once './culto.tema.menu.php';
    ?>
 </ul>


      </div><!--/sideNav-->
      </div><!--/sideNavBottom-->

      
    </div><!--/sideBar-->
    <div id="content">
    <div id="contentTop">
    <div id="contentBottom">
      <div id="image">
        
<!-- Start_Content_121589 -->

<?php


  
?>

<div class="element" id="element131808_67053">

<div class="textElement">
    <h1>
      <?php 
      if (file_exists($ficheroSeleccionadoTitulo)) {
          require_once $ficheroSeleccionadoTitulo;
      } 
       ?>
    </h1>
    <p>
      <?php 
      if (file_exists($ficheroSeleccionado)) {
          require_once $ficheroSeleccionado;
      }
      ?>
    </p>

</div>
</div>

<!-- End_Content_121589 -->

<!-- ie -->
      </div><!--/image-->
      <div id="text">
        
<!-- ie -->
      </div><!--/text-->  
    </div><!--/contentBottom-->
    </div><!--/contentTop-->
    </div><!--/content-->
    
  </div><!--/body-->
