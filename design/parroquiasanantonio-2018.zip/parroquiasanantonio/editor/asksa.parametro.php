<?php


function parametroRecuperar($strNombreParametro) {    
    $strValor = null;
    
    if (isset($_POST[$strNombreParametro])) {
      $strValor = $_POST[$strNombreParametro];
    }elseif (isset($_GET[$strNombreParametro])) {
      $strValor =$_GET[$strNombreParametro];
    }
    
    return parametroDecodificarUrl($strValor);
}


function parametroDecodificarUrl($strValor) {
    //return base64_decode($strValor);
    return urldecode($strValor);
}


function parametroGenerar($strNombre, $strValor, $blnEsElPrimero = false){
    $strRespuesta = "";
    if (!is_null($strValor)) {
        if ($blnEsElPrimero) {
            $strRespuesta = "?";
        } else {
            $strRespuesta = "&";
        }
        $strRespuesta .= $strNombre."=".parametroCodificarUrl($strValor);
    }
    return $strRespuesta;

}

function parametroCodificarUrl($strValor) {
    //return base64_encode($strValor);
    return urlencode($strValor);
}
?>
