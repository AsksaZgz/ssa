 
<?php

// SEGURIDAD ///////////////////////////////////////////////////////////////////
// Web origen
define('EDITOR_ORIGEN', 'localhost:8888');
// Usuario permitido
define('EDITOR_USUARIO_NOMBRE', 'asksa');
define('EDITOR_USUARIO_CLAVE', 'asksa');

// Validacion directa
define('EDITOR_KEY','123456789');

// Mostrar mensajes de depuraci�n
define('EDITOR_DEPURAR', false);

// PARAMETRIZACI�N DEL EDITOR //////////////////////////////////////////////////
// Activar la edici�n de directorios
define('EDITOR_ACTIVAR_DIRECTORIOS', false);
//TODO NUEVO Crear el interface necesario
define('EDITOR_ACTIVAR_NUEVO', true);
//TODO ELIMINAR Crear el interface necesario
define('EDITOR_ACTIVAR_BORRAR', true);
//TODO RECUPERAR Crear el interface necesario
define('EDITOR_ACTIVAR_RECUPERAR', false);

// PRESENTACION ////////////////////////////////////////////////////////////////
define('EDITOR_PRESENTACION_TIULO', 'Evangelios editor:');

// CONTENDIO ///////////////////////////////////////////////////////////////////
// Ruta base donde se encuentra el contenido
define('EDITOR_CONTENIDO_RUTA', '../contenido/evangelio');
// Extensi�n de los contenidos
define('EDITOR_CONTENIDO_EXTENSION', 'dat');
// Extensi�n de los titulos de los contenidos
define('EDITOR_CONTENIDO_EXTENSION_TITULO', 'tit');
// Extensi�n de las versiones de los contenidos
define('EDITOR_CONTENIDO_EXTENSION_VERSION', 'ver');
// Extensi�n borrado contenido
define('EDITOR_CONTENIDO_EXTENSION_BORRADO', 'borrado');
// Contenido por defecto para los nuevos 
define('EDITOR_CONTENIDO_DEFECTO','Contenido del evangelio');
// Titulo por defecto para los nuevos 
define('EDITOR_TITULO_DEFECTO','Titulo del evangelio');


// BOTONES /////////////////////////////////////////////////////////////////////
// Titulo boton editar
define('EDITOR_BOTON_EDITAR','Editar Evangelio');
// Titulo boton nuevo
define('EDITOR_BOTON_NUEVO','Nuevo Evangelio');
// Titulo boton eliminar
define('EDITOR_BOTON_BORRAR','Borrar Evangelio');





?>
