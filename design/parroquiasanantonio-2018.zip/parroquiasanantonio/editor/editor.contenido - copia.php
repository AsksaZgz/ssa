<!DOCTYPE html>
<?php
$fichero = parametro('fichero');
?>
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="en" lang="en">
<head>
	<meta http-equiv="Content-Type" content="text/html; charset=utf-8"/>
	<title></title>
	
	<meta name="description" content=""/>
	<!--[if lte IE 8]> 
	<![endif]-->
	<!--[if IE 8]> 
	<![endif]-->
	<script src="http://recursos.asksa.es/js/jquery-1.6.2.min.js" type="text/javascript" charset="utf-8"></script>
	<script src="./js/jquery.wysiwyg.js" type="text/javascript" charset="utf-8"></script>
	<!--
	<script src="./js/jquery.wysiwyg.controls.defecto.js" type="text/javascript" charset="utf-8"></script>
	
	<script type="text/javascript" src="./js/farbtastic.js"></script>
	<script type="text/javascript" src="./js/jquery.autoload.js"></script>

<script type="text/javascript" src="./js/wysiwyg.autoload.js"></script>
<script type="text/javascript" src="./js/wysiwyg.fullscreen.js"></script>
<script type="text/javascript" src="./js/wysiwyg.i18n.js"></script>
<script type="text/javascript" src="./js/lang.es.js"></script>
<script type="text/javascript" src="./js/wysiwyg.rmFormat.js"></script>
<script type="text/javascript" src="./js/wysiwyg.colorpicker.js"></script>
<script type="text/javascript" src="./js/wysiwyg.image.js"></script>
<script type="text/javascript" src="./js/wysiwyg.link.js"></script>
<script type="text/javascript" src="./js/wysiwyg.table.js"></script>
-->
	<!--
	<script type="text/javascript" charset="utf-8">
	//<![CDATA[
		$(document).ready(function(){
			$('#editor').wysiwyg
			(
				{
					plugins: 
					{
						//autoload: true,
						i18n: { lang: "es" },
						rmFormat: { rmMsWordMarkup: true }
					},
					controls: 
					{
						html: {visible: true},
						colorpicker: {
							groupIndex: 11,
							visible: true,
							css: {
								"color": function (cssValue, Wysiwyg) {
									var document = Wysiwyg.innerDocument(),
										defaultTextareaColor = $(document.body).css("color");

									if (cssValue !== defaultTextareaColor) {
										return true;
									}

									return false;
								}
							},
							exec: function() {
								if ($.wysiwyg.controls.colorpicker) {
									$.wysiwyg.controls.colorpicker.init(this);
								}
							},
							tooltip: "Colorpicker"
						},
						fullscreen: {
							groupIndex: 12,
							visible: true,
							exec: function () {
								if ($.wysiwyg.fullscreen) {
									$.wysiwyg.fullscreen.init(this);
								}
							},
							tooltip: "Fullscreen"
						}
					},
					initialContent: function() 
					{
						return "<p>Prueba</p>";
					}
				}
			);
            //$('editor').wysiwyg("insertHtml", "Sample code");
            
		});
	//]]>
	</script>
	-->
	<!--
        <script type="text/javascript">
	(function($) {
		$(document).ready(function() {
			$('#editor').wysiwyg
			(
				{
					initialContent: function() 
					{
						return "<p>Prueba</p>";
					}
				}
			);
		});
	})(jQuery);
	</script>
        -->
        <!-- Ejemplo basico -->
        <script type="text/javascript" src="./js/wysiwyg.image.js"></script>
        <script type="text/javascript" src="./js/wysiwyg.link.js"></script>
        <script type="text/javascript" src="./js/wysiwyg.table.js"></script>
        <script type="text/javascript">
        (function($) {
                $(document).ready(function() {
                        $('#editor').wysiwyg();
                });
        })(jQuery);
        </script>
        <link rel="stylesheet" type="text/css" href="./css/screen.css" media="screen, projection" />
        <link rel="stylesheet" type="text/css" href="./css/blueprint/print.css" media="print" />

        <!-- Ejemplo basico -->
        <link rel="stylesheet" href="./css/jquery.wysiwyg.css" type="text/css" media="screen" charset="utf-8" />
	<!--
	<link rel="stylesheet" href="./css/farbtastic.css" type="text/css"/>
	-->
	
	<style type="text/css" media="screen">
		#container{ width:600px; }
		textarea{ width:500px; height:300px; }
	</style>
</head>
<body>
	<?php depurar('Fichero:'.$fichero); ?>
	<div id="container">
		<?php //echo WEB_FORMULARIO; 
                ?>
			<textarea id="editor"></textarea>
			<br/>
			<input name="fichero" type="hidden" value="<?php echo $fichero; ?>" />
			<input name="modo" type="hidden" value="guardar" />
			<input id="inputsubmit1" type="submit" name="inputsubmit1" value="Guardar" />
		<?php 
                //echo WEB_FORMULARIO_FIN; 
                ?>
	</div>
</body>
</html>