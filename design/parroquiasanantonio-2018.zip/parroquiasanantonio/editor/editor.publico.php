<?php

require_once 'editor.web.php';
// Parametros a configurar
require_once 'editor.config.php';

/*
 * Devuelve un array con el titulo y nombre del fichero como key
 */
function editorPublicoContenido($strRuta){
    $arrContenido = array();
    if (is_dir($strRuta)) {
        if ($dh = opendir($strRuta)) {
            while (($file = readdir($dh)) !== false) {
                if ($file == ".") {
                    continue;
                }
                if ($file == "..") {
                    continue;
                }
                //esta l�nea la utilizar�amos si queremos listar todo lo que hay en el directorio 
                //mostrar�a tanto archivos como directorios 
                //http://php.net/manual/es/function.pathinfo.php
                if ((is_dir($strRuta . '/' . $file)) && (EDITOR_ACTIVAR_DIRECTORIOS)) {
                    //crearEnlaceDirectorio($file);
                } elseif (!(is_dir($strRuta . '/' . $file))) {
                    $ficheroInformacion = pathinfo($file);
                    if ($ficheroInformacion['extension'] == EDITOR_CONTENIDO_EXTENSION) {
                        
                        $strFechaModificacion = date("d/m/Y", filemtime($strRuta . '/' . $file));
                        //require $fichero . '.' . EDITOR_CONTENIDO_EXTENSION_TITULO;
                        //echo "($strFechaModificacion)";
                        
                        $arrContenido[$file] = file_get_contents($strRuta . '/'. $file. '.' . EDITOR_CONTENIDO_EXTENSION_TITULO);
                        
                        
                    }
                }
            }
            closedir($dh);
        }
        
        
    } else {
        echo "<br>No es ruta valida";
    }
    return $arrContenido;
    
}



function editorPublico($strRuta){
    //Recorrer el directorio y presentar enlaces
    // ?configurar?
    // ruta del contenido
    // p�gina destino
    // nombre del parametro
    // mostrar fecha de ultima actualizacion
    if (is_dir($strRuta)) {
        if ($dh = opendir($strRuta)) {
            while (($file = readdir($dh)) !== false) {
                if ($file == ".") {
                    continue;
                }
                if ($file == "..") {
                    continue;
                }
                //esta l�nea la utilizar�amos si queremos listar todo lo que hay en el directorio 
                //mostrar�a tanto archivos como directorios 
                //http://php.net/manual/es/function.pathinfo.php
                if ((is_dir($strRuta . '/' . $file)) && (EDITOR_ACTIVAR_DIRECTORIOS)) {
                    //crearEnlaceDirectorio($file);
                } elseif (!(is_dir($strRuta . '/' . $file))) {
                    $ficheroInformacion = pathinfo($file);
                    if ($ficheroInformacion['extension'] == EDITOR_CONTENIDO_EXTENSION) {
                        //echo EDITOR_WEB_FORMULARIO;
                        echo "<br/>";
                        editorPublicoCrearEnlace($strRuta . '/' . $file);
                        //crearEditor($strRuta . '/' . $file);
                        //crearBotonBorrar($strRuta . '/' . $file);
                        //echo EDITOR_WEB_FORMULARIO_FIN;
                    }
                }
            }
            closedir($dh);
        }
        echo '<hr/>';
        //crearBotonNuevo($strRuta);
    } else {
        echo "<br>No es ruta valida";
    }
    
}

function editorPublicoCrearEnlace($fichero) {

    // Recuperar el titulo del documento
    // xej: require $fichero'.tit'
    $strFechaModificacion = date("d/m/Y", filemtime($fichero));
    require $fichero . '.' . EDITOR_CONTENIDO_EXTENSION_TITULO;
    echo "($strFechaModificacion)";
}


?>
