<html>
<head>
</head>
<body>
    <a href="editor.php">Editor</a>
    <hr/>
    <a href="editor.php?editorKey=123456789" targer="_self">Validaci�n directa</a>
    <hr/>
    <h2>Presentaci�n del contendio</h2>
    <?php
        require_once 'editor.publico.php';
        editorPublico('../contenido');
    ?>
    <hr/>
    <h2>Presentaci�n del contendio personalizado</h2>
    <?php
        require_once 'editor.publico.php';
        $arrPrueba = editorPublicoContenido('../contenido');
        
        /*
         // Alternativa para versiones anteriores
        foreach ($colors as $key => $color) {
            $colors[$key] = strtoupper($color);
        }
         * // PHP 5
        foreach ($colors as &$color) {
            $color = strtoupper($color);
        }
         * 
         */
        
        foreach ($arrPrueba as $key => $value) {
            echo 'Fichero:##'.$key.'## Titulo:##'.$value.'##<br/>';
            
        }
    ?>
</body>
</html>