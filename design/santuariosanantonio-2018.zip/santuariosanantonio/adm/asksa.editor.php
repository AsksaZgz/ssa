<?php

define('EDITOR_LLAVE','123456789');



function editorBotonAcceso($strRuta,$strValorBoton){
    
    echo '<form name="form1" method="post" action="'.$strRuta.'/editor.php" target="_blank">';
    echo '<input type="submit" name="Submit" value="'.$strValorBoton.'">';
    echo '<input name="editorKey" type="hidden" id="editorKey" value="'.EDITOR_LLAVE.'">';
    echo '</form>';
}

function editorBotonAccesoPersonalizado(){
    editorBotonAcceso('http://parroquiasanantonio.asksa.es/editor','Administrar el Evangelio');
}

function editorBotonAccesoPersonalizadoGrupos(){
    editorBotonAcceso('http://parroquiasanantonio.asksa.es/editorGrupos','Administrar Grupos');
}

function editorBotonAccesoPersonalizadoCulto(){
    editorBotonAcceso('http://parroquiasanantonio.asksa.es/editorCulto','Administrar Culto');
}

function editorBotonAccesoPersonalizadoContenido(){
    editorBotonAcceso('http://parroquiasanantonio.asksa.es/editorContenido','Administrar Contenido');
}
?>
