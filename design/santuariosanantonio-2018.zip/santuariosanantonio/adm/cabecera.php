<table width="90%" border="1" align="center">
  <tr align="center">
    <td>Novedades Enero del 2007. </td>
  </tr>
  <tr>
    <td align="justify">
    <!--
		Nuevo servicio Musical, que permite elegir la m�sica de tu web.
		<br />
		Manual. <a href="http://servicios.asksa.net/biblioteca/Sonido_1_00_ManualUsuario.pdf">Pulsa aqu� para descargar el manual.</a>	</td>
        -->
  </tr>
</table>
