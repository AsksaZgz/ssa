<?php
mysql_connect(BD_SERVIDOR, BD_USUARIO, BD_CLAVE);
mysql_select_db(BD_BD);
?>