<?php
mysql_close();  
?>