<?php
include("../../etc/config.php");
include("BD_conectar.php");
?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd">
<html>
<head>
<?php
$id_web = $_POST["id_web"];
$orden = $_POST["orden"];
$id_usuario = $_POST["id_usuario"];
$informacion = $_POST["informacion"];
$id_informacion = $_POST["id_informacion"];

include ("sql.inc");
include ("ok.inc");
//TABLA DE INFORMACI�N
include ("logica_web.php");
define("PATH_SERVICIO_INFORMACION","ver_informacionv0.php");
?>
<title>Servicio de Informaci�n</title>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
<link href="../estilo.css" rel="stylesheet" type="text/css">
</head>

<body>
<?php
function menu_informacion($id_web, $id_usuario)
{
$res_informacion=sql("select id_informacion, id_web, titulo, estado from ".INFO_TABLA." where id_web='$id_web' and estado=1 order by titulo");
?>
<table width="90%" border="0">
  <tr>
    <td>
      <div align="center">MENU DEL SERVICIO DE INFORMACION v.3 
        <table width="98%" border="0">
          <tr>
            <td>
              <table width="98%" border="1" align="center">
                <tr> 
                  <td> 
                    <form name="form2" method="post" action="<?php global $PHP_SELF; print $PHP_SELF; ?>">
                      <div align="center"> 
                        <input type="submit" class="boton" name="Submit9" value="Nueva Informaci&oacute;n">
                        <input type="hidden" name="id_web" value="<?php print $id_web; ?>">
                        <input type="hidden" name="orden" value="100016">
                        <input name="id_usuario" type="hidden" id="id_usuario" value="<?php print $id_usuario; ?>">
<span class="ayuda"><?php
		//print ayuda(100016);
		?></span>
</div>
                    </form>
                  </td>
                  <td> 
                    <form name="form3" method="post" action="<?php global $PHP_SELF; print $PHP_SELF; ?>">
                      <div align="center"> 
                        <input type="submit" class="boton" name="Submit10" value="Recuperar Informaci&oacute;n">
                        <input name="id_web" type="hidden" id="id_web" value="<?php print $id_web; ?>">
                        <input name="orden" type="hidden" id="orden" value="100027">
                        <input name="id_usuario" type="hidden" id="id_usuario8" value="<?php print $id_usuario; ?>">
                        <span class="ayuda">
                        <?php
		//print ayuda(100027);
		?>
                        </span> </div>
                    </form>
                  </td>
                </tr>
                <tr valign="middle"> 
                  <td colspan="2"> 
                    <table width="99%" border="1" align="center">
                      <?php
	while ($informacion=mysql_fetch_array($res_informacion))
	{
				
?>
                      <tr valign="middle"> 
                        <td> 
                          <?php print $informacion[titulo]; ?>
                        </td>
                        <?php
		if($tupla_lista[estado]==7)
		{
?>
                        <td> 
                          <form name="form9" method="post" action="<?php global $PHP_SELF; print $PHP_SELF; ?>">
                            <input type="button" name="Button" value="En uso ">
                          </form>
                        </td>
                        <?php
		}
		elseif($informacion[estado]==1)
		{
?>
                        <td> 
                          <form name="form4" method="post" action="<?php global $PHP_SELF; print $PHP_SELF; ?>">
                            <input type="submit" class="boton" name="Submit11" value="Editar">
                            <input type="hidden" name="id_web" value="<?php print $id_web; ?>">
                            <input type="hidden" name="orden" value="100020">
                            <input name="id_informacion" type="hidden" id="id_informacion" value="<?php print $informacion[id_informacion]; ?>">
                            <input name="id_usuario" type="hidden" id="id_usuario3" value="<?php print $id_usuario; ?>">
                            <span class="ayuda">
                            <?php
		//print ayuda(100020);
		?>
                            </span>                          </form>
                        </td>
<!--
                        <td> 
                          <form name="form5" method="post" action="<?php global $PHP_SELF; print $PHP_SELF; ?>">
                            <input type="submit" class="boton" name="Submit12" value="asociar imagen">
                            <input type="hidden" name="id_web" value="<?php print $id_web; ?>">
                            <input type="hidden" name="orden" value="101401">
                            <input type="hidden" name="id_info" value="<?php print $informacion[id_informacion]; ?>">
                          </form>
                        </td>
-->


                        <td> 
                          <form name="form7" method="post" action="<?php global $PHP_SELF; print $PHP_SELF; ?>">
                            <input type="submit" class="boton" name="Submit14" value="Borrar">
                            <input name="id_web" type="hidden" id="id_web" value="<?php print $id_web; ?>">
                            <input name="orden" type="hidden" id="orden" value="100023">
                            <input name="id_informacion" type="hidden" id="id_informacion" value="<?php print $informacion[id_informacion]; ?>">
                            <input name="id_usuario" type="hidden" id="id_usuario" value="<?php print $id_usuario; ?>">
                            <span class="ayuda">
                            <?php
		//print ayuda(100023);
		?>
                            </span>                          </form>
                        </td>
                        <td> 
                        <!--
                          <form name="form7" method="post" action="<?php global $PHP_SELF; print $PHP_SELF; ?>">
                            <input type="submit" class="boton" name="Submit14" value="Seleccionar Fondo">
                            <input name="id_web" type="hidden" id="id_web" value="<?php print $id_web; ?>">
                            <input name="orden" type="hidden" id="orden" value="100030">
                            <input name="id_informacion" type="hidden" id="id_informacion" value="<?php print $informacion[id_informacion]; ?>">
                            <input name="id_usuario" type="hidden" id="id_usuario" value="<?php print $id_usuario; ?>">
                            <span class="ayuda">
                            
                            <?php
		//print ayuda(100030);
		?>
                            </span>                          </form>
                            -->
                        </td>

                        <td>
                        <!--
                        <form name="form5" method="post" action="<?php print PATH_SERVICIO_INFORMACION;?>" target="_blank">
                          <input name="Submit4" type="submit" class="boton" value="Vista previa">
                          <input name="id_informacion" type="hidden" id="id_informacion4" value="<?php print $informacion[id_informacion]; ?>">
                          <span class="ayuda">
                          <?php
		//print ayuda(100033);
		?>
                          </span>                        </form></td>
                          -->
                      </tr>
                      <?php    
 		}
	 }
?>
                    </table>
                  </td>
                </tr>
                <tr> 
                  <td> 
                                       <form name="form2" method="post" action="<?php global $PHP_SELF; print $PHP_SELF; ?>">
                      <div align="center"> 
                        <input type="submit" class="boton" name="Submit9" value="Nueva Informaci&oacute;n">
                        <input type="hidden" name="id_web" value="<?php print $id_web; ?>">
                        <input type="hidden" name="orden" value="100016">
                        <input name="id_usuario" type="hidden" id="id_usuario" value="<?php print $id_usuario; ?>">
<span class="ayuda"><?php
		//print ayuda(100016);
		?></span>
</div>
                    </form>
                  </td>
                  <td> 
                    <form name="form3" method="post" action="<?php global $PHP_SELF; print $PHP_SELF; ?>">
                      <div align="center"> 
                        <input type="submit" class="boton" name="Submit10" value="Recuperar Informaci&oacute;n">
                        <input name="id_web" type="hidden" id="id_web4" value="<?php print $id_web; ?>">
                        <input name="orden" type="hidden" id="orden4" value="100027">
                        <input name="id_usuario" type="hidden" id="id_usuario9" value="<?php print $id_usuario; ?>">
                        <span class="ayuda">
                        <?php
		//print ayuda(100027);
		?>
                        </span></div>
                    </form>
                  </td>
                </tr>
              </table>
            </td>
          </tr>
          <tr>
            <td>
<form name="form6" method="post" action="http://<?php  interface_usuario($id_usuario); ?>">
            <input type="submit" class="boton" name="Submit6" value="Volver al menu principal">
            <input name="id_web" type="hidden" id="id_web"  value="<?php print $id_web; ?>">
            <input name="orden" type="hidden" id="orden"  value="100019">
            <input name="id_usuario" type="hidden" id="id_usuario"  value="<?php print $id_usuario; ?>">
                <span class="ayuda"><?php
		//print ayuda(100019);
		?></span> 
			  </form>
            </td>
          </tr>
        </table>
      </div>
    </td>
  </tr>
</table>

<?php
}
//FIN MENU INFORMACION
function menu_nueva_informacion($id_web,$id_usuario)
{
?>
<table width="90%" border="0">
  <tr> 
    <td> 
      <div align="center">NUEVA INFORMACI&Oacute;N 
        <table width="98%" border="0">
          <tr> 
            <td>
              <form name="form8" method="post" action="<?php global $PHP_SELF; print $PHP_SELF; ?>">
                <table width="99%" border="0" align="center">
                  <tr> 
                    <td colspan="2"> 
                      <div align="center"> 
                        <input name="Submit15" type="button" class="boton" onClick="alert('Si desea poner en negrita una palabra debera poner delante de ella \r&lt;b&gt; \ry detras \r&lt;/b&gt;\rEjemplo: \rHola &lt;b&gt;mundo&lt;/b&gt;')" value="Negrita">
                        <input name="Submit16" type="button" class="boton"
						onClick="alert('Si desea poner en cursiva una palabra debera poner delante de ella \r&lt;i&gt; \ry detras \r&lt;/i&gt;\r\rEjemplo: \rHola &lt;i&gt;mundo&lt;/i&gt;')" value="Cursiva">
                        <input name="Submit163" type="button" class="boton"
						onClick="alert('Si desea poner en Negrita y Cursiva una palabra debera poner delante de ella \r&lt;i&gt; &lt;b&gt; \ry detras \r&lt;/b&gt;&lt;/i&gt; \r\rEjemplo: \rHola &lt;i&gt; &lt;b&gt; mundo&lt;/b&gt;&lt;/i&gt;')" value="Negrita &amp; Cursiva">
                      </div>
                    </td>
                  </tr>
                  <tr> 
                    <td>Titulo:</td>
                    <td> * 
                      <input name="informacion[titulo]" type="text" id="informacion[titulo]" size="100">
                    </td>
                  </tr>
                  <tr> 
                    <td>Texto:</td>
                    <td> * 
                      <textarea name="informacion[texto]" cols="80" rows="20" id="informacion[texto]"></textarea>
                    </td>
                  </tr>
                  <tr> 
                    <td colspan="2">Color: 
                      <select name="informacion[color]" id="informacion[color]">
                        <option value="white" selected>blanco</option>
                        <option value="black">negro</option>
                        <option value="green">verde</option>
                        <option value="blue">azul</option>
                        <option value="yellow">amarillo</option>
                        <option value="red">rojo</option>
                        <option value="darkblue">azul oscuro</option>
                      </select>
                      Tama&ntilde;o: 
                      <select name="informacion[size]" id="informacion[size]">
                        <option value="6">6</option>
                        <option value="7">7</option>
                        <option value="8">8</option>
                        <option value="9">9</option>
                        <option value="10">10</option>
                        <option value="11">11</option>
                        <option value="12">12</option>
                        <option value="14" selected>14</option>
                        <option value="16">16</option>
                        <option value="18">18</option>
                        <option value="20">20</option>
                        <option value="24">24</option>
                        <option value="28">28</option>
                        <option value="32">32</option>
                      </select>
                    </td>
                  </tr>
                  <tr> 
                    <td colspan="2">Alineaci&oacute;n: 
                      <select name="informacion[alineacion]" id="informacion[alineacion]">
                        <option value="justify" selected>Justificada</option>
                        <option value="center">Centrada</option>
                        <option value="left">A la Izquierda</option>
                        <option value="right">A la derecha</option>
                      </select>
<!-- EN ESTUDIO DE SI SIRVE PARA ALGO
                      Caduca: 
                      <select name="caduca">
                        <option value="1" selected>Nunca</option>
                        <option value="11">En un mes</option>
                        <option value="22">En 2 meses</option>
                        <option value="33">En 3 meses</option>
                        <option value="44">En 4 meses</option>
                        <option value="55">En 5 meses</option>
                        <option value="66">En 6 meses</option>
                        <option value="77">En 7 meses</option>
                      </select>
-->					  
                    </td>
                  </tr>
                  <tr> 
                    <td colspan="2"> 
                      <div align="right"> 
                        <span class="ayuda">                        </span>
                        <input name="id_usuario" type="hidden" id="id_usuario" value="<?php print $id_usuario; ?>">
                        <input type="hidden" name="orden" value="100017">
                        <input type="hidden" name="id_web" value="<?php print $id_web; ?>">
                        <input type="submit" class="boton" name="Submit17" value="ACEPTAR">
                        <span class="ayuda">
                        <?php
		//print ayuda(100017);
		?>
                      </span></div>
                    </td>
                  </tr>
                  <tr>
                    <td colspan="2">Los campos marcados con * son obligatorios.</td>
                  </tr>
                </table>
              </form>
            </td>
          </tr>
          <tr> 
            <td> 
              <form name="form1" method="post" action="<?php global $PHP_SELF; print $PHP_SELF; ?>">
                <div align="right">
                  <input name="id_usuario" type="hidden" id="id_usuario" value="<?php print $id_usuario; ?>">
                  <input type="hidden" name="id_web" value="<?php print $id_web; ?>">
                  <input name="orden" type="hidden" id="orden" value="100018">
                  <input type="submit" class="boton" name="Submit2" value="CANCELAR">
                  <span class="ayuda">
                  <?php
		//print ayuda(100018);
		?>
                </span>                </div>
              </form>
            </td>
          </tr>
        </table>
      </div>
    </td>
  </tr>
</table><?php
}
//FIN MENU NUEVA INFORMACION
// MENU EDITAR INFORMACION
function menu_editar_informacion($id_web, $id_usuario, $id_informacion)
{
$res_informacion_original=sql("select id_informacion, titulo, texto, color, size, alineacion, estado from ".INFO_TABLA." where id_informacion='$id_informacion'");
$informacion_original=mysql_fetch_array($res_informacion_original);
?>
<table width="90%" border="0">
  <tr> 
    <td> 
      <div align="center">EDITAR INFORMACI&Oacute;N 
        <table width="98%" border="0">
          <tr> 
            <td>
              <form name="form8" method="post" action="<?php global $PHP_SELF; print $PHP_SELF; ?>">
                <table width="99%" border="0" align="center">
                  <tr> 
                    <td> 
                      <div align="left">Id: 
                        <?php print $id_informacion;?>
                      </div>
                    </td>
                    <td> 
                      <input name="Submit152" type="button" class="boton" onClick="alert('Si desea poner en negrita una palabra debera poner delante de ella \r&lt;b&gt; \ry detras \r&lt;/b&gt;\rEjemplo: \rHola &lt;b&gt;mundo&lt;/b&gt;')" value="Negrita">
                      <input name="Submit162" type="button" class="boton"
						onClick="alert('Si desea poner en cursiva una palabra debera poner delante de ella \r&lt;i&gt; \ry detras \r&lt;/i&gt;\r\rEjemplo: \rHola &lt;i&gt;mundo&lt;/i&gt;')" value="Cursiva">
                      <input name="Submit1632" type="button" class="boton"
						onClick="alert('Si desea poner en Negrita y Cursiva una palabra debera poner delante de ella \r&lt;i&gt; &lt;b&gt; \ry detras \r&lt;/b&gt;&lt;/i&gt; \r\rEjemplo: \rHola &lt;i&gt; &lt;b&gt; mundo&lt;/b&gt;&lt;/i&gt;')" value="Negrita &amp; Cursiva">
                    </td>
                  </tr>
                  <tr> 
                    <td>Titulo:</td>
                    <td> * 
                      <input name="informacion[titulo]" type="text" id="informacion[titulo]" value="<?php print $informacion_original[titulo]; ?>" size="100">
                    </td>
                  </tr>
                  <tr> 
                    <td>Comentario:</td>
                    <td valign="top"> * 
                      <textarea name="informacion[texto]" cols="80" rows="20" id="informacion[texto]"><?php print $informacion_original[texto]; ?></textarea>
                    </td>
                  </tr>
                  <tr> 
                    <td colspan="2">Color: 
                      <select name="informacion[color]" id="informacion[color]">
                        <option value="white" <?php if($informacion_original[color]=="white") { print "selected"; } ?>>blanco</option>
                        <option value="black" <?php if($informacion_original[color]=="black") { print "selected"; } ?>>negro</option>
                        <option value="green" <?php if($informacion_original[color]=="green") { print "selected"; } ?>>verde</option>
                        <option value="blue" <?php if($informacion_original[color]=="blue") { print "selected"; } ?>>azul</option>
                        <option value="yellow" <?php if($informacion_original[color]=="yellow") { print "selected"; } ?>>amarillo</option>
                        <option value="darkblue" <?php if($informacion_original[color]=="darkblue") { print "selected"; } ?>>azul 
                        oscuro</option>
                        <option value="red" <?php if($informacion_original[color]=="red") { print "selected"; } ?>>rojo</option>
                      </select>
                      Tama&ntilde;o: 
                      <select name="informacion[size]" id="informacion[size]">
                        <option value="6" <?php if($informacion_original[size]=="6") { print "selected"; } ?>>6</option>
                        <option value="7" <?php if($informacion_original[size]=="7") { print "selected"; } ?>>7</option>
                        <option value="8" <?php if($informacion_original[size]=="8") { print "selected"; } ?>>8</option>
                        <option value="9" <?php if($informacion_original[size]=="9") { print "selected"; } ?>>9</option>
                        <option value="10" <?php if($informacion_original[size]=="10") { print "selected"; } ?>>10</option>
                        <option value="11" <?php if($informacion_original[size]=="11") { print "selected"; } ?>>11</option>
                        <option value="12" <?php if($informacion_original[size]=="12") { print "selected"; } ?>>12</option>
                        <option value="14" <?php if($informacion_original[size]=="14") { print "selected"; } ?>>14</option>
                        <option value="16" <?php if($informacion_original[size]=="16") { print "selected"; } ?>>16</option>
                        <option value="18" <?php if($informacion_original[size]=="18") { print "selected"; } ?>>18</option>
                        <option value="20" <?php if($informacion_original[size]=="20") { print "selected"; } ?>>20</option>
                        <option value="24" <?php if($informacion_original[size]=="24") { print "selected"; } ?>>24</option>
                        <option value="28" <?php if($informacion_original[size]=="28") { print "selected"; } ?>>28</option>
                        <option value="32" <?php if($informacion_original[size]=="32") { print "selected"; } ?>>32</option>
                      </select>
                    </td>
                  </tr>
                  <tr> 
                    <td colspan="2">Alineaci&oacute;n: 
                      <select name="informacion[alineacion]" id="informacion[alineacion]">
                        <option value="justify" <?php if($informacion_original[alineacion]=="justify") { print "selected"; } ?>>Justificada</option>
                        <option value="center" <?php if($informacion_original[alineacion]=="center") { print "selected"; } ?>>Centrada</option>
                        <option value="left" <?php if($informacion_original[alineacion]=="left") { print "selected"; } ?>>A 
                        la Izquierda</option>
                        <option value="right" <?php if($informacion_original[alineacion]=="right") { print "selected"; } ?>>A 
                        la derecha</option>
                      </select>
<!--
                      Caduca: 
                      <select name="caduca">
                        <option value="1" <?php if($info_old[6]==1) { print "selected"; } ?>>Nunca</option>
                        <option value="11" <?php if($info_old[6]==11) { print "selected"; } ?>>En 
                        un mes</option>
                        <option value="22" <?php if($info_old[6]==22) { print "selected"; } ?>>En 
                        2 meses</option>
                        <option value="33" <?php if($info_old[6]==33) { print "selected"; } ?>>En 
                        3 meses</option>
                        <option value="44" <?php if($info_old[6]=="44") { print "selected"; } ?>>En 
                        4 meses</option>
                        <option value="55" <?php if($info_old[6]=="55") { print "selected"; } ?>>En 
                        5 meses</option>
                        <option value="66" <?php if($info_old[6]=="66") { print "selected"; } ?>>En 
                        6 meses</option>
                        <option value="77" <?php if($info_old[6]=="77") { print "selected"; } ?>>En 
                        7 meses</option>
                      </select>
-->					  
                    </td>
                  </tr>
                  <tr> 
                    <td colspan="2"> 
                      <div align="right"> 
                        <input name="id_usuario" type="hidden" id="id_usuario" value="<?php print $id_usuario; ?>">
                        <input name="id_informacion" type="hidden" id="id_informacion" value="<?php print $id_informacion; ?>">
                        <input type="hidden" name="orden" value="100021">
                        <input type="hidden" name="id_web" value="<?php print $id_web; ?>">
                        
                        <input name="Submit172" type="submit"  class="boton" value="ACEPTAR">
						<span class="ayuda">
                        <?php
		//print ayuda(100021);
		?>
                        </span>
                      </div>
                    </td>
                  </tr>
                  <tr>
                    <td colspan="2">Los campos marcados con * son obligatorios.</td>
                  </tr>
                </table>
              </form>
            </td>
          </tr>
          <tr> 
            <td> 
              <form action="<?php global $PHP_SELF; print $PHP_SELF; ?>" method="post" name="form1" >
                <div align="right">
                  <input name="id_usuario" type="hidden" id="id_usuario5" value="<?php print $id_usuario; ?>">
                  <input name="id_informacion" type="hidden" id="id_informacion" value="<?php print $id_informacion; ?>">
                  <input name="orden" type="hidden" id="orden" value="100022">
                  <input name="id_web" type="hidden" id="id_web" value="<?php print $id_web; ?>">                  
                  <input type="submit" class="boton" name="Submit3" value="CANCELAR">
                  <span class="ayuda">
                  <?php
		//print ayuda(100022);
		?>
                </span>                </div>
              </form>
            </td>
          </tr>
        </table>
      </div>
    </td>
  </tr>
</table>
<?php
}
// FIN EDITAR INFORMACION

// MENU BORRAR INFORMACION
function menu_borrar_informacion($id_web, $id_usuario, $id_informacion)
{
$res_informacion_borrar=sql("select id_informacion, titulo from ".INFO_TABLA." where id_informacion='$id_informacion'");
$informacion_borrar=mysql_fetch_array($res_informacion_borrar);
?>
<table width="90%" border="0">
  <tr> 
    <td> 
      <div align="center">BORRAR INFORMACI&Oacute;N 
        <table width="98%" border="0">
          <tr> 
            <td>
              <table width="99%" border="0" align="right">
                <tr>
                  <td>Desea borrar:<br>
				   	<?php print $informacion_borrar[titulo];?>
					<br>
					
			      </td>
                </tr>
                <tr>
                  <td>
                    <form action="<?php global $PHP_SELF; print $PHP_SELF; ?>" method="post" name="form10" class="boton">
                      <div align="right">
                        <input name="id_usuario" type="hidden" id="id_usuario" value="<?php print $id_usuario; ?>">
                        <input name="id_informacion" type="hidden" id="id_informacion" value="<?php print $id_informacion; ?>">
                        <input type="hidden" name="orden" value="100024">
                        <input type="hidden" name="id_web" value="<?php print $id_web; ?>">
                        <input type="submit" name="Submit" value="ACEPTAR">
                        <span class="ayuda">
                        <?php
		//print ayuda(100024);
		?>
                      </span>                      </div>
                    </form>
                  </td>
                </tr>
              </table>
            </td>
          </tr>
          <tr> 
            <td> 
              <form name="form1" method="post" action="<?php global $PHP_SELF; print $PHP_SELF; ?>">
                <div align="right">
                  <input name="id_usuario" type="hidden" id="id_usuario6" value="<?php print $id_id_usuario; ?>">
                  <input name="orden" type="hidden" id="orden" value="100025">
                  <input name="id_web" type="hidden" id="id_web" value="<?php print $id_web; ?>">
                  <input name="Submit7" type="submit" class="boton" value="CANCELAR">
                  <span class="ayuda">
                  <?php
		//print ayuda(100025);
		?>
                </span>                </div>
              </form>
            </td>
          </tr>
        </table>
      </div>
    </td>
  </tr>
</table>
<?php
}
//FIN MENU BORRAR INFORMACION
//MENU RECUPERAR INFORMACION
function menu_recuperar_informacion($id_web, $id_usuario)
{
$res_listado=sql("select id_informacion, id_web, titulo, estado from ".INFO_TABLA." where estado=0 and id_web='$id_web'");
?>
<table width="90%" border="0">
  <tr> 
    <td> 
      <div align="center">RECUPERAR INFORMACI&Oacute;N 
        <table width="98%" border="1">
          <?php
	while($tupla_listado=mysql_fetch_array($res_listado))
	{
?>
          <tr> 
            <td><?php print $tupla_listado[titulo]; ?></td>
            <td>
              <form name="form16" method="post" action="<?php global $PHP_SELF; print $PHP_SELF; ?>">
                <input name="Submit23" type="submit" class="boton" value="Recuperar">
                <input name="id_usuario" type="hidden" id="id_usuario4" value="<?php print $id_id_usuario; ?>">
                <input name="id_informacion" type="hidden" id="id_informacion" value="<?php print $tupla_listado[id_informacion]; ?>">
                <input name="orden" type="hidden" id="orden" value="100028">
                <input name="id_web" type="hidden" id="id_web" value="<?php print $id_web; ?>">
                <span class="ayuda">
                <?php
		//print ayuda(100028);
		?>
                </span>              </form>
            </td>
          </tr>
          <?php
	} // fin while
?>
          <tr> 
            <td colspan="2"> 
              <form name="form1" method="post" action="<?php global $PHP_SELF; print $PHP_SELF; ?>">
                <div align="right"> 
                  <input name="id_usuario" type="hidden" id="id_usuario7" value="<?php print $id_usuario; ?>">
                  <input name="orden" type="hidden" id="orden3" value="100029">
                  <input name="id_web" type="hidden" id="id_web3" value="<?php print $id_web; ?>">
                  <input name="Submit8" type="submit" class="boton" value="Volver Menu Principal">
                  <span class="ayuda">
                  <?php
		//print ayuda(100029);
		?>
                </span>                </div>
              </form>
            </td>
          </tr>
        </table>
      </div>
    </td>
  </tr>
</table>
<?php
}
//FIN MENU RECUPERAR INFORMACION
//MENU SELECCIONAR FONDO
function menu_seleccionar_fondo($id_web, $id_usuario, $id_informacion)
{
$res_fondo=sql("select id_fondo, path, nombre from fondo");
?>
<table width="90%"  border="1" cellspacing="0">
  <tr>
    <th  scope="col"><?php //print ayuda(100031); ?></th>
  </tr>
  <tr>
  <td>
<table width="100%"  border="1" cellspacing="0"> 
<?php
		$contador=0;
		while($fondo=mysql_fetch_array($res_fondo))
		{
		$contador++;
		if($contador==1)
		{
		?>
		<tr>
		<?php	
		}
?>

<td>

  
	<form name="form1" method="post" action="<?php global $PHP_SELF; print $PHP_SELF; ?>">
	<input type="image" class="boton" src="http://<?php print $fondo[path]; ?>" alt="<?php print $fondo[nombre]; ?>" width="50" height="50">
    <input name="id_usuario" type="hidden" id="id_usuario" value="<?php print $id_usuario; ?>">
    <input name="id_informacion" type="hidden" id="id_informacion" value="<?php print $id_informacion; ?>">
    <input name="orden" type="hidden" id="orden" value="100031">
    <input name="id_web" type="hidden" id="id_web" value="<?php print $id_web; ?>">	
    <input name="id_fondo" type="hidden" id="id_usuario10" value="<?php print $fondo[id_fondo]; ?>">
    </form>	</td>
	

<?php
		if($contador==5)
		{
		$contador=0;
		?>
		</tr>
		<?php	
		}
		}//FIN WHILE
		if($contador<5)
		{
		?>
		</tr>
		<?php	
		}
?>
</table>
</td>
</tr>
  <tr>
    <td>
	<form name="form1" method="post" action="<?php global $PHP_SELF; print $PHP_SELF; ?>">
	  <input name="id_usuario" type="hidden" id="id_usuario12" value="<?php print $id_usuario; ?>">
      <input name="orden" type="hidden" id="orden5" value="100032">
      <input name="id_web" type="hidden" id="id_web5" value="<?php print $id_web; ?>">
      <input name="Submit82" type="submit" class="boton" value="Volver Menu Principal">
      <span class="ayuda">
      <?php
		//print ayuda(100032);
		?>
      <input name="id_informacion" type="hidden" id="id_informacion3" value="<?php print $id_informacion; ?>">
</span>	
	</form>
	</td>
  </tr>
</table>
<?php		
}
//FIN MENU SELECCIONAR FONDO
//MENU DE ARRANQUE
//historico($orden,$id_usuario);
print "-----------------------".$orden;
switch ($orden)
	{


		case 100015:	//MENU PRINCIPAL DEL SERVICIO DE INFORMACION
			menu_informacion($id_web, $id_usuario);		
			break;	

		case 100016:	//MENU NUEVA INFORMACION
			menu_nueva_informacion($id_web, $id_usuario);		
			break;			
			
		case 100017:	//INTRODUCE NUEVA INFORMACION
			$res_id_libre=sql("select max(id_informacion)+1 from ".INFO_TABLA);
			$id_libre=mysql_fetch_array($res_id_libre);
			$res_fondo_defecto=sql("select id_web, id_fondo_defecto from web where id_web='$id_web'");
			$fondo_defecto=mysql_fetch_array($res_fondo_defecto);
			sql("insert into ".INFO_TABLA." (id_informacion, id_web, titulo, texto, color, size, alineacion, estado, modificado, caduca, id_fondo) values ('$id_libre[0]', '$id_web', '$informacion[titulo]', '$informacion[texto]', '$informacion[color]', '$informacion[size]', '$informacion[alineacion]', 1, now(), 0, '$fondo_defecto[id_fondo_defecto]')");
			menu_informacion($id_web, $id_usuario);		
			break;	
		
		case 100018:	//CANCELAR NUEVA INFORMACION
			menu_informacion($id_web, $id_usuario);		
			break;	

		case 100020:	//MENU EDITAR INFORMACION
			//BLOQUEA LA INFORMACION PARA OTROS USUARIOS
			//TEMPORALMENTE INACTIVO
			//sql("update informacion set estado=7, modificado=now() where id_informacion='$id_informacion'");
			menu_editar_informacion($id_web, $id_usuario, $id_informacion);		
			break;	

		case 100021:	//CAMBIA LOS DATOS DE UNA INFORMACION
			sql("update ".INFO_TABLA." set titulo='$informacion[titulo]', texto='$informacion[texto]', color='$informacion[color]', size='$informacion[size]', alineacion='$informacion[alineacion]', modificado=now(), estado=1, modificado=now() where id_informacion='$id_informacion'");
			menu_informacion($id_web, $id_usuario);		
			break;	

		case 100022:	//CANCELAR LOS CAMBIOS DE UNA INFORMACION
			//LIBERA LA INFORMACION PARA OTROS USUARIOS
			sql("update ".INFO_TABLA." set estado=1, modificado=now() where id_informacion='$id_informacion'");
			menu_informacion($id_web, $id_usuario);		
			break;	
			
		case 100023:	//MENU BORRAR INFORMACION
			//BLOQUEA LA INFORMACION PARA OTROS USUARIOS
			//TEMPORALMENTE INACTIVO
                                                                //sql("update informacion set estado=7,modificado=now() where id_informacion='$id_informacion'");
			menu_borrar_informacion($id_web, $id_usuario, $id_informacion);		
			break;	
			
		case 100024:	//BORRAR INFORMACION SELECCIONADA
			sql("update ".INFO_TABLA." set estado=0,modificado=now() where id_informacion='$id_informacion'");
			menu_informacion($id_web, $id_usuario);		
			break;	
			
		case 100025:	//CANCELAR BORRAR INFORMACION
			//LIBERA LA INFORMACION PARA OTROS USUARIOS
			sql("update ".INFO_TABLA." set estado=1,modificado=now() where id_informacion='$id_informacion'");
			menu_informacion($id_web, $id_usuario);		
			break;	

		case 100027:	//MENU RECUPERAR INFORMACION
			menu_recuperar_informacion($id_web, $id_usuario);		
			break;	

		case 100028:	//RECUPERAR INFORMACION
			sql("update ".INFO_TABLA." set estado=1, modificado=now() where id_informacion='$id_informacion'");
			menu_recuperar_informacion($id_web, $id_usuario);		
			break;	

		case 100029:	//VOLVER DE RECUPERAR INFORMACION
			menu_informacion($id_web, $id_usuario);		
			break;	

		case 100030:	//ENTRA EN EL MENU DE SELECCIONAR UN FONDO PARA LA INFORMACI�N
			//BLOQUEA LA INFORMACION PARA OTROS USUARIOS
                                                                //TEMPORALMENTE DESACTIVADO
                                                                //sql("update informacion set estado=7,modificado=now() where id_informacion='$id_informacion'");

			menu_seleccionar_fondo($id_web, $id_usuario, $id_informacion);		
			break;	

		case 100031:	//SELECCIONA UNA IMAGEN COMO FONDO PARA LA INFORMACI�N
			//LIBERA LA INFORMACION PARA OTROS USUARIOS
			sql("update ".INFO_TABLA." set id_fondo='$id_fondo', estado=1, modificado=now() where id_informacion='$id_informacion'");
			menu_informacion($id_web, $id_usuario);		
			break;	

		case 100032:	//SALE DEL MENU SELECCIONAR FONDO
			//LIBERA LA INFORMACION PARA OTROS USUARIOS
			sql("update ".INFO_TABLA." set estado=1, modificado=now() where id_informacion='$id_informacion'");
			menu_informacion($id_web, $id_usuario);		
			break;	


		default:	//ERROR
			print "ERROR";
			break;
	}//FIN SWITCH

//FIN MENU DE ARRANQUE
?>
</body>
</html>
<?php
include("BD_desconectar.php");
?>
