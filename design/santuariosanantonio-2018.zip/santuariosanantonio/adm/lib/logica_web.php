<?php
switch ($id_web) {
   case 100004: // Mensajero
       define("INFO_TABLA","MSA_informacion");
       define("INFO_TEMA_TABLA","MSA_tema");
       define("INFO_TEMARIO_TABLA","MSA_temario");
       define("NOTICIA_TABLA","MSA_noticia");
       define("NOTICIA_CONFIGURAR_TABLA","MSA_configurar_noticia");
       
     break;
   case 100001: //Parroquia
       define("INFO_TABLA","PSA_informacion");
       define("INFO_TEMA_TABLA","PSA_tema");
       define("INFO_TEMARIO_TABLA","PSA_temario");
       define("NOTICIA_TABLA","PSA_noticia");
       define("NOTICIA_CONFIGURAR_TABLA","PSA_configurar_noticia");

     break;
   case 100200: //Ainkaren
       define("INFO_TABLA","AIN_informacion");
       define("INFO_TEMA_TABLA","AIN_tema");
       define("INFO_TEMARIO_TABLA","AIN_temario");
       define("NOTICIA_TABLA","AIN_noticia");
       define("NOTICIA_CONFIGURAR_TABLA","AIN_configurar_noticia");
   

     break;
   case 100026: //Obra social
       define("INFO_TABLA","OSS_informacion");
       define("INFO_TEMA_TABLA","OSS_tema");
       define("INFO_TEMARIO_TABLA","OSS_temario");
       define("NOTICIA_TABLA","OSS_noticia");
       define("NOTICIA_CONFIGURAR_TABLA","OSS_configurar_noticia");

     break;

}
?>