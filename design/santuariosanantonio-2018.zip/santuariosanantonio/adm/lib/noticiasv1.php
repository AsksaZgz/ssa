<?php
include(".././etc/config.php");
include("BD_conectar.php");
?>

<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN"
"http://www.w3.org/TR/html4/loose.dtd">
<html>
<?php
$id_web = $_POST["id_web"];
$id_usuario = $_POST["id_usuario"];
$orden  = $_POST["orden"];
$titulo = $_POST["titulo"];
$texto = $_POST["texto"];
$id_noticia = $_POST["id_noticia"];
$fecha = $_POST["fecha"];

include ("sql.inc");
include ("ok.inc");
include("logica_web.php");
?>

<head>
<title></title>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">

<link href="../estilo.css" rel="stylesheet" type="text/css">
</head>
<body>
<?php
function menu_noticias($id_web, $id_usuario)
{
$res=sql("select id_noticia, id_web, titulo, fecha, estado from ".NOTICIA_TABLA." where id_web=".$id_web." and estado=1 order by fecha desc");
?>

<table width="98%"  border="1" align="center" cellpadding="0" cellspacing="0">
  <tr>
    <td colspan="3"><div align="center"><strong>Servicio de Noticias. </strong></div></td>
  </tr>
  <tr>
    <td colspan="3">	<table width="98%"  border="1" cellspacing="0">
      <tr>
        <td><form name="form1" method="post" action="">
            <input type="submit" class="boton"name="Submit" value="Nueva noticia" >
            <input name="id_web" type="hidden"  value="<?php print $id_web; ?>">
            <input name="orden" type="hidden"  value="100002">
            <input name="id_usuario" type="hidden" id="id_usuario" value="<?php print $id_usuario; ?>">
        <span class="ayuda"><?php
		print ayuda(100002);
		?></span>     
		</form>		     
		</td>
        <td colspan="2"><form name="form1" method="post" action="">
            <input type="submit" class="boton"name="Submit" value="Recuperar noticias" >
            <input name="id_web" type="hidden"  value="<?php print $id_web; ?>">
            <input name="orden" type="hidden"  value="100011">
            <input name="id_usuario" type="hidden" id="id_usuario" value="<?php print $id_usuario; ?>">
        <span class="ayuda"><?php
		print ayuda(100011);
		?></span> 
		</form></td>
		<td><input type="button" name="Submit7" value="Fondo (fuera de servicio)"></td>
      </tr>
<?php
while($tupla_noticia=mysql_fetch_array($res))
{
?>
      <tr>
        <td colspan="2"><?php print $tupla_noticia[titulo]; ?></td>
        <td><form name="form4" method="post" action="">
          <input type="submit" class="boton"name="Submit4" value="Editar">
          <input name="id_web" type="hidden"  value="<?php print $id_web; ?>">
          <input name="orden" type="hidden"  value="100005">
          <input name="id_usuario" type="hidden"  value="<?php print $id_usuario; ?>">
          <input name="id_noticia" type="hidden"  value="<?php print $tupla_noticia[id_noticia]; ?>">
        <span class="ayuda"><?php
		print ayuda(100005);
		?></span> 
		</form></td>
        <td>
		<form name="form4" method="post" action="">
          <input type="submit" class="boton"name="Submit4" value="Borrar noticia">
          <input name="id_web" type="hidden" id="id_web4" value="<?php print $id_web; ?>">
          <input name="orden" type="hidden" id="orden4" value="100010">
          <input name="id_usuario" type="hidden" id="id_usuario4" value="<?php print $id_usuario; ?>">
          <input name="id_noticia" type="hidden" id="id_usuario5" value="<?php print $tupla_noticia[id_noticia]; ?>">
        <span class="ayuda"><?php
		print ayuda(100010);
		?></span> 
		</form>		</td>
      </tr>
<?php
}
?>	  
      <tr>
        <td><form name="form1" method="post" action="">
            <input type="submit" class="boton"name="Submit" value="Nueva noticia" >
            <input name="id_web" type="hidden"  value="<?php print $id_web; ?>">
            <input name="orden" type="hidden"  value="100002">
            <input name="id_usuario" type="hidden" id="id_usuario" value="<?php print $id_usuario; ?>">
        <span class="ayuda"><?php
		print ayuda(100002);
		?></span> 
		</form></td>
        <td colspan="2"><form name="form1" method="post" action="">
            <input type="submit" class="boton"name="Submit" value="Recuperar noticias" >
            <input name="id_web" type="hidden"  value="<?php print $id_web; ?>">
            <input name="orden" type="hidden"  value="100011">
            <input name="id_usuario" type="hidden" id="id_usuario" value="<?php print $id_usuario; ?>">
        <span class="ayuda"><?php
		print ayuda(100011);
		?></span> 
		</form></td>
		<td><input type="button" name="Submit7" value="Fondo (fuera de servicio)"></td>
      </tr>
    </table></td>
  </tr>
  <tr>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
	<td>
	<form name="form7" method="post" action="http://<?php  interface_usuario($id_usuario); ?>">
        <input name="Submit8" type="submit" class="boton" value="Volver al menu de servicios">
        <input name="orden" type="hidden" id="orden"  value="100014">
        <input name="id_usuario" type="hidden" value="<?php print $id_usuario; ?>">
    <span class="ayuda"><?php
		print ayuda(100014);
		?></span> 
	</form></td>
  </tr>
</table>
<?php
}//FIN MENU NOTICIAS

function menu_nueva_noticia($id_web, $id_usuario)
{
?>
<table width="98%"  border="1" cellspacing="0">
  <tr>
    <th scope="col">Nueva Noticia </th>
  </tr>
  <tr>
    <td><form name="form2" method="post" action="">
      <table width="100%"  border="1" cellspacing="0">
        <tr>
          <th scope="row">Titulo:</th>
          <td><input name="titulo" type="text" id="titulo" size="84"></td>
        </tr>
        <tr>
          <th scope="row">Texto:</th>
          <td><textarea name="texto" cols="80" rows="10" id="texto"></textarea></td>
        </tr>
        <tr>
          <th scope="row"><!--Fecha:--></th>
          <td>&nbsp;</td>
        </tr>
        <tr>
          <th scope="row">&nbsp;</th>
          <td><div align="right">
            <input type="submit" class="boton"name="Submit2" value="Introducir Noticia">
            <input name="id_usuario" type="hidden" id="id_usuario" value="<?php print $id_usuario; ?>">
            <input name="id_web" type="hidden" id="id_web" value="<?php print $id_web; ?>">
            <input name="orden" type="hidden" id="orden" value="100003">
            <span class="ayuda"><?php
		print ayuda(100003);
		?></span> 
			</div></td>
        </tr>
      </table>
    </form></td>
  </tr>
  <tr>
    <td><div align="right">
      <form name="form3" method="post" action="">
        <input type="submit" class="boton"name="Submit3" value="Cancelar nueva Noticia">
        <input name="id_usuario" type="hidden" id="id_usuario3" value="<?php print $id_usuario; ?>">
        <input name="id_web" type="hidden" id="id_web3" value="<?php print $id_web; ?>">
        <input name="orden" type="hidden" id="orden3" value="100004">
      <span class="ayuda"><?php
		print ayuda(100004);
		?></span> 
	  </form>
      </div></td>
  </tr>
</table>
<?php
}//FIN MENU NUEVA NOTICIA

function menu_editar_noticia($id_web, $id_usuario, $id_noticia)
{
$res=sql("select id_noticia, titulo, texto, fecha from ".NOTICIA_TABLA." where id_noticia='$id_noticia'");
$tupla_noticia=mysql_fetch_array($res);
?>
<table width="98%"  border="1" cellspacing="0">
  <tr>
    <th scope="col">Editar Noticia</th>
  </tr>
  <tr>
    <td><form name="form2" method="post" action="">
      <table width="100%"  border="1" cellspacing="0">
        <tr>
          <th scope="row">Titulo:</th>
          <td><input name="titulo" type="text" id="titulo" value="<?php print $tupla_noticia[titulo]; ?>" size="84"></td>
        </tr>
        <tr>
          <th scope="row">Texto:</th>
          <td><textarea name="texto" cols="80" rows="10" id="texto"><?php print $tupla_noticia[texto]; ?></textarea></td>
        </tr>
        <tr>
          <th scope="row"><!--Fecha:--></th>
          <td><input name="fecha" type="hidden" id="fecha" value="<?php print $tupla_noticia[fecha]; ?>"></td>
        </tr>
        <tr>
          <th scope="row">&nbsp;</th>
          <td><div align="right">
            <input type="submit" class="boton"name="Submit2" value="Cambiar Noticia">
            <input name="id_usuario" type="hidden" id="id_usuario" value="<?php print $id_usuario; ?>">
            <input name="id_web" type="hidden" id="id_web" value="<?php print $id_web; ?>">
            <input name="id_noticia" type="hidden" id="id_noticia" value="<?php print $id_noticia; ?>">
            <input name="orden" type="hidden" id="orden" value="100006">
            <span class="ayuda"><?php
		print ayuda(100006);
		?></span> 
			</div></td>
        </tr>
      </table>
    </form></td>
  </tr>
  <tr>
    <td><div align="right">
      <form name="form3" method="post" action="">
        <input type="submit" class="boton"name="Submit3" value="Cancelar nueva Noticia">
        <input name="id_usuario" type="hidden" id="id_usuario" value="<?php print $id_usuario; ?>">
        <input name="id_web" type="hidden" id="id_web" value="<?php print $id_web; ?>">
        <input name="id_noticia" type="hidden" id="id_noticia" value="<?php print $id_noticia; ?>">
        <input name="orden" type="hidden" id="orden" value="100007">
      <span class="ayuda"><?php
		print ayuda(100007);
		?></span> 
	  </form>
      </div></td>
  </tr>
</table>
<?php
}//FIN MENU EDITAR NOTICIA

function menu_borrar_noticia($id_web, $id_usuario, $id_noticia)
{
$res=sql("select id_noticia, titulo from ".NOTICIA_TABLA." where id_noticia='$id_noticia'");
$tupla=mysql_fetch_array($res);
?>
<table width="98%"  border="1" cellspacing="0">
  <tr>
    <th colspan="2" scope="col">Borrar Noticia </th>
  </tr>
  <tr>
    <td colspan="2">Esta seguro que desea borrar la noticia: </td>
  </tr>
  <tr>
    <td colspan="2">
<?php
	print $tupla[titulo];
?>	
	</td>
  </tr>
  <tr>
    <div align="right">
	<td>	
	
	<form name="form5" method="post" action="">
      <input name="id_usuario" type="hidden" value="<?php print $id_usuario; ?>">
      <input name="id_web" type="hidden"  value="<?php print $id_web; ?>">
      <input name="id_noticia" type="hidden"  value="<?php print $id_noticia; ?>">
      <input name="orden" type="hidden"  value="100008">
      <input type="submit" class="boton" name="Submit5" value="Borrar noticia">
    <span class="ayuda"><?php
		print ayuda(100008);
		?></span> 
	</form>
	
	</td>
    <td><form name="form5" method="post" action="">
	  <input name="id_usuario" type="hidden"  value="<?php print $id_usuario; ?>">
      <input name="id_web" type="hidden" value="<?php print $id_web; ?>">
      <input name="id_noticia" type="hidden" value="<?php print $id_noticia; ?>">
      <input name="orden" type="hidden" value="100009">
    <span class="ayuda"><?php
		print ayuda(100009);
		?></span> 
	<input type="submit" class="boton"name="Submit5" value="Cancelar">
    </form></td>
</div>	
  </tr>
</table>
<?php
}//FIN MENU BORRAR NOTICIA

function menu_recuperar_noticias($id_web, $id_usuario)
{
$res=sql("select id_noticia, id_web, titulo, fecha, estado from ".NOTICIA_TABLA." where id_web=".$id_web." and estado=0 order by fecha desc");
?>

<table width="98%"  border="1" cellspacing="0">
  <tr>
    <td><div align="center"><strong>Recuperar Noticias. </strong></div></td>
  </tr>
  <tr>
    <td><table width="100%"  border="1" cellspacing="0">
<?php
while($tupla_noticia=mysql_fetch_array($res))
{
?>
      <tr>
        <td colspan="2"><?php print $tupla_noticia[titulo]; ?></td>
        <td><form name="form4" method="post" action="">
          <input type="submit" class="boton"name="Submit4" value="Recuperar noticia">
          <input name="id_web" type="hidden"  value="<?php print $id_web; ?>">
          <input name="orden" type="hidden"  value="100012">
          <input name="id_usuario" type="hidden"  value="<?php print $id_usuario; ?>">
          <input name="id_noticia" type="hidden"  value="<?php print $tupla_noticia[id_noticia]; ?>">
        <span class="ayuda"><?php
		print ayuda(100012);
		?></span> 
		</form>
		  </td>
        </tr>
<?php
}
?>	  
      <tr>
        <td>&nbsp;</td>
        <td>&nbsp;</td>
        <td><form name="form6" method="post" action="">
            <input type="submit" name="Submit6" value="Volver al menu principal">
            <input name="id_web" type="hidden" id="id_web"  value="<?php print $id_web; ?>">
            <input name="orden" type="hidden" id="orden"  value="100014">
            <input name="id_usuario" type="hidden" id="id_usuario"  value="<?php print $id_usuario; ?>">
                <span class="ayuda"><?php
		print ayuda(100014);
		?></span> 
				</form></td>
      </tr>
    </table></td>
  </tr>
</table>
<?php
}//FIN MENU RECUPERAR NOTICIAS

//MENU DE ARRANQUE
historico($orden,$id_usuario);
switch ($orden)
	{
		case 100002:	//MENU NUEVA NOTICIA
			menu_nueva_noticia($id_web, $id_usuario);		
			break;
		case 100003:	//INTRODUCIR NUEVA NOTICIA

			$res=sql("select max(id_noticia)+1 from ".NOTICIA_TABLA);
			$tupla=mysql_fetch_array($res);
			sql("insert into ".NOTICIA_TABLA." (id_noticia,id_web, titulo, texto) values ('$tupla[0]','$id_web','$titulo','$texto')");

			menu_noticias($id_web, $id_usuario);		
			break;

		case 100005:	//MENU EDITAR NOTICIA
			menu_editar_noticia($id_web, $id_usuario, $id_noticia);		
			break;
			
		case 100006:	//CAMBIAR NOTICIA
			sql("update ".NOTICIA_TABLA." set titulo='$titulo', texto='$texto' where id_noticia='$id_noticia'");
			menu_noticias($id_web, $id_usuario);		
			break;

		case 100010:	//MENU BORRAR NOTICIA
			menu_borrar_noticia($id_web, $id_usuario,$id_noticia);		
			break;			

		case 100008:	//BORRAR NOTICIA
			sql("update ".NOTICIA_TABLA." set estado=0 where id_noticia='$id_noticia'");
			menu_noticias($id_web, $id_usuario);		
			break;			

		case 100011:	//MENU RECUPERAR NOTICIA
			menu_recuperar_noticias($id_web, $id_usuario);		
			break;			

		case 100012:	//RECUPERAR NOTICIA
			sql("update ".NOTICIA_TABLA." set estado=1 where id_noticia='$id_noticia'");
			menu_recuperar_noticias($id_web, $id_usuario);		
			break;			

		case 100001:	//MENU PRINCIPAL DEL SERVICIO DE NOTICIAS
			menu_noticias($id_web, $id_usuario);		
			break;			
		case 100013:	//VOLVER AL MENU PRINCIPAL DESDE MENU RECUPERAR NOTICIA
			menu_noticias($id_web, $id_usuario);		
			break;			
		case 100004:	//VOLVER AL MENU PRINCIPAL DESDE MENU NUEVA NOTICIA
			menu_noticias($id_web, $id_usuario);		
			break;			
		case 100007:	//VOLVER AL MENU PRINCIPAL DESDE MENU EDITAR NOTICIA
			menu_noticias($id_web, $id_usuario);		
			break;			
		case 100009:	//VOLVER AL MENU PRINCIPAL DESDE MENU BORRAR NOTICIA
			menu_noticias($id_web, $id_usuario);		
			break;			

			
		default:	//ERROR
			print "ERROR";
			break;
	}//FIN SWITCH

//FIN MENU DE ARRANQUE
?>
</body>
</html>
<?php
include("BD_desconectar.php");
?>
