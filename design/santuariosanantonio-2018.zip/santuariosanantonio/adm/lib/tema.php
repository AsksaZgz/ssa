<?php
include("../../etc/config.php");
include("BD_conectar.php");
?>

<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd">
<html>
<head>
<?php
$id_web = $_POST["id_web"];
$id_usuario = $_POST["id_usuario"];
$id_tema = $_POST["id_tema"];
$orden = $_POST["orden"];
$informacion = $_POST["informacion"];
$id_informacion = $_POST["id_informacion"];

include "sql.inc";
include "ok.inc";

include ("logica_web.php");

$res_tema=sql("select id_tema, titulo from ".INFO_TEMA_TABLA." where id_tema='$id_tema'");
$tema=mysql_fetch_array($res_tema);

define("VER_INFORMACION","ver_informacionv0.php");
define("VER_TEMA","ver_tema.php");

?>
<title>Documento sin t&iacute;tulo</title>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
<link href="http://estilo.asksa.net/100027.css" rel="stylesheet" type="text/css">
</head>

<body>
<?php
function menu_tema($id_web, $id_usuario, $id_tema)
{
$res_informacion=sql("select titulo, id_tema, orden, temario.estado, temario.id_informacion, informacion.id_informacion as id_informacion, informacion.estado as estado from ".INFO_TEMARIO_TABLA." temario, ".INFO_TABLA." informacion where id_tema='$id_tema' and temario.id_informacion=informacion.id_informacion and temario.estado=1 order by orden");
?>
<table width="90%" border="0">
  
<tr>       <td>
	    <table width="98%" border="0">
          <tr>
            <td>
              <table width="98%" border="1" align="center">
				<tr>
				<td>
				  <form name="form1" method="post" action="">
				    <input type="submit" class="boton" name="Submit" value="Editar Tema">
				    </form>
				</td>
				<td>
				  <form name="form1" method="post" action="">
				<input type="submit" class="boton" name="Submit2" value="Fondo Tema">
				</form>
				</td>
				<td>
				  <form name="form1" method="post" action="">
				    <input type="submit"  class="boton" name="Submit3" value="Vista Previa del Tema">
				    </form>
				</td>
				
				</tr>
                <tr> 
                  <td colspan="2"> 
                    <form name="form2" method="post" action="<?php global $PHP_SELF; print $PHP_SELF; ?>">
                      <div align="center"> 
                        <input type="submit" class="boton" name="Submit9" value="Nueva Informaci&oacute;n">
                        <input name="id_tema" type="hidden" id="id_tema6" value="<?php print $id_tema;?>"> 
                        <input type="hidden" name="id_web" value="<?php print $id_web; ?>">
                        <input type="hidden" name="orden" value="100035">
                        <input name="id_usuario" type="hidden" id="id_usuario" value="<?php print $id_usuario; ?>">
<span class="ayuda"><?php
		print ayuda(100035);
		?></span>
</div>
                    </form>
                  </td>
<!--				  
                  <td> 
                    <form name="form3" method="post" action="<?php global $PHP_SELF; print $PHP_SELF; ?>">
                      <div align="center"> 
                        <input type="submit" class="boton" name="Submit10" value="Recuperar Informaci&oacute;n">
                        <input name="id_web" type="hidden" id="id_web" value="<?php print $id_web; ?>">
                        <input name="orden" type="hidden" id="orden" value="100027">
                        <input name="id_usuario" type="hidden" id="id_usuario8" value="<?php print $id_usuario; ?>">
                        <span class="ayuda">
                        <?php
		print ayuda(100027);
		?>
                        </span> </div>
                    </form>
                  </td>
-->			  
                </tr>
                <tr valign="middle"> 
                  <td colspan="3"> 
                    <table width="99%" border="1" align="center">
                      <?php
	while ($informacion=mysql_fetch_array($res_informacion))
	{
				
?>
                      <tr valign="middle"> 
                        <td> 
                          <?php print $informacion[titulo]; ?>
                        </td>
                        <?php
		if($tupla_lista[estado]==7)
		{
?>
                        <td> 
                          <form name="form9" method="post" action="<?php global $PHP_SELF; print $PHP_SELF; ?>">
                            <input type="button" name="Button" value="En uso ">
                          </form>
                        </td>
                        <?php
		}
		elseif($informacion[estado]==2)
		{
?>
                        <td> 
                          <form name="form4" method="post" action="<?php global $PHP_SELF; print $PHP_SELF; ?>">
                            <input type="submit" class="boton" name="Submit11" value="Editar Informacion">
                            <input type="hidden" name="id_web" value="<?php print $id_web; ?>">
                            <input type="hidden" name="orden" value="100037">
                            <input name="id_informacion" type="hidden" id="id_informacion" value="<?php print $informacion[id_informacion]; ?>">
                            <input name="id_usuario" type="hidden" id="id_usuario3" value="<?php print $id_usuario; ?>">
                            <span class="ayuda">
                            <?php
		print ayuda(100037);
		?>
                            <input name="id_tema" type="hidden" id="id_tema4" value="<?php print $id_tema;?>">
                            </span>                          
                          </form>
                        </td>
<!--
                        <td> 
                          <form name="form5" method="post" action="<?php global $PHP_SELF; print $PHP_SELF; ?>">
                            <input type="submit" class="boton" name="Submit12" value="asociar imagen">
                            <input type="hidden" name="id_web" value="<?php print $id_web; ?>">
                            <input type="hidden" name="orden" value="101401">
                            <input type="hidden" name="id_info" value="<?php print $informacion[id_informacion]; ?>">
                          </form>
                        </td>
-->


                        <td> 
                          <form name="form7" method="post" action="<?php global $PHP_SELF; print $PHP_SELF; ?>">
                            <input type="submit" class="boton" name="Submit14" value="Borrar">
                            <input name="id_web" type="hidden" id="id_web" value="<?php print $id_web; ?>">
                            <input name="orden" type="hidden" id="orden" value="100038">
                            <input name="id_informacion" type="hidden" id="id_informacion" value="<?php print $informacion[id_informacion]; ?>">
                            <input name="id_usuario" type="hidden" id="id_usuario" value="<?php print $id_usuario; ?>">
                            <span class="ayuda">
                            <?php
		print ayuda(100038);
		?>
                            <input name="id_tema" type="hidden" id="id_tema8" value="<?php print $id_tema;?>">
</span>                          
                          </form>
                        </td>
					
                        <td> 
                          <form name="form7" method="post" action="<?php global $PHP_SELF; print $PHP_SELF; ?>">
                            <input type="submit" class="boton" name="Submit14" value="Seleccionar Fondo Informacion">
                            <input name="id_web" type="hidden" id="id_web" value="<?php print $id_web; ?>">
                            <input name="orden" type="hidden" id="orden" value="100039">
                            <input name="id_informacion" type="hidden" id="id_informacion" value="<?php print $informacion[id_informacion]; ?>">
                            <input name="id_usuario" type="hidden" id="id_usuario" value="<?php print $id_usuario; ?>">
                            <span class="ayuda">
                            <?php
		print ayuda(100039);
		?>
                            <input name="id_tema" type="hidden" id="id_tema7" value="<?php print $id_tema;?>">
</span>                          
                          </form>
                        </td>

                        <td><form name="form5" method="post" action="http://<?php print VER_INFORMACION;?>" target="_blank">
                          <input name="Submit4" type="submit" class="boton" value="Vista previa">
                          <input name="id_informacion" type="hidden" id="id_informacion4" value="<?php print $informacion[id_informacion]; ?>">
                          <span class="ayuda">
                          <?php
		print ayuda(100040);
		?>
                          </span>                        </form></td>
                      </tr>
                      <?php    
 		}
	 }
?>
                    </table>
                  </td>
                </tr>
                <tr> 
                  <td colspan="2"> 
                                       <form name="form2" method="post" action="<?php global $PHP_SELF; print $PHP_SELF; ?>">
                      <div align="center"> 
                        <input type="submit" class="boton" name="Submit9" value="Nueva Informaci&oacute;n">
                        <input type="hidden" name="id_web" value="<?php print $id_web; ?>">
                        <input type="hidden" name="orden" value="100035">
                        <input name="id_usuario" type="hidden" id="id_usuario" value="<?php print $id_usuario; ?>">
<span class="ayuda"><?php
		print ayuda(100035);
		?></span>
<input name="id_tema" type="hidden" id="id_tema5" value="<?php print $id_tema;?>">
                      </div>
                    </form>
                  </td>
                  <td> 
<!--				  
                    <form name="form3" method="post" action="<?php global $PHP_SELF; print $PHP_SELF; ?>">
                      <div align="center"> 
                        <input type="submit" class="boton" name="Submit10" value="Recuperar Informaci&oacute;n">
                        <input name="id_web" type="hidden" id="id_web4" value="<?php print $id_web; ?>">
                        <input name="orden" type="hidden" id="orden4" value="100036">
                        <input name="id_usuario" type="hidden" id="id_usuario9" value="<?php print $id_usuario; ?>">
                        <span class="ayuda">
                        <?php
		print ayuda(100036);
		?>
                        </span></div>
                    </form>
-->					
                  </td>
                </tr>
              </table>
            </td>
          </tr>
          <tr>
            <td>
<form name="form6" method="post" action="http://<?php  interface_usuario($id_usuario); ?>">
            <input type="submit" class="boton" name="Submit6" value="Volver al menu principal">
            <input name="id_web" type="hidden" id="id_web"  value="<?php print $id_web; ?>">
            <input name="orden" type="hidden" id="orden"  value="100019">
            <input name="id_usuario" type="hidden" id="id_usuario"  value="<?php print $id_usuario; ?>">
                <span class="ayuda"><?php
		print ayuda(100019);
		?></span> 
			  </form>
            </td>
          </tr>
        </table>
      
    </td>
  </tr>
</table>

<?php
}
//FIN MENU INFORMACION
//MENU NUEVA INFORMACION
function menu_nueva_informacion($id_web,$id_usuario,$id_tema)
{
?>
<table width="90%" border="0">
  <tr> 
    <td> 
      <div align="center">NUEVA INFORMACI&Oacute;N 
        <table width="98%" border="0">
          <tr> 
            <td>
              <form name="form8" method="post" action="<?php global $PHP_SELF; print $PHP_SELF; ?>">
                <table width="99%" border="0" align="center">
                  <tr> 
                    <td colspan="2"> 
                      <div align="center"> 
                        <input name="Submit15" type="button" class="boton" onClick="alert('Si desea poner en negrita una palabra debera poner delante de ella \r&lt;b&gt; \ry detras \r&lt;/b&gt;\rEjemplo: \rHola &lt;b&gt;mundo&lt;/b&gt;')" value="Negrita">
                        <input name="Submit16" type="button" class="boton"
						onClick="alert('Si desea poner en cursiva una palabra debera poner delante de ella \r&lt;i&gt; \ry detras \r&lt;/i&gt;\r\rEjemplo: \rHola &lt;i&gt;mundo&lt;/i&gt;')" value="Cursiva">
                        <input name="Submit163" type="button" class="boton"
						onClick="alert('Si desea poner en Negrita y Cursiva una palabra debera poner delante de ella \r&lt;i&gt; &lt;b&gt; \ry detras \r&lt;/b&gt;&lt;/i&gt; \r\rEjemplo: \rHola &lt;i&gt; &lt;b&gt; mundo&lt;/b&gt;&lt;/i&gt;')" value="Negrita &amp; Cursiva">
                      </div>
                    </td>
                  </tr>
                  <tr> 
                    <td>Titulo:</td>
                    <td> * 
                      <input name="informacion[titulo]" type="text" id="informacion[titulo]" size="50">
                    </td>
                  </tr>
                  <tr> 
                    <td>Texto:</td>
                    <td> * 
                      <textarea name="informacion[texto]" cols="50" rows="5" id="informacion[texto]"></textarea>
                    </td>
                  </tr>
                  <tr> 
                    <td colspan="2">Color: 
                      <select name="informacion[color]" id="informacion[color]">
                        <option value="white" selected>blanco</option>
                        <option value="black">negro</option>
                        <option value="green">verde</option>
                        <option value="blue">azul</option>
                        <option value="yellow">amarillo</option>
                        <option value="red">rojo</option>
                        <option value="darkblue">azul oscuro</option>
                      </select>
                      Tama&ntilde;o: 
                      <select name="informacion[size]" id="informacion[size]">
                        <option value="6">6</option>
                        <option value="7">7</option>
                        <option value="8">8</option>
                        <option value="9">9</option>
                        <option value="10">10</option>
                        <option value="11">11</option>
                        <option value="12">12</option>
                        <option value="14" selected>14</option>
                        <option value="16">16</option>
                        <option value="18">18</option>
                        <option value="20">20</option>
                        <option value="24">24</option>
                        <option value="28">28</option>
                        <option value="32">32</option>
                      </select>
                    </td>
                  </tr>
                  <tr> 
                    <td colspan="2">Alineaci&oacute;n: 
                      <select name="informacion[alineacion]" id="informacion[alineacion]">
                        <option value="justify" selected>Justificada</option>
                        <option value="center">Centrada</option>
                        <option value="left">A la Izquierda</option>
                        <option value="right">A la derecha</option>
                      </select>
<!-- EN ESTUDIO DE SI SIRVE PARA ALGO
                      Caduca: 
                      <select name="caduca">
                        <option value="1" selected>Nunca</option>
                        <option value="11">En un mes</option>
                        <option value="22">En 2 meses</option>
                        <option value="33">En 3 meses</option>
                        <option value="44">En 4 meses</option>
                        <option value="55">En 5 meses</option>
                        <option value="66">En 6 meses</option>
                        <option value="77">En 7 meses</option>
                      </select>
-->					  
                    </td>
                  </tr>
                  <tr> 
                    <td colspan="2"> 
                      <div align="right"> 
                        <span class="ayuda">                        </span>
                        <input name="id_tema" type="hidden" id="id_tema" value="<?php print $id_tema;?>">
                        <input name="id_usuario" type="hidden" id="id_usuario" value="<?php print $id_usuario; ?>">
                        <input type="hidden" name="orden" value="100044">
                        <input type="hidden" name="id_web" value="<?php print $id_web; ?>">
                        <input type="submit" class="boton" name="Submit17" value="ACEPTAR">
                        <span class="ayuda">
                        <?php
		print ayuda(100044);
		?>
                      </span></div>
                    </td>
                  </tr>
                  <tr>
                    <td colspan="2">Los campos marcados con * son obligatorios.</td>
                  </tr>
                </table>
              </form>
            </td>
          </tr>
          <tr> 
            <td> 
              <form name="form1" method="post" action="<?php global $PHP_SELF; print $PHP_SELF; ?>">
                <div align="right">
                  <input name="id_tema" type="hidden" id="id_tema" value="<?php print $id_tema;?>">
                  <input name="id_usuario" type="hidden" id="id_usuario" value="<?php print $id_usuario; ?>">
                  <input type="hidden" name="id_web" value="<?php print $id_web; ?>">
                  <input name="orden" type="hidden" id="orden" value="100045">
                  <input type="submit" class="boton" name="Submit2" value="CANCELAR">
                  <span class="ayuda">
                  <?php
		print ayuda(100045);
		?>
                </span>                </div>
              </form>
            </td>
          </tr>
        </table>
      </div>
    </td>
  </tr>
</table><?php
}
//FIN MENU NUEVA INFORMACION

// MENU EDITAR INFORMACION
function menu_editar_informacion($id_web, $id_usuario, $id_informacion, $id_tema)
{
$res_informacion_original=sql("select id_informacion, titulo, texto, color, size, alineacion, estado from ".INFO_TABLA." where id_informacion='$id_informacion'");
$informacion_original=mysql_fetch_array($res_informacion_original);
?>
<table width="90%" border="0">
  <tr> 
    <td> 
      <div align="center">EDITAR INFORMACI&Oacute;N 
        <table width="98%" border="0">
          <tr> 
            <td>
              <form name="form8" method="post" action="<?php global $PHP_SELF; print $PHP_SELF; ?>">
                <table width="99%" border="0" align="center">
                  <tr> 
                    <td> 
                      <div align="left">Id: 
                        <?php print $id_informacion;?>
                      </div>
                    </td>
                    <td> 
                      <input name="Submit152" type="button" class="boton" onClick="alert('Si desea poner en negrita una palabra debera poner delante de ella \r&lt;b&gt; \ry detras \r&lt;/b&gt;\rEjemplo: \rHola &lt;b&gt;mundo&lt;/b&gt;')" value="Negrita">
                      <input name="Submit162" type="button" class="boton"
						onClick="alert('Si desea poner en cursiva una palabra debera poner delante de ella \r&lt;i&gt; \ry detras \r&lt;/i&gt;\r\rEjemplo: \rHola &lt;i&gt;mundo&lt;/i&gt;')" value="Cursiva">
                      <input name="Submit1632" type="button" class="boton"
						onClick="alert('Si desea poner en Negrita y Cursiva una palabra debera poner delante de ella \r&lt;i&gt; &lt;b&gt; \ry detras \r&lt;/b&gt;&lt;/i&gt; \r\rEjemplo: \rHola &lt;i&gt; &lt;b&gt; mundo&lt;/b&gt;&lt;/i&gt;')" value="Negrita &amp; Cursiva">
                    </td>
                  </tr>
                  <tr> 
                    <td>Titulo:</td>
                    <td> * 
                      <input name="informacion[titulo]" type="text" id="informacion[titulo]" value="<?php print $informacion_original[titulo]; ?>" size="50">
                    </td>
                  </tr>
                  <tr> 
                    <td>Comentario:</td>
                    <td valign="top"> * 
                      <textarea name="informacion[texto]" cols="50" rows="5" id="informacion[texto]"><?php print $informacion_original[texto]; ?></textarea>
                    </td>
                  </tr>
                  <tr> 
                    <td colspan="2">Color: 
                      <select name="informacion[color]" id="informacion[color]">
                        <option value="white" <?php if($informacion_original[color]=="white") { print "selected"; } ?>>blanco</option>
                        <option value="black" <?php if($informacion_original[color]=="black") { print "selected"; } ?>>negro</option>
                        <option value="green" <?php if($informacion_original[color]=="green") { print "selected"; } ?>>verde</option>
                        <option value="blue" <?php if($informacion_original[color]=="blue") { print "selected"; } ?>>azul</option>
                        <option value="yellow" <?php if($informacion_original[color]=="yellow") { print "selected"; } ?>>amarillo</option>
                        <option value="darkblue" <?php if($informacion_original[color]=="darkblue") { print "selected"; } ?>>azul 
                        oscuro</option>
                        <option value="red" <?php if($informacion_original[color]=="red") { print "selected"; } ?>>rojo</option>
                      </select>
                      Tama&ntilde;o: 
                      <select name="informacion[size]" id="informacion[size]">
                        <option value="6" <?php if($informacion_original[size]=="6") { print "selected"; } ?>>6</option>
                        <option value="7" <?php if($informacion_original[size]=="7") { print "selected"; } ?>>7</option>
                        <option value="8" <?php if($informacion_original[size]=="8") { print "selected"; } ?>>8</option>
                        <option value="9" <?php if($informacion_original[size]=="9") { print "selected"; } ?>>9</option>
                        <option value="10" <?php if($informacion_original[size]=="10") { print "selected"; } ?>>10</option>
                        <option value="11" <?php if($informacion_original[size]=="11") { print "selected"; } ?>>11</option>
                        <option value="12" <?php if($informacion_original[size]=="12") { print "selected"; } ?>>12</option>
                        <option value="14" <?php if($informacion_original[size]=="14") { print "selected"; } ?>>14</option>
                        <option value="16" <?php if($informacion_original[size]=="16") { print "selected"; } ?>>16</option>
                        <option value="18" <?php if($informacion_original[size]=="18") { print "selected"; } ?>>18</option>
                        <option value="20" <?php if($informacion_original[size]=="20") { print "selected"; } ?>>20</option>
                        <option value="24" <?php if($informacion_original[size]=="24") { print "selected"; } ?>>24</option>
                        <option value="28" <?php if($informacion_original[size]=="28") { print "selected"; } ?>>28</option>
                        <option value="32" <?php if($informacion_original[size]=="32") { print "selected"; } ?>>32</option>
                      </select>
                    </td>
                  </tr>
                  <tr> 
                    <td colspan="2">Alineaci&oacute;n: 
                      <select name="informacion[alineacion]" id="informacion[alineacion]">
                        <option value="justify" <?php if($informacion_original[alineacion]=="justify") { print "selected"; } ?>>Justificada</option>
                        <option value="center" <?php if($informacion_original[alineacion]=="center") { print "selected"; } ?>>Centrada</option>
                        <option value="left" <?php if($informacion_original[alineacion]=="left") { print "selected"; } ?>>A 
                        la Izquierda</option>
                        <option value="right" <?php if($informacion_original[alineacion]=="right") { print "selected"; } ?>>A 
                        la derecha</option>
                      </select>
<!--
                      Caduca: 
                      <select name="caduca">
                        <option value="1" <?php if($info_old[6]==1) { print "selected"; } ?>>Nunca</option>
                        <option value="11" <?php if($info_old[6]==11) { print "selected"; } ?>>En 
                        un mes</option>
                        <option value="22" <?php if($info_old[6]==22) { print "selected"; } ?>>En 
                        2 meses</option>
                        <option value="33" <?php if($info_old[6]==33) { print "selected"; } ?>>En 
                        3 meses</option>
                        <option value="44" <?php if($info_old[6]=="44") { print "selected"; } ?>>En 
                        4 meses</option>
                        <option value="55" <?php if($info_old[6]=="55") { print "selected"; } ?>>En 
                        5 meses</option>
                        <option value="66" <?php if($info_old[6]=="66") { print "selected"; } ?>>En 
                        6 meses</option>
                        <option value="77" <?php if($info_old[6]=="77") { print "selected"; } ?>>En 
                        7 meses</option>
                      </select>
-->					  
                    </td>
                  </tr>
                  <tr> 
                    <td colspan="2"> 
                      <div align="right"> 
                        <input name="id_tema" type="hidden" id="id_usuario4" value="<?php print $id_tema; ?>">
                        <input name="id_usuario" type="hidden" id="id_usuario" value="<?php print $id_usuario; ?>">
                        <input name="id_informacion" type="hidden" id="id_informacion" value="<?php print $id_informacion; ?>">
                        <input type="hidden" name="orden" value="100046">
                        <input type="hidden" name="id_web" value="<?php print $id_web; ?>">
                        
                        <input name="Submit172" type="submit"  class="boton" value="ACEPTAR">
						<span class="ayuda">
                        <?php
		print ayuda(100046);
		?>
                      </span>                      </div>
                    </td>
                  </tr>
                  <tr>
                    <td colspan="2">Los campos marcados con * son obligatorios.</td>
                  </tr>
                </table>
              </form>
            </td>
          </tr>
          <tr> 
            <td> 
              <form action="<?php global $PHP_SELF; print $PHP_SELF; ?>" method="post" name="form1" >
                <div align="right">
                  <input name="id_tema" type="hidden" id="id_tema3" value="<?php print $id_tema; ?>">
                  <input name="id_usuario" type="hidden" id="id_usuario5" value="<?php print $id_usuario; ?>">
                  <input name="id_informacion" type="hidden" id="id_informacion" value="<?php print $id_informacion; ?>">
                  <input name="orden" type="hidden" id="orden" value="100047">
                  <input name="id_web" type="hidden" id="id_web" value="<?php print $id_web; ?>">                  
                  <input type="submit" class="boton" name="Submit3" value="CANCELAR">
                  <span class="ayuda">
                  <?php
		print ayuda(100047);
		?>
                </span>                </div>
              </form>
            </td>
          </tr>
        </table>
      </div>
    </td>
  </tr>
</table>
<?php
}
// FIN EDITAR INFORMACION
//MENU SELECCIONAR FONDO
function menu_seleccionar_fondo($id_web, $id_usuario, $id_informacion,$id_tema)
{
$res_fondo=sql("select id_fondo, path, nombre from fondo");
?>
<table width="90%"  border="1" cellspacing="0">
  <tr>
    <th  scope="col"><?php print ayuda(100048); ?></th>
  </tr>
  <tr>
  <td>
<table width="100%"  border="1" cellspacing="0"> 
<?php
		$contador=0;
		while($fondo=mysql_fetch_array($res_fondo))
		{
		$contador++;
		if($contador==1)
		{
		?>
		<tr>
		<?php	
		}
?>

<td>

  
	<form name="form1" method="post" action="<?php global $PHP_SELF; print $PHP_SELF; ?>">
	<input type="image" class="boton" src="http://<?php print $fondo[path]; ?>" alt="<?php print $fondo[nombre]; ?>" width="50" height="50">
    <input name="id_usuario" type="hidden" id="id_usuario" value="<?php print $id_usuario; ?>">
    <input name="id_informacion" type="hidden" id="id_informacion" value="<?php print $id_informacion; ?>">
    <input name="orden" type="hidden" id="orden" value="100048">
    <input name="id_web" type="hidden" id="id_web" value="<?php print $id_web; ?>">	
	<input name="id_tema" type="hidden" id="id_tema" value="<?php print $id_tema; ?>">	
    <input name="id_fondo" type="hidden" id="id_usuario10" value="<?php print $fondo[id_fondo]; ?>">
    </form>	</td>
	

<?php
		if($contador==5)
		{
		$contador=0;
		?>
		</tr>
		<?php	
		}
		}//FIN WHILE
		if($contador<5)
		{
		?>
		</tr>
		<?php	
		}
?>
</table>
</td>
</tr>
  <tr>
    <td>
	<form name="form1" method="post" action="<?php global $PHP_SELF; print $PHP_SELF; ?>">
	  <input name="id_usuario" type="hidden" id="id_usuario12" value="<?php print $id_usuario; ?>">
      <input name="orden" type="hidden" id="orden5" value="100049">
      <input name="id_web" type="hidden" id="id_web5" value="<?php print $id_web; ?>">
      <input name="Submit82" type="submit" class="boton" value="Volver Menu Principal">
      <span class="ayuda">
      <?php
		print ayuda(100049);
		?>
      <input name="id_informacion" type="hidden" id="id_informacion3" value="<?php print $id_informacion; ?>">
      <input name="id_tema" type="hidden" id="id_tema" value="<?php print $id_tema;?>">
      </span>	
	</form>
	</td>
  </tr>
</table>
<?php		
}
//FIN MENU SELECCIONAR FONDO
// MENU BORRAR INFORMACION
function menu_borrar_informacion($id_web, $id_usuario, $id_informacion, $id_tema)
{
$res_informacion_borrar=sql("select id_informacion, titulo from ".INFO_TABLA." where id_informacion='$id_informacion'");
$informacion_borrar=mysql_fetch_array($res_informacion_borrar);
?>
<table width="90%" border="0">
  <tr> 
    <td> 
      <div align="center">BORRAR INFORMACI&Oacute;N 
        <table width="98%" border="0">
          <tr> 
            <td>
              <table width="99%" border="0" align="right">
                <tr>
                  <td>Desea borrar:<br>
				   	<?php print $informacion_borrar[titulo];?>
					<br>
					
			      </td>
                </tr>
                <tr>
                  <td>
                    <form action="<?php global $PHP_SELF; print $PHP_SELF; ?>" method="post" name="form10" >
                      <div align="right">
                        <span class="ayuda">
                        <input name="id_tema" type="hidden" id="id_tema" value="<?php print $id_tema;?>">
                        </span>
                        <input name="id_usuario" type="hidden" id="id_usuario" value="<?php print $id_usuario; ?>">
                        <input name="id_informacion" type="hidden" id="id_informacion" value="<?php print $id_informacion; ?>">
                        <input type="hidden" name="orden" value="100050">
                        <input type="hidden" name="id_web" value="<?php print $id_web; ?>">
                        <input type="submit" name="Submit" value="ACEPTAR" class="boton">
                        <span class="ayuda">
                        <?php
		print ayuda(100050);
		?>
                      </span>                      </div>
                    </form>
                  </td>
                </tr>
              </table>
            </td>
          </tr>
          <tr> 
            <td> 
              <form name="form1" method="post" action="<?php global $PHP_SELF; print $PHP_SELF; ?>">
                <div align="right">
                  <span class="ayuda">
                  <input name="id_tema" type="hidden" id="id_tema10" value="<?php print $id_tema;?>">
                  </span>
                  <input name="id_usuario" type="hidden" id="id_usuario6" value="<?php print $id_id_usuario; ?>">
                  <input name="orden" type="hidden" id="orden" value="100051">
                  <input name="id_web" type="hidden" id="id_web" value="<?php print $id_web; ?>">
                  <input name="Submit7" type="submit" class="boton" value="CANCELAR">
                  <span class="ayuda">
                  <?php
		print ayuda(100051);
		?>
                </span>                </div>
              </form>
            </td>
          </tr>
        </table>
      </div>
    </td>
  </tr>
</table>
<?php
}
//FIN MENU BORRAR INFORMACION


print "Administraci�n del tema: ".$tema[titulo];

//MENU DE ARRANQUE
//historico($orden,$id_usuario);
switch ($orden)
	{


		case 100034:	//MENU PRINCIPAL DEL SERVICIO DE TEMA
			menu_tema($id_web, $id_usuario, $id_tema);		
			break;	

		case 100035:	//MENU NUEVA INFORMACION EN ESTE TEMA
			menu_nueva_informacion($id_web, $id_usuario, $id_tema);		
			break;	

		case 100044:	//CREA NUEVA INFORMACION EN ESTE TEMA
			//SELECCINAR ID_INFORMACION LIBRE
			$res_id_libre=sql("select max(id_informacion)+1 from ".INFO_TABLA."");
			$id_libre=mysql_fetch_array($res_id_libre);
			//BUSCAR FONDO
			$res_fondo_defecto=sql("select id_web, id_fondo_defecto from web where id_web='$id_web'");
			$fondo_defecto=mysql_fetch_array($res_fondo_defecto);
			//CREAR LA NUEVA INFORMACION
			sql("insert into ".INFO_TABLA." (id_informacion, id_web, titulo, texto, color, size, alineacion, estado, modificado, caduca, id_fondo) values ('$id_libre[0]', '$id_web', '$informacion[titulo]', '$informacion[texto]', '$informacion[color]', '$informacion[size]', '$informacion[alineacion]', 2, now(), 0, '$fondo_defecto[id_fondo_defecto]')");
			//ASOCIAR LA INFORMACION AL TEMARIO DE ESTE TEMA
			sql("insert into ".INFO_TEMARIO_TABLA." (id_tema, id_informacion, estado, orden, fecha) values ('$id_tema', '$id_libre[0]', 1, 1, now())");
			menu_tema($id_web, $id_usuario, $id_tema);		
			break;	

		case 100045:	//CANCELAR NUEVA INFORMACION DEL SERVICIO DE TEMA
			menu_tema($id_web, $id_usuario, $id_tema);		
			break;	
	
		case 100037:	//MENU EDITAR INFORMACION DEL SERVICIO DE TEMA
			menu_editar_informacion($id_web, $id_usuario, $id_informacion, $id_tema);
			break;

		case 100046:	//CAMBIAR LOS DATOS DE UNA INFORMACION DE ESTE TEMA
			sql("update ".INFO_TABLA." set titulo='$informacion[titulo]', texto='$informacion[texto]', color='$informacion[color]', size='$informacion[size]', alineacion='$informacion[alineacion]', modificado=now(), estado=2, modificado=now() where id_informacion='$id_informacion'");
			menu_tema($id_web, $id_usuario, $id_tema);		
			break;	

		case 100047:	//CANCELAR LOS CAMBIOS DE UNA INFORMACION DE ESTE TEMA
			menu_tema($id_web, $id_usuario, $id_tema);		
			break;	
		
		case 100039:	//MENU SELECCIONAR FONDO DE UNA INFORMACION DE ESTE TEMA
			menu_seleccionar_fondo($id_web, $id_usuario, $id_informacion,$id_tema);	
			break;	

		case 100048:	//SELECCIONA UN FONDO PARA LA INFORMACION DE ESTE TEMA
			sql("update ".INFO_TABLA." set id_fondo='$id_fondo', estado=2, modificado=now() where id_informacion='$id_informacion'");
			menu_tema($id_web, $id_usuario, $id_tema);		
			break;				

		case 100049:	//CANCELAR LOS CAMBIOS DE UNA INFORMACION DE ESTE TEMA
			menu_tema($id_web, $id_usuario, $id_tema);		
			break;	
			
		case 100038:
			menu_borrar_informacion($id_web, $id_usuario, $id_informacion, $id_tema);
			break;
			
		case 100050:	//SE BORRA INFORMACION DE ESTE TEMA
			sql("update ".INFO_TABLA." set estado=0,modificado=now() where id_informacion='$id_informacion'");
			sql("update ".INFO_TEMARIO_TABLA." set estado=0,fecha=now() where id_informacion='$id_informacion'");
			menu_tema($id_web, $id_usuario, $id_tema);		
			break;	

		case 100051:	//CANCELAR BORRAR INFORMACION DE ESTE TEMA
			menu_tema($id_web, $id_usuario, $id_tema);		
			break;	

		default:	//ERROR
			print "ERROR";
			break;
	}//FIN SWITCH

//FIN MENU DE ARRANQUE

?>
</body>
</html>
<?php
include("BD_desconectar.php");
?>
