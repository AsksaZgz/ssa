<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd">
<html>
<head>
<?php
global $id_informacion;
include ("sql.inc");
include ("texto.inc");

$res_informacion=sql("select id_informacion, titulo, texto, color, size, alineacion, estado, informacion.id_fondo, fondo.id_fondo, path from informacion, fondo where id_informacion='$id_informacion' and informacion.id_fondo=fondo.id_fondo");
$informacion=mysql_fetch_array($res_informacion);

?>
<title><?php print $informacion[titulo]; ?></title>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
<style type="text/css">
<!--
body {
	background-image: url(http://<?php print $informacion[path]; ?>);
}
.titulo {
color:<?php print $informacion[color]; ?>;
font-size:<?php print $informacion[size]+8; ?>px;
text-align:<?php print $informacion[alineacion]; ?>;
	font-variant: small-caps;
	text-transform: capitalize;
}
.texto {
color:<?php print $informacion[color]; ?>;
font-size:<?php print $informacion[size]+4; ?>px;
text-align:<?php print $informacion[alineacion]; ?>;
}
-->
</style></head>

<body>
<table width="90%"  border="0" align="center" >
  <tr>
<!--
    <td>
	<p><span class="titulo">
<?php escribe($informacion[titulo]); ?> 
	</span>
	</p>
	</td>
-->
    <td>
	<p class="titulo">
<?php escribe($informacion[titulo]); ?> 
	
	</p>
	</td>

  </tr>
  <tr>
<!--
    <td><p><span class="texto">
-->
    <td><p class="texto">

<?php 
switch ($informacion[estado])
	{
		case 1://INFORMACI�N UTILIZABLE
		escribe($informacion[texto]); 
		break;
                                           case 2://INFORMACI�N UTILIZABLE PERTENECE A UN TEMA
		escribe($informacion[texto]); 
		break;

		case 7://INFORMACI�N EN USO
		print "Esta informaci�n esta siendo actualizada en estos momentos. En breve estar� a su disposici�n. Disculpe las molestias. Webmaster."; 
		break;
		case 0://INFORMACI�N UTILIZABLE
		print "Esta informaci�n ha sido borrada. Disculpe las molestias. Webmaster."; 
		break;

	}
?>
<!--
</span>
-->
</p></td>
  </tr>
  <tr>
    <td></td>
  </tr>
</table>


</body>
</html>
