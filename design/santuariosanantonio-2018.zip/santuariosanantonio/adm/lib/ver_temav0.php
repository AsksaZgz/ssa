<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd">
<html>
<head>
<?php
global $id_tema;

include ("../sql.inc");
include ("../texto.inc");

define("PATH_VER_INFORMACION","http://servicios.asksa.net/informacion/ver_informacionv0.php");

$res_tema=sql("select id_tema, titulo, texto, color, size, alineacion, estado, tema.id_fondo, fondo.id_fondo, path from tema, fondo where id_tema='$id_tema' and tema.id_fondo=fondo.id_fondo");

$tema=mysql_fetch_array($res_tema);

$res_listado_informaciones=sql("SELECT titulo, id_tema, temario.id_informacion as id_informacion, informacion.id_informacion from temario, informacion where id_tema='$id_tema' and temario.id_informacion=informacion.id_informacion and temario.estado=1 order by orden, temario.id_informacion");

?>
<title><?php print $tema[titulo]; ?></title>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
<style type="text/css">
<!--
body {
	background-image: url(http://<?php print $tema[path]; ?>);
}
.titulo {
color:<?php print $tema[color]; ?>;
font-size:<?php print $tema[size]+10; ?>px;
text-align:<?php print $tema[alineacion]; ?>;
	font-variant: small-caps;
	text-transform: capitalize;
}
.texto {
color:<?php print $tema[color]; ?>;
font-size:<?php print $tema[size]; ?>px;
text-align:<?php print $tema[alineacion]; ?>;
	cursor: hand;
	text-transform: none;
	text-decoration: none;
}
-->
</style>
</head>

<body>
<table width="97%"  border="0" align="center" cellpadding="0" cellspacing="0">
  <tr>
    <td><span class="titulo"><?php escribe($tema[titulo]); ?></span></td>
  </tr>
  <tr>
    <td>
<?php
	while($informacion=mysql_fetch_array($res_listado_informaciones))
	{
		
?>
	<a href="<?php print PATH_VER_INFORMACION."?id_informacion=".$informacion[id_informacion];?>" class="texto"><?php escribe($informacion[titulo]); ?></a><br>
<?php
	}//FIN WHILE
?>	

	</td>
  </tr>
  <tr>
    <td><span class="texto"><?php escribe($tema[texto]); ?></span></td>
  </tr>
<!--
  <tr>
    <td>volver</td>
  </tr>
-->
</table>

</body>
</html>
