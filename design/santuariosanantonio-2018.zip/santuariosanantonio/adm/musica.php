<?php
include("../lib/fichero.php");
include("../lib/fichero_musica.php");
$musica = new Musica();
$musica->ruta = "../musica/";
$musica->ruta_suena = "../musica_actual/";

?>
<html>
<head>

<title>Musica</title>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
</head>

<body bgcolor="#FFFFFF" text="#000000">
<?php 
    print $musica->logica();
    ?>



</body>
</html>