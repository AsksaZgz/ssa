<html>
<head>
<?php 

require_once 'asksa.parametro.php';

$id_usuario = parametroRecuperar('id_usuario');


define("PATH_ADMINISTRAR_INFORMACION","lib/informacionv0.php");	
define("PATH_ADMINISTRAR_TEMA","lib/temav0.php");

define("PATH_AINKAREN","http://ainkaren.asksa.es/adm/musica.php");
define("PATH_SANTUARIO","http://santuario.asksa.es/adm/musica.php");
define("PATH_PARROQUIA","http://parroquiasanantonio.asksa.es/adm/musica.php");
define("PATH_OBRA","http://obrasocialsanantonio.asksa.es/adm/musica.php");
?>
<title>Untitled Document</title>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
</head>
<body bgcolor="#FFFFFF" text="#000000">
<br />
<table width="90%" border="1" align="center">
   <tr> 
    <td>Parroquia de San Antonio:</td>
 	  <td>
          <?php
            require_once 'asksa.editor.php';
            editorBotonAccesoPersonalizado();
			editorBotonAccesoPersonalizadoGrupos();
			editorBotonAccesoPersonalizadoCulto();
			editorBotonAccesoPersonalizadoContenido();
          ?>
	  </td>
  </tr>
</table>
</body>
</html>
