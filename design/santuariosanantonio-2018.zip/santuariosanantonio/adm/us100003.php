 
<html>
<head>
<?php 
require_once 'asksa.parametro.php';
//$id_usuario = $_GET["id_usuario"];
$id_usuario = parametroRecuperar('id_usuario');


include ("lib/sql.inc");
//include ("../texto.inc");
//include ("lib/usuario.inc");
define("LOCAL",false); 
define("PATH_ADMINISTRAR_INFORMACION","lib/informacion_3.php?");	
//define("","http://servicios.asksa.net/tema/temav0.php");
if(LOCAL) 
{
    define("PATH_MENSAJERO","http://localhost/mensajerosanantonio/adm/musica.php");
} else {
    define("PATH_MENSAJERO","http://mensajerosanantonio.asksa.es/adm/musica.php");
    
}

function enlace($ruta_musica)
{
     return "<td>
                        <a  href=\"".$ruta_musica."\" 
                            class=\"navText\"
                            target=\"_blank\">
                            Musica de la web
                        </a>
                    </td>";
}

//$aviso=avisos(100614);
?>
<title>Untitled Document</title>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
</head>

<body bgcolor="#FFFFFF" text="#000000">
<?php 
	include("cabecera.php");
?>

<br />

<table width="90%" border="1" align="center">
	<tr> 
		<td>Mensajero de San Antonio:</td>
	  <td>
		<?php
			print enlace(PATH_MENSAJERO);
		?>
	  </td>
		<td> 
	<form name="form1" method="post" action="<?php print PATH_ADMINISTRAR_INFORMACION; ?>">
			<input type="submit" name="Submit" value="Servicio de Informaci&oacute;n">
			<input type="hidden" name="id_web" value="100004">
			<input type="hidden" name="id_usuario" value="<?php print $id_usuario; ?>">
			<input type="hidden" name="orden" value="100015">      </form>
	
	<!--
		  <form name="form1" method="post" action="http://asksa3.dynip.com/sweb/v2.1/servicios2.php">
			<input type="submit" name="Submit" value="Servicio de Temas">
			<input type="hidden" name="id_web" value="100004">
			<input type="hidden" name="id_tp" value="4">
		  </form>
	-->
	
	   <form name="form1" method="post" action="lib/noticiasv1.php">
			<input type="hidden" name="id_web" value="100004">
			<input type="hidden" name="id_usuario" value="<?php print $id_usuario; ?>">
			<input type="hidden" name="orden" value="100001">
			<input type="submit" name="Submit" value="Servico de Noticias">
		  </form>
	
		</td>
		<td>
        <!--
	<form name="form1" method="post" action="http://estadisticas.asksa.net/visitas.php">
			<input type="submit" name="Submit" value="Servicio de Estadisticas">
			<input type="hidden" name="id_web" value="100004">
		  </form>
          -->
	
	</td>
	  </tr>
</table>
<br />
<table width="90%" border="1" align="center">
   <tr> 
    <td>Santuario de San Antonio:</td>
  </tr>
   <tr> 
    <td>
<form name="form1" method="post" action="<?php print PATH_ADMINISTRAR_INFORMACION; ?>">
        <input type="submit" name="Submit" value="Servicio de Informaci&oacute;n">
        <input type="hidden" name="id_web" value="100020">
        <input type="hidden" name="id_usuario" value="<?php print $id_usuario; ?>">
        <input type="hidden" name="orden" value="100015">      </form>

</td>
    <td>
    <!--
<form name="form1" method="post" action="http://estadisticas.asksa.net/visitas.php">
        <input type="submit" name="Submit" value="Servicio de Estadisticas">
        <input type="hidden" name="id_web" value="100020">
      </form>
        -->
</td>
  </tr>

</table>

<br />

<table width="90%" border="1" align="center">
   <tr> 
    <td>Parroquia de San Antonio:</td>
  </tr>
<!-- <tr> 
    <td><?php print $aviso[titulo]; ?></td>
  </tr>
<tr> 
    <td><?php print $aviso[texto]; ?></td>
  </tr> 
-->

	<tr>
	  <td>
	  <!--
	  <form name="form1" method="post" action=".php">
	
			<input type="submit" name="Submit" value="Administrar el Evangelio">
			<input name="id_usuario" type="hidden" id="id_usuario" value="<?php print $id_usuario; ?>">
			<input name="orden" type="hidden" id="orden" value="100034">
			<input name="id_tema" type="hidden" id="id_tema" value="100010">
			<input name="id_web" type="hidden" id="id_web" value="100001">
	  </form> 
       -->       
          <?php
            require_once 'asksa.editor.php';
            editorBotonAccesoPersonalizado();
			editorBotonAccesoPersonalizadoGrupos();
			editorBotonAccesoPersonalizadoCulto();
			editorBotonAccesoPersonalizadoContenido();
          ?>    
	  </td>
	</tr>
  <tr> 
    <td> 
	<!--
<form name="form1" method="post" action="<?php print PATH_ADMINISTRAR_INFORMACION; ?>">
        <input type="submit" name="Submit" value="Servicio de Informaci&oacute;n">
        <input type="hidden" name="id_web" value="100001">
        <input type="hidden" name="id_usuario" value="<?php print $id_usuario; ?>">
        <input type="hidden" name="orden" value="100015">      </form>
		-->
<!--
      <form name="form1" method="post" action="http://asksa3.dynip.com/sweb/v2.1/servicios2.php">
        <input type="submit" name="Submit" value="Servicio de Temas">
        <input type="hidden" name="id_web" value="100001">
        <input type="hidden" name="id_tp" value="4">
      </form>
-->
      <!--
	  <form name="form1" method="post" action="noticiasv1.php">
        <input type="hidden" name="id_web" value="100001">
        <input type="hidden" name="id_usuario" value="<?php print $id_usuario; ?>">
        <input type="hidden" name="orden" value="100001">
        <input type="submit" name="Submit" value="Servico de Noticias">
      </form>
	  -->
    </td>
    <td>
    <!--
<form name="form1" method="post" action="http://estadisticas.asksa.net/visitas.php">
        <input type="submit" name="Submit" value="Servicio de Estadisticas">
        <input type="hidden" name="id_web" value="100001">
      </form>
      -->

</td>
  </tr>
</table>

<br />


<br />

<table width="90%" border="1" align="center">    
  <tr> 
    <td>Obra Social:</td>
  </tr>
  <tr> 
    <td>
<form name="form1" method="post" action="<?php print PATH_ADMINISTRAR_INFORMACION; ?>">
        <input type="submit" name="Submit" value="Servicio de Informaci&oacute;n">
        <input type="hidden" name="id_web" value="100026">
        <input type="hidden" name="id_usuario" value="<?php print $id_usuario; ?>">
        <input type="hidden" name="orden" value="100015">      </form>
      </form>

</td>
    <td>
    <!--
<form name="form1" method="post" action="http://estadisticas.asksa.net/visitas.php">
        <input type="submit" name="Submit" value="Servicio de Estadisticas">
        <input type="hidden" name="id_web" value="100026">
      </form>
      -->

</td>
  </tr>
</table>

<br />


</body>
</html>




