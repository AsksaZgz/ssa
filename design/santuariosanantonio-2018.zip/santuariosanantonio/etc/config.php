<?php
// PARAMETROS GENERALES

// PARAMETROS DE LA B.D.
define("BD_SERVIDOR","195.8.66.105");
define("BD_BD","cm250399");
define("BD_USUARIO","cm250399");
define("BD_CLAVE","rY-XdTj2");

// PARAMETROS DEL SERVICIO WEB
define("WEB_ID",100020);
define("WEB_TABLA","web");
define("WEB_CONTADOR_RUTA","./lib/contador/");

// PARAMETROS DEL SERVICIO ADMINISTRACION
define("ADM_USUARIO_TABLA","ASK_usuario");


?>