 


<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
    <head>
        <title>Santuario San Antonio</title>
        <meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
        <script type="text/javascript">
            <!--
            // mask images referenced by number
            var mask2load = new Array();
            mask2load[0] = "masks/8bit/crippleedge.png";
            mask2load[1] = "masks/8bit/frizzedge.png";
            mask2load[2] = "masks/8bit/softedge.png";
            mask2load[3] = "masks/8bit/splatteredge.png";
            mask2load[4] = "masks/8bit/waveedge.png";
            mask2load[5] = "images/textedge.png";
            mask2load[6] = "images/glowedge.png";
            mask2load[7] = "images/textedge.gif";
            mask2load[8] = "images/glowedge.gif";
            mask2load[9] = "masks/2bit/crippleedge.gif";
            mask2load[10] = "masks/2bit/frizzedge.gif";
            mask2load[11] = "masks/2bit/softedge.gif";
            mask2load[12] = "masks/2bit/splatteredge.gif";
            mask2load[13] = "masks/2bit/waveedge.gif";
-->
        </script>
        <script type="text/javascript" src="edge.js"></script>
        <script type="text/javascript" src="bevel.js"></script>
        <script type="text/javascript" src="reflex.js"></script>
        <style type="text/css">
            <!--
            .titulo{
                text-align:center;
                font-family:"Times New Roman", Times, serif;
                font-size:large;
            }


            -->
        </style>
        <link href="estilo.css" rel="stylesheet" type="text/css" />
        <link href='http://fonts.googleapis.com/css?family=Sail' rel='stylesheet' type='text/css'/>
        <link href="css/santuariosanantonio.asksa.css" rel="stylesheet" type="text/css" />

        <style type="text/css">
            <!--
            .Estilo1 {color: #FF0000}
            -->

        </style>
        <!-- Notificaciones -->
        <!--        <link rel="stylesheet" media="all" href="http://css.asksa.es/pnotify.custom.min.css"/>
                <link rel="stylesheet" href="http://code.jquery.com/ui/1.10.4/themes/sunny/jquery-ui.css">
                    <script src="http://code.jquery.com/jquery-1.10.2.js"></script>
                    <script src="http://code.jquery.com/ui/1.10.4/jquery-ui.js"></script>
                    <script src="http://js.asksa.es/pnotify.custom.min.js"></script>
                    <script type="text/javascript">
                        
                        var titulo = '';
                        var aviso ='';
                        
                        titulo += 'SAN ANTONIO DE PADUA';
                        aviso += 'El pr�ximo d�a 13 de Junio<br/>';
                        aviso += 'es la fiesta de San Antonio de Padua.<br/>';
                        aviso += 'El horario de las Misas ser� el siguiente:<br/>';
                        aviso += 'Por la ma&ntilde;ana,<br/>';
                        aviso += '&nbsp;&nbsp;&nbsp;&nbsp;desde las 7h. hasta la 1h. del mediod�a<br/>';
                        aviso += 'Por la tarde,<br/>';
                        aviso += '&nbsp;&nbsp;&nbsp;&nbsp;desde las 5h. hasta las 9h.<br/>';
                        //                avisoSanAntonio += '<br/>';
                        
                        $(function(){
                            //                    PNotify.prototype.options.styling = "jqueryui";
                            new PNotify({
                                title: titulo,
                                text: aviso,
                                //                        width: "400px",
                                type: "info",
                                delay: 60 * 1000,
                                //                        desktop: {
                                //                          desktop: false,
                                //                          icon: null,
                                //                          tag: null
                                //                        },
                                styling: "jqueryui",
                                icon:'ui-icon ui-icon-locked'
                            });
                            
                            
                        });
                    </script>-->
        <!-- Efecto sombra -->
        <script src="js/shine.min.js"></script>

    </head>

    <body>

        <table width="100%" border="0" cellspacing="15">
            <tr>
                <td colspan="5"><div align="center">
                        <h1 id="tituloSantuario" class="texto__xxl"> Santuario </h1>
                        <h1 id="headline" class="texto__xxl">San Antonio de Padua </h1>

                        <p>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                    </div></td>
            </tr>
            <!-- 2012/02/16 -->
            <tr>
                <td>&nbsp;</td>
                <td>&nbsp;</td>
                <td >
                    <div align="center">
                        <a href="http://www.mensajerosanantonio.org">
						
                            <img 
                                src="http://www.mensajerosanantonio.org/documentos/sumario/8/2018-02-Mensajero-de-san-Antonio.jpg" 
                                alt="" 
                                height="300" 
                                border="0" 
                                class="reflex itiltright idistance4 iopacity50" longdesc="El Mensajero" /></a>
                                <!--src="imagen/mensajero_150.jpg"--> 
                        <br/>

                        <a id="mensajero" href="http://www.mensajerosanantonio.org">El Mensajero</a>	  </div>	</td>
                <td >
                    <div align="center">
                        <a href="http://parroquiasanantonio.asksa.es">
                            <img 
                                src="imagen/navidad2014-min.gif" 
                                alt="" 
                                width="360" 
                                height="300" 
                                border="0" 
                                class="reflex itiltnone idistance4 iopacity50" 
                                longdesc="La Parroquia de San Antonio de Padua" 
                                />
<!--                            <img 
                                src="imagen/parroquia_100.gif" 
                                alt="" width="120" 
                                height="100" 
                                border="0" 
                                class="reflex itiltnone idistance4 iopacity50" 
                                longdesc="La Parroquia de San Antonio de Padua" 
                                />-->
                        </a>
                        <br/>
                        <a href="http://parroquiasanantonio.asksa.es">La Parroquia</a> </div></td>
                <td>&nbsp;</td>
            </tr>
            <tr>
                <td>&nbsp;</td>
                <td>&nbsp;</td>
                <td >
                    <div align="center">
                        <a href="http://centrosocial.santuariosanantonio.com">
                            <img src="imagen/obraSocial_100.jpg" alt="" width="165" height="100" border="0" class="reflex itiltright idistance4 iopacity50" longdesc="El Centro Social de los Capuchinos" /></a>
                        <br/>
                        <a href="http://centrosocial.santuariosanantonio.com">El Centro Social</a></div></td>
                </td>
                <td >
                    <div align="center"><a href="http://www.ccsanantoniodepadua.com"><img src="imagen/colegio_100.jpg" alt="" width="331" height="100" border="0" class="reflex idistance4 iopacity50" longdesc="El Colegio de San Antonio de Pauda" /></a><br/>
                        <a href="http://www.ccsanantoniodepadua.com">El Colegio</a> </div></td>


                <td>&nbsp;</td>
            </tr>
            <!--/ 2012/02/16 -->

            <tr valign="middle">
                <td>&nbsp;</td>
                <td colspan="3" align="center">
                    &nbsp;
                </td>
                <td>&nbsp;</td>
            </tr>
        </table>
        <?php
        include("pie.php");
        ?>
    </body>
    <script type="text/javascript">
            var shine = new Shine(document.getElementById('headline'));

            function handleMouseMove(event) {
                shine.light.position.x = event.clientX;
                shine.light.position.y = event.clientY;
                shine.draw();
            }

            window.addEventListener('mousemove', handleMouseMove, false);

            var mensajero = new Shine(document.getElementById('mensajero'));

            function mensajeroHandleMouseMove(event) {
                mensajero.light.position.x = event.clientX;
                mensajero.light.position.y = event.clientY;
                mensajero.draw();
            }

            window.addEventListener('mousemove', mensajeroHandleMouseMove, false);
    </script>
</html>
