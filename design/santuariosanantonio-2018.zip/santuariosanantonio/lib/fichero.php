<?php
/*
Metodos y propiedades para trabajar con ficheros
    Metodos:
        archivosTipo    Recupera los archivos de un tipo de una ruta.
        extension       Recupera la extension de un archivo.
        limpiarNombre   Recupera el nombre del archivo sin la extension y sin _.
    
Versiones
1.2     2009/01/07  borrar
                    copiar
1.1 2008/07/15
    metodos:
        fecha($archivo) metodo que devuelva la fecha de modificacion

1.0 2008/07/14
    Se crea.
    Metodos:
        archivosTipo
        extension
        limpiarNombre
 
*/

class fichero
{
    //metodo que devuelva la fecha de modificacion
    function fecha($archivo)
    {
        return fileatime($archivo);    
    }
    
    function limpiarNombre($archivo, $separador = " ")
    {
        //quitar extension
        $out = substr($archivo , 0 , strrpos($archivo, "."));
        
        //quitar _
        return str_replace( "_" ,$separador, $out );
    }
    
    function extension($archivo)
    {
        $archivoInfo = pathinfo($archivo);
        return $archivoInfo['extension'];
    }
     

    function archivosTipo($url, $extension)
    { 
        $out = array();
        if(is_dir($url))
          {
              $dir_handle=opendir($url);
          }
          $dirname = substr($url,strrpos($url,"/")+1);

          while($file=readdir($dir_handle))
          {
            if($file!="." && $file!="..")
            {
              if(!is_dir($url."/".$file)) 
              {
                  $archivoInfo = pathinfo($url);
                  if ($this->extension($file) == $extension)
                    $out[] = $file;
              }
            }
          }
          closedir($dir_handle);
          return $out;
    }    
    
    function borrar($archivo)
    {
        return unlink($archivo);
    }
    
    function copiar($archivo_origen, $archivo_destino)
    {
        return copy($archivo_origen, $archivo_destino);
    }
}
?>