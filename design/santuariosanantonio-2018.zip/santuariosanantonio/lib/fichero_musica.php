<?php
/*
1.0.0   2009/01/07  mostrar_listado
                    actualizar
                    logica
                    musica_actual
                    reproducir
                    util_enlace
                    
*/
class Musica extends fichero
{
    var $ruta_suena = "./musica_actual/";
    var $ruta = "./musica/";
    var $extension = "mid";
    
    var $orden = "musica";
    var $orden_actualizar = "actualizar";
    
    function logica()
    {
        $out = "";
        
        switch ($_GET[suborden])
        {
            case $this->orden_actualizar:
                  $this->actualizar();
                  $out = $this->reproducir();
                  $out .= $this->mostrar_listado();
            break;
            default:
                  $out = $this->reproducir();
                  $out .= $this->mostrar_listado();
            
            break;
        }
        
        return $out;
    }
    
    function mostrar_listado()
    {
        $musica_suena = $this->musica_actual();
        
        $out = "<table border=\"1\" id=\"navigation\">";
        $out .="<tr><th colspan=\"2\">Actualmente: ".$this->limpiarNombre($musica_suena)."</th></tr>";
        
        $lista = $this->archivosTipo($this->ruta, $this->extension);
        foreach($lista as $nombre)
        {
            $out .= "<tr><td>";
            $out .= $this->limpiarNombre($nombre);
            $out .= "</td>";
            $out .= $this->util_enlace($this->orden,$this->orden_actualizar,$nombre,"Seleccionar");
            $out .= "</tr>";
        }        

        $out .= "</table>";
        
        return $out;
        
    }
    
    function actualizar()
    {
        $archivo_nuevo =$_GET[archivo];
        //borrar el contenido actual
        $archivo_actual = $this->ruta_suena.$this->musica_actual();
        $out = $this->borrar($archivo_actual);  
        
        //copiar el archivo nuevo
        $out &= $this->copiar($this->ruta.$archivo_nuevo , $this->ruta_suena.$archivo_nuevo);
        
        return $out;
    }
    
    function musica_actual()
    {
        $lista =  $this->archivosTipo($this->ruta_suena,$this->extension);
        foreach($lista as $nombre)
        {
            $out = $nombre;
        }
        return $out;
        
    }
    
    function reproducir()
    {
        $musica = $this->ruta_suena.$this->musica_actual();
        print "     <script language=\"Javascript\">
                        if (navigator.appName==\"Microsoft Internet Explorer\")
                            document.write('<bgsound src=\"".$musica."\" >');
                        else
                        document.write('<embed src=\"".$musica."\" hidden=\"true\"> ');
                    </script>";
    }
    
    function util_enlace($orden,$suborden,$musica,$texto)
    {
        return "<td>
                        <a  href=\"".$this->volver."?orden=".$orden."&suborden=".$suborden."&archivo=".$musica."\" 
                            class=\"navText\">
                            ".$texto."
                        </a>
                    </td>";
    }
    
    
       
}
?>