<html>
<head>
<title>Untitled Document</title>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
<?php 
$id_web=100020;

mysql_connect("localhost", "asksa_net", "Ortilla");
mysql_select_db("asksa_net_1");

$res=mysql_query("update web set visitas=visitas+1 where id_web=$id_web");
$res2=mysql_query("insert into conexion values ('$id_web', now(),'$REMOTE_ADDR')");
mysql_close();
?>


</head>

<body bgcolor="#000000" text="#000000" >
</body>
</html>
