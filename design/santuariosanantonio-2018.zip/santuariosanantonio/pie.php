<table>

 <tr>
  	<td id="dateformat" height="25" align="center">
	<h6>Copyright &copy; 2008. <a href="mailto:jbg@asksa.net"> J.B.G.</a></h6>
  </td>
  </tr>
</table>