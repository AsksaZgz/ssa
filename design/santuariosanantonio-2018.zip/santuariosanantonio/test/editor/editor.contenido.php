<!DOCTYPE html>
<?php
switch (parametro(EDITOR_PARAMETRO_MODO)) {
    case EDITOR_MODO_CONTENIDO_NUEVO:
        $strRuta = parametro(EDITOR_PARAMETRO_FICHERO);
        $fichero = editorCrearFichero($strRuta);
        break;

    case EDITOR_MODO_CONTENIDO:
        $fichero = parametro(EDITOR_PARAMETRO_FICHERO);
        break;
}
$strTitulo = $fichero.'.'.EDITOR_CONTENIDO_EXTENSION_TITULO;

function editorCrearFichero($strRuta) {
    //Crear el fichero
    ////Nombre del fichero yymmddhhmmss.extension y titulo
    $strNombreFichero = $strRuta . '/' . date('YmdHis') . '.' . EDITOR_CONTENIDO_EXTENSION;
    $strNombreFicheroTitulo = $strNombreFichero . '.' . EDITOR_CONTENIDO_EXTENSION_TITULO;

    $filContenido = fopen($strNombreFichero, 'w+');
    $filTitulo = fopen($strNombreFicheroTitulo, 'w+');

    if ($filContenido != false) {
        if ($filTitulo != false) {
            fwrite($filContenido, EDITOR_CONTENIDO_DEFECTO);
            fwrite($filTitulo, EDITOR_TITULO_DEFECTO);
            fclose($filTitulo);
        }
        fclose($filContenido);
    }
    return $strNombreFichero;
}
?>
<html>
    <head>
        <meta http-equiv="Content-Type" content="text/html; charset=UTF-8"/>
        <link rel="stylesheet" type="text/css" href="./css/jquery.wysiwyg/blueprint/screen.css" media="screen, projection" />
        <link rel="stylesheet" type="text/css" href="./css/jquery.wysiwyg/blueprint/print.css" media="print" />
        <!--[if lt IE 8]><link rel="stylesheet" href="./css/jquery.wysiwyg/blueprint/ie.css" type="text/css" media="screen, projection" /><![endif]-->
        <link rel="stylesheet" href="./css/jquery.wysiwyg/jquery.wysiwyg.css" type="text/css"/>

        <script src="./js/jquery-1.6.2.min.js" type="text/javascript" charset="utf-8"></script>
        <script type="text/javascript" src="./js/jquery.wysiwyg/jquery.wysiwyg.js"></script>
        <script type="text/javascript" src="./js/jquery.wysiwyg/controls/wysiwyg.image.js"></script>
        <script type="text/javascript" src="./js/jquery.wysiwyg/controls/wysiwyg.link.js"></script>
        <script type="text/javascript" src="./js/jquery.wysiwyg/controls/wysiwyg.table.js"></script>
        <!-- TODO castellano -->
        <script type="text/javascript">
            (function($) {
                $(document).ready(function() {
                    $('#editor').wysiwyg();
                    //$('#titulo').wysiwyg();
                });
            })(jQuery);
        </script>
    </head>
    <body>
        <div class="container">
            <?php depurar('Fichero:' . $fichero); ?>
            <?php echo EDITOR_WEB_FORMULARIO; ?>
            
            <label for="inputtext1">Titulo:</label>
            <input 
                id="titulo" 
                type="text" 
                name="titulo" 
                value="<?php include($strTitulo); ?>" />
            
            <textarea id="editor" name="editor" rows="5" cols="80">
                <?php include($fichero); ?>
            </textarea>
            <input id="inputsubmit1" type="submit" name="inputsubmit1" value="Guardar" />
            <?php 
                editorWebOculto(EDITOR_PARAMETRO_FICHERO, $fichero);
                editorWebOculto(EDITOR_PARAMETRO_MODO, EDITOR_MODO_CONTENIDO_GUARDAR);
                echo EDITOR_WEB_FORMULARIO_FIN; 
            ?>

        </div></body>
</html>
