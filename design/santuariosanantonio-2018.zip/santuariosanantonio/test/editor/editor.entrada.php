<html>
    <head>
    </head>
    <body>
        <div class="contenido">
            <?php echo EDITOR_WEB_FORMULARIO; ?>
            <fieldset>
                <legend>Entrada:</legend>
                <label for="inputtext1">Usuario:</label>
                <input id="usuario" type="text" name="usuario" value="" />
                <label for="inputtext2">Clave:</label>
                <input id="clave" type="password" name="clave" value="" />

                <input name="modo" type="hidden" value="validacion" />
                <input id="inputsubmit1" type="submit" name="inputsubmit1" value="Entrar" />

            </fieldset>
            <?php echo EDITOR_WEB_FORMULARIO_FIN; ?>
        </div>
    </body>
</html>