<?php
	$strFichero = parametro(EDITOR_PARAMETRO_FICHERO);
        $strFicheroTitulo = $strFichero.'.'.EDITOR_CONTENIDO_EXTENSION_TITULO;
        $strContenidoTitulo = parametro('titulo');
	$strEditor = parametro('editor');
	
	//http://es.php.net/manual/es/function.date.php
	//http://www.php.net/manual/es/function.filemtime.php
	//echo "La �ltima modificaci�n de $nombre_archivo fue: " . date ("F d Y H:i:s.", filemtime($nombre_archivo))
	$strMarcaTiempo = date('YmdHis',filemtime($strFichero));
	
	$strFicheroAnterior = $strFichero.'.'.$strMarcaTiempo.'.'.EDITOR_CONTENIDO_EXTENSION_VERSION;
	$strFicheroTituloAnterior = $strFicheroTitulo.'.'.$strMarcaTiempo.'.'.EDITOR_CONTENIDO_EXTENSION_VERSION;
	//guardar una copia del original con marcar de tiempo
	//http://es.php.net/manual/es/function.copy.php
	copy($strFichero,$strFicheroAnterior);
        copy($strFicheroTitulo,$strFicheroTituloAnterior);
		
	//guardar los cambios
	//  http://www.php.net/manual/es/function.fopen.php
	//  w: Escritura
	$gestorFichero = fopen($strFichero, "w");
	//  http://php.net/manual/es/function.fwrite.php
	$blnGuardar = fwrite($gestorFichero, $strEditor);
	
	fclose($gestorFichero);
        
        // Guardar los cambios del titulo
        $gestorFichero = fopen($strFicheroTitulo, "w");
	//  http://php.net/manual/es/function.fwrite.php
	$blnGuardar = fwrite($gestorFichero, $strContenidoTitulo);
	
	fclose($gestorFichero);
	
?>