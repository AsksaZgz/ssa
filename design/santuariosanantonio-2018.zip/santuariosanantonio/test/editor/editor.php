<?php

session_start();

$strModo = '';
$strRuta = '';

require_once 'editor.web.php';
//Recuperar el parametro config
// que indica que configuracin utilizar
$strConfigRequire = 'editor.config.php';
$strConfig = parametro(EDITOR_PARAMETRO_CONFIG);
if ($strConfig != '') {
    $strConfigRequire = 'editor.config.' . $strConfig . '.php';
}
require_once $strConfigRequire;


//Recuperar los parametros
//if (seguridad()) {
//    $strModo = parametro(EDITOR_PARAMETRO_MODO);
//}
$strModo = editorSeguridad();

//Presentar modo, por defecto entrada
switch ($strModo) {
    case EDITOR_MODO_CONTENIDO:

        require_once 'editor.contenido.php';
        break;

    case EDITOR_MODO_VALIDACION:
        if (validacion()) {
            require_once 'editor.presentacion.php';
        } else {
            require_once 'editor.entrada.php';
        }
        break;

    case EDITOR_MODO_CONTENIDO_GUARDAR:
    case EDITOR_MODO_CONTENIDO_BORRAR:
    case EDITOR_MODO_PRESENTACION:
    case EDITOR_MODO_PRESENTACION_DIRECTORIO:
        // TODO tratamiento del directorio
        // arrastrar la ruta, permitir retroceder
        require_once 'editor.presentacion.php';
        break;

    case EDITOR_MODO_CONTENIDO_NUEVO:
    case EDITOR_MODO_CONTENIDO:
        require_once 'editor.contenido.php';
        break;

    
    
    default:
        if (urlCorrecta()) {
            require_once 'editor.entrada.php';
        }
        break;
}


/**
 * Autenticaci�n de los usuarios
 * @return boolean true: si el usuario es correcto
 */
function validacion() {
    /* TODO Multiples usuarios */
    $blnValidacion = false;
    $strUsuario = parametro('usuario');
    $strClave = parametro('clave');
    /* TODO (+)validacion del contenido de los campos
     */
    if (($strUsuario == EDITOR_USUARIO_NOMBRE) && ($strClave == EDITOR_USUARIO_CLAVE)) {
        $blnValidacion = true;
    }
    return $blnValidacion;
}

/**
 * Mostrar los mensajes de depuraci�n, 
 * si DEPURACION = true los muestra
 * @param type $strTexto texto a mostrar
 */
function depurar($strTexto) {
    if (EDITOR_DEPURAR)
        echo $strTexto;
}

/**
 * Recuperar parametros
 * @param type $strParametro nombre del parametro
 * @return type valor del parametro recuperado
 */
function parametro($strParametro) {
    include_once 'asksa.parametro.php';
    return parametroRecuperar($strParametro);
}

/**
 * Medidas de seguridad para evitar accesos no contralados
 * @return boolean true si se han validado correctamente
 */
function seguridad() {
    $blnSeguridad = false;
    $strSesionId = session_id();
    $strSesionIdesionIdParametro = parametro('sesionCodigo');


    if (($strSesionId != '') &&
            ($strSesionId == $strSesionIdesionIdParametro)) {
        $blnSeguridad = true;
    } else {
        // comprobaci�n de validaci�n directa
        $strEditorKey = parametro('editorKey');
        if ($strEditorKey != '') {
            if ($strEditorKey == EDITOR_KEY) {
                $blnSeguridad = true;
            }
        }
    }
    return $blnSeguridad;
}

function editorSeguridad() {
    $strModo = "";
    $strSesionId = session_id();
    $strSesionIdesionIdParametro = parametro('sesionCodigo');


    if (($strSesionId != '') &&
            ($strSesionId == $strSesionIdesionIdParametro)) {
        $strModo = parametro(EDITOR_PARAMETRO_MODO);
    } else {
        // comprobaci�n de validaci�n directa
        $strEditorKey = parametro('editorKey');
        if ($strEditorKey != '') {
            if ($strEditorKey == EDITOR_KEY) {
                $strModo = EDITOR_MODO_PRESENTACION;
            }
        }
    }
    return $strModo;
}

function urlCorrecta() {
    return true;
}



?>

