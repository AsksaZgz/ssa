<?php
switch (parametro(EDITOR_PARAMETRO_MODO)) {

    case EDITOR_MODO_CONTENIDO_BORRAR:
        unlink(parametro(EDITOR_PARAMETRO_FICHERO));
        break;

    case EDITOR_MODO_CONTENIDO_GUARDAR:
        require_once 'editor.guardar.php';
        break;
        
    case EDITOR_MODO_PRESENTACION:

        break;

    case EDITOR_MODO_PRESENTACION_DIRECTORIO:

        break;
}

$strRuta = EDITOR_CONTENIDO_RUTA;
?>
<html>
    <head>
    </head>
    <body>
        <div class="contenido">

            <fieldset>
                <legend><?php echo EDITOR_PRESENTACION_TIULO; ?></legend>
<?php
//$strRuta = CONTENIDO_RUTA;
depurar('Ruta' . $strRuta);
crearBotonNuevo($strRuta);
echo '<hr/>';
if (is_dir($strRuta)) {
    if ($dh = opendir($strRuta)) {
        while (($file = readdir($dh)) !== false) {
            if ($file == ".") {
                continue;
            }
            if ($file == "..") {
                continue;
            }
            //esta l�nea la utilizar�amos si queremos listar todo lo que hay en el directorio 
            //mostrar�a tanto archivos como directorios 
            //http://php.net/manual/es/function.pathinfo.php
            if ((is_dir($strRuta . '/' . $file)) && (EDITOR_ACTIVAR_DIRECTORIOS)) {
                crearEnlaceDirectorio($file);
            } elseif (!(is_dir($strRuta . '/' . $file))) {
                $ficheroInformacion = pathinfo($file);
                if ($ficheroInformacion['extension'] == EDITOR_CONTENIDO_EXTENSION) {
                    //echo EDITOR_WEB_FORMULARIO;
                    echo "<br/>";
                    crearEnlace($strRuta . '/' . $file);
                    crearEditor($strRuta . '/' . $file);
                    crearBotonBorrar($strRuta . '/' . $file);
                    //echo EDITOR_WEB_FORMULARIO_FIN;
                }
            }
        }
        closedir($dh);
    }
    echo '<hr/>';
    crearBotonNuevo($strRuta);
} else {
    echo "<br>No es ruta valida";
}
?>

            </fieldset>

        </div>
    </body>
</html>
<?php

function crearBotonBorrar($strFichero) {
    if (EDITOR_ACTIVAR_BORRAR) {
        //Enlace editor  
        crearBoton($strFichero, EDITOR_MODO_CONTENIDO_BORRAR, EDITOR_BOTON_BORRAR);
    }
}

function crearBotonNuevo($strRuta) {
    //Comprobar que esta activado
    if (EDITOR_ACTIVAR_NUEVO) {
        //Enlace editor  
        crearBoton($strRuta, EDITOR_MODO_CONTENIDO_NUEVO, EDITOR_BOTON_NUEVO);
    }
}

function crearEnlace($fichero) {


    // Mostrar la titulo del fichero y su ultima modificacion
    /*
      //http://www.desarrolloweb.com/articulos/1930.php

      Obtener la hora del ultimo acceso a un archivo
      fileatime('archivo.xxx');

      Obtener la hora de la ultima modificaci�n de un archivo
      filemtime('archivo.xxx');

      http://www.php.net/manual/es/function.filemtime.php
      echo "La �ltima modificaci�n de $nombre_archivo fue: " . date ("F d Y H:i:s.", filemtime($nombre_archivo))
     */
    // Recuperar el titulo del documento
    // xej: require $fichero'.tit'
    $strFechaModificacion = date("d/m/Y", filemtime($fichero));
    require $fichero . '.' . EDITOR_CONTENIDO_EXTENSION_TITULO;
    echo "($strFechaModificacion)";
}

function crearEditor($fichero) {
    /*
      //echo "Crear editor para $fichero";
      echo EDITOR_WEB_OCULTO_MODO_CONTENIDO;

      <input name="fichero" type="hidden" value="<?php echo $fichero; ?>" />
      <input id="inputsubmit1" type="submit" name="inputsubmit1" value="Editar" />

     */
    crearBoton($fichero, EDITOR_MODO_CONTENIDO, EDITOR_BOTON_EDITAR);
}

function crearBoton($strFichero, $strModo, $strBoton) {
    //echo "Crear editor para $fichero";
    echo EDITOR_WEB_FORMULARIO;
    editorWebOculto(EDITOR_PARAMETRO_MODO, $strModo);
    editorWebOculto(EDITOR_PARAMETRO_FICHERO, $strFichero);
    echo '<input id="inputsubmit1" type="submit" name="inputsubmit1" value="' . $strBoton . '" />';
    echo EDITOR_WEB_FORMULARIO_FIN;
}

function crearEnlaceDirectorio($fichero) {
    //TODO Crear 
    echo EDITOR_WEB_OCULTO_MODO_CONTENIDO_DIRECTORIO;
    ?>
    <input name="" type="hidden" value="<?php echo $fichero; ?>" />
    <input id="inputsubmit1" type="submit" name="inputsubmit1" value="Editar" />
    <?php
}
?>
