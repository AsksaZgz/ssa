<?php
// PARAMETROS //////////////////////////////////////////////////////////////////
define('EDITOR_PARAMETRO_FICHERO','editorFichero');
define('EDITOR_PARAMETRO_MODO','editorModo');
define('EDITOR_PARAMETRO_CONFIG','editorConfig');

// MODO ////////////////////////////////////////////////////////////////////////
define('EDITOR_MODO_CONTENIDO', 'contenido');
define('EDITOR_MODO_CONTENIDO_NUEVO', 'contenidoNuevo');
define('EDITOR_MODO_CONTENIDO_BORRAR', 'contenidoBorrar');
define('EDITOR_MODO_CONTENIDO_DIRECTORIO', 'contenidoDirectorio');
define('EDITOR_MODO_CONTENIDO_GUARDAR', 'contenidoGuardar');
define('EDITOR_MODO_PRESENTACION', 'presentacion');
define('EDITOR_MODO_PRESENTACION_DIRECTORIO', 'directorio');
define('EDITOR_MODO_VALIDACION', 'validacion');

// ELEMENTOS WEB ///////////////////////////////////////////////////////////////
// P�gina base
define('EDITOR_WEB', 'editor.php');
// Marcador de seguridad
define('EDITOR_WEB_OCULTO_SESION', '<input name="sesionCodigo" type="hidden" value="' . session_id() . '" />');
// Marcador de modo contenido
define('EDITOR_WEB_OCULTO_MODO_CONTENIDO', '<input name="modo" type="hidden" value="' . EDITOR_MODO_CONTENIDO . '" />');
// Marcador de modo contenido nuevo
define('EDITOR_WEB_OCULTO_MODO_CONTENIDO_NUEVO', '<input name="modo" type="hidden" value="' . EDITOR_MODO_CONTENIDO_NUEVO . '" />');

// Marcador de modo contenido
define('EDITOR_WEB_OCULTO_MODO_CONTENIDO_DIRECTORIO', '<input name="modo" type="hidden" value="' . EDITOR_MODO_CONTENIDO_DIRECTORIO . '" />');
// Cabecera del formulario
define('EDITOR_WEB_FORMULARIO', '<form id="formEditor" method="post" action="' . EDITOR_WEB . '">');
// Fin formulario
define('EDITOR_WEB_FORMULARIO_FIN', EDITOR_WEB_OCULTO_SESION . '</form>');

function editorWebOculto($strNombre, $strValor) {
    echo '<input name="'.$strNombre.'" type="hidden" value="'.$strValor.'" />';
}
?>
