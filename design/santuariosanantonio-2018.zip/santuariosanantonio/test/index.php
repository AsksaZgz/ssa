<h1>TEST www.santuariosanantonio.com</h1>

<h2>Evangelio del domingo. Prueba 1. Enlazando con dropbox</h2>
<script type="text/javascript" src="http://pancake.io/embed/v1/contents.js?key=327b93&capitalize=true&hide_extension=true&date=true"></script>
<hr/>


<h2>Evangelio del domingo. Prueba 2. Enlazando con dropbox</h2>
<script type="text/javascript" src="http://pancake.io/embed/v1/contents.js?key=327b93&capitalize=true&sort=az&hide_extension=true"></script>

<hr/>

<h2>Enviar ficheros a drop box</h2>
<a href="www.dropitto.me/santuariosanantonio">Pulsa aqui</a>

<hr/>
<h2>Presentaci�n Evangelios</h2>
<hr/>
<h2>Editor Evangelios</h2>
<a href="editor/editor.php?editorKey=123456789&editorConfig=evangelio">Pulsa aqui</a>
   

<hr/>